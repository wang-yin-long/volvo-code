var express = require('express');
var moment = require("moment");
var utilUrl = "../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_BOOKING";
/**
 * Get Booking By userName
 */
exports.getuserbooks = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);
    //console.log(condition);
    //var whereSql = "where userName = @userName and status < 2";
    //var whereParams = {userName: condition.UserName};
    // 前缀 和 pool的身份ID 处理
    var agentNameStr = condition.AgentName;
    var prefixCondi = "";
    var identityCondi = "";
    if (agentNameStr != null && agentNameStr.length >= 10) {
        prefixCondi = agentNameStr.substring(0, 3);  // 机器的前缀 和 区域对应
        identityCondi = agentNameStr.substring(9, 10); // 机器的 池 对应的身份 ID
    }
    var whereUserName = (condition.UserName).toUpperCase();
    var sql = "select distinct a.*,b.regionID as prefix,c.poolID as identityID "
        + "from V_BOOKING as a left join V_REGION as b on a.bookRegion = b.id "
        + "left join V_POOL as c on a.bookPool = c.id where a.status < 2 and upper(a.userName)='" +
        whereUserName + "' order by a.bookStart "

    dbHelper.search(sql, function (err, result) {
        //dbHelper.select(tableName, whereSql, whereParams, " order by bookStart", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(null);
        } else {
            // console.log(result);
            var quickBooks = [];
            var jsonObjs = []; // 当前时间不同的pool的中得预定
            var jsonObj = null;// 与机器字符串匹配的book
            var now = new Date().valueOf() + 8 * 60 * 60 * 1000;
            for (var i = 0; i < result.length; i++) {
                var one = result[i];
                // 0 为普通预定 1为快速预定  其他是追加预定
                if (one.bookType > 0) {
                    quickBooks.push(one);
                }
                //  当前时间是否有 normal预定
                if (one.bookType == 0 && now >= one.bookStart.valueOf() && now <= one.bookEnd.valueOf()) {
                    jsonObjs.push(one);
                    jsonObj = one;
                }
            }
            /**
             * 根据机器序号判断 属于哪个pool的预定
             */
            for (var p = 0; p < jsonObjs.length; p++) {
                var onebook = jsonObjs[p];
                var preStr = onebook.prefix;// region 的前缀
                var ideStr = onebook.identityID;// 机器的第10位
                console.log(preStr + "---------" + ideStr);
                var flg1 = false;
                var flg2 = false;
                if (preStr != null && ideStr != null && preStr.indexOf(",") >= 0 && ideStr.indexOf(",") >= 0) {
                    var preStrs = preStr.split(",");
                    var ideStrs = ideStr.split(",");
                    for (var a = 0; a < preStrs.length; a++) {
                        if (prefixCondi == preStrs[a]) {
                            flg1 = true;
                        }
                    }
                    for (var b = 0; b < ideStrs.length; b++) {
                        if (identityCondi == ideStrs[b]) {
                            flg2 = true;
                        }
                    }
                }
                if (flg1 && flg2) {
                    jsonObj = onebook;
                    break;
                }
            }

            if (jsonObj == null) {
                /**
                 *  当前时间是否有 quick预定
                 */
                for (var j = 0; j < quickBooks.length; j++) {
                    var quick = quickBooks[j];
                    if (now >= quick.bookStart.valueOf() && now <= quick.bookEnd.valueOf()) {
                        jsonObj = quick;
                        break;
                    }
                }
            }
            /**
             * change booking status is login on 修改预定的登陆状态 登陆时间
             */
            var params = null;
            if (jsonObj != null) {
                if (jsonObj.remarks == null) {
                    params = {
                        status: 1,
                        agentName: agentNameStr,
                        remarks: moment(new Date(new Date().valueOf() + 6 * 60 * 60 * 1000)).format("YYYY-MM-DD HH:mm:ss"),
                        useStart: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
                    };
                    var where = {id: jsonObj.id};
                    dbHelper.update(params, where, tableName, function (err, result) {
                        if (err && err != null) {
                            console.log("Set booking login status error : " + err);
                        }
                    });
                }
            }

            /**
             * normal预定 和 quick预定 时间叠加
             */
            if (jsonObj != null) {
                for (var m = 0; m < quickBooks.length; m++) {
                    var Sbook = jsonObj.bookEnd.valueOf();
                    var book = quickBooks[m];
                    if (Sbook == book.bookStart.valueOf()) {
                        jsonObj.bookEnd = book.bookEnd;
                    }
                }
            }
            res.json(jsonObj);

            /**
             * logType == 2  user login on 登陆日志
             */
            if (jsonObj != null) {
                var params = {
                    logType: 2,
                    userId: "",
                    userName: jsonObj.userName,
                    logTime: moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
                    region: jsonObj.bookRegion,
                    pool: jsonObj.bookPool,
                    adGroup: jsonObj.bookGroup,
                    agentName: jsonObj.agentName,
                    status: 0,
                    description: "Login On"
                };
                // add to DB
                dbHelper.add(params, "V_LOGS", function (err, result) {
                    if (err && err != null) {
                        console.log("Add User ON Error: " + err);
                    }
                });
            }

        }
    });
};
/**
 * add Quick Booking
 */
exports.addQuickBook = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);
    var start = moment(condition.BookStart).format("YYYY-MM-DD HH:mm:ss");
    var end = moment(condition.BookEnd).format("YYYY-MM-DD HH:mm:ss");

    var sql = "select a.*,b.regionID as prefix "
        + "from V_POOL as a left join V_REGION as b on a.region = b.id ";

    dbHelper.search(sql, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            var prefix = condition.AgentName.substring(0, 3);  // 机器的前缀 和 区域对应
            var identity = condition.AgentName.substring(9, 10); // 机器的 池 对应的身份 ID
            var selectpool = null;
            //console.log(result);
            /**
             * 快速预定的情况  根据机器名称判断 属于哪一个pool
             */
            for (var p = 0; p < result.length; p++) {
                var one = result[p];
                var preStr = one.prefix;// region 的前缀
                var ideStr = one.poolID;// 机器的第10位
                var flg1 = false;
                var flg2 = false;
                if (preStr != null && ideStr != null && preStr.indexOf(",") >= 0 && ideStr.indexOf(",") >= 0) {
                    var preStrs = preStr.split(",");
                    var ideStrs = ideStr.split(",");
                    for (var a = 0; a < preStrs.length; a++) {
                        if (prefix == preStrs[a]) {
                            flg1 = true;
                        }
                    }
                    for (var b = 0; b < ideStrs.length; b++) {
                        if (identity == ideStrs[b]) {
                            flg2 = true;
                        }
                    }
                }
                if (flg1 && flg2) {
                    selectpool = one;
                    break;
                }
            }
            console.log("************************* ADD Quick Booking *************************");
            var params = {
                bookType: condition.BookType,
                userId: condition.UserId,
                userName: condition.UserName,
                bookStart: start,
                bookEnd: end,
                bookRegion: (selectpool != null ? selectpool.region : ""),
                bookPool: (selectpool != null ? selectpool.id : ""),
                status: 1,
                agentName: condition.AgentName,
                description: condition.Description,
                remarks: condition.Remarks,
                useStart: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
            };
            console.log(params);
            // add to DB
            dbHelper.add(params, tableName, function (err, result) {
                if (err && err != null) {
                    console.log(err);
                    res.json(false);
                } else {
                    res.json(true);
                }
            });
        }
    });
};
/**
 * add extent time
 */
exports.addExtentTime = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);
    var start = moment(condition.BookStart).format("YYYY-MM-DD HH:mm:ss");
    var end = moment(condition.BookEnd).format("YYYY-MM-DD HH:mm:ss");

    console.log("************************* ADD Extent Time *************************");

    var params = {
        bookType: condition.BookType,
        userId: condition.UserId,
        userName: condition.UserName,
        bookStart: start,
        bookEnd: end,
        bookRegion: condition.BookRegion,
        bookPool: condition.BookPool,
        status: 1,
        agentName: condition.AgentName,
        description: condition.Description,
        remarks: condition.Remarks,
        useStart: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    };
    console.log(params);
    // add to DB
    dbHelper.add(params, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

/**
 *  Agent 心跳通信 ,统计使用时间
 */
exports.userHeartBeat = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);
    var start = moment(condition.BookStart).format("YYYY-MM-DD HH:mm:ss");
    var end = moment(condition.BookEnd).format("YYYY-MM-DD HH:mm:ss");

    var whereSql = "where bookId = @bookId";
    var whereParams = {bookId: condition.Id};

    dbHelper.select("V_BOOKING_USING", whereSql, whereParams, " order by bookStart", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            var minutes = 0;
            var BookID = 0;
            if (result.length > 0) {
                minutes = result[0].useMinutes;
                BookID = result[0].id
            } else {
                minutes = 0;
                BookID = 0;
            }
            var params = {
                bookId: condition.Id,
                userId: condition.UserId,
                userName: condition.UserName,
                bookStart: start,
                bookEnd: end,
                bookRegion: condition.BookRegion,
                bookPool: condition.BookPool,
                bookGroup: condition.BookGroup,
                agentName: "",
                useMinutes: minutes + 1,
                description: condition.Description,
                remarks: condition.Remarks
            };
            if (BookID == 0) {
                // add to DB
                dbHelper.add(params, "V_BOOKING_USING", function (err, result) {
                    if (err && err != null) {
                        console.log(err);
                        res.json(false);
                    } else {
                        res.json(true);
                    }
                });
            } else {
                var whereSql = "where id=" + BookID;
                // update DB
                dbHelper.modify(params, whereSql, "V_BOOKING_USING", function (err, result) {
                    if (err && err != null) {
                        console.log(err);
                        res.json(false);
                    } else {
                        res.json(true);
                    }
                });
            }

        }
    });


};
/**
 * force Cancel Login (Time expires)
 */
exports.forceLoginOff = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);

    /**
     * Agent退出时间
     */
    var params = {
        status: 2,
        useEnd: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    };
    var where = {id: condition.Id};
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log("Set booking login status error : " + err);
        } else {
            var logs = {
                logType: 3,
                userId: "",
                userName: condition.UserName,
                logTime: moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
                region: condition.BookRegion,
                pool: condition.BookPool,
                adGroup: condition.BookGroup,
                agentName: condition.AgentName,
                status: 0,
                description: "Be forced to logout"
            };
            // add to DB
            dbHelper.add(logs, "V_LOGS", function (err, result) {
                if (err && err != null) {
                    console.log("Add User OFF Error: " + err);
                }
            });
        }
    });
};
/**
 * Cancel Login
 */
exports.agentLoginOff = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var param = req.body.paramaters;
    var condition = JSON.parse(param);
    /**
     * Agent退出时间
     */
    var params = {
        status: 2,
        useEnd: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    };
    var where = {id: condition.Id};
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(" Cancel agent error: " + err);
        } else {
            // status=2  预定关闭
            var params = {
                status: 2
            };
            // 预定 及相关联的book都设置为 关闭
            var whereSql = "where id=" + condition.Id + " or bookType =" + condition.Id;
            // update DB
            dbHelper.modify(params, whereSql, tableName, function (err, result) {
                if (err && err != null) {
                    console.log(err);
                    res.json(false);
                } else {
                    res.json(true);
                    //  logType == 3  user login off
                    var logs = {
                        logType: 3,
                        userId: "",
                        userName: condition.UserName,
                        logTime: moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
                        region: condition.BookRegion,
                        pool: condition.BookPool,
                        adGroup: condition.BookGroup,
                        agentName: condition.AgentName,
                        status: 0,
                        description: "The normal user logout"
                    };
                    // add to DB
                    dbHelper.add(logs, "V_LOGS", function (err, result) {
                        if (err && err != null) {
                            console.log("Add User OFF Error: " + err);
                        }
                    });
                }
            });
        }

    });


};


