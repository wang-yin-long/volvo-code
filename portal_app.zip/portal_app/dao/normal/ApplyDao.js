var express = require('express');
var utilUrl = "../../routes/dbUtil.js";

var tableName = "V_APPLY";

exports.searchApply = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName, "", null, "", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });

};

exports.addApply = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    // sql params
    var params = {
        userID: condition.userID,
        userName: condition.userName,
        applyRegion: condition.applyRegion,
        applyPool: condition.applyPool,
        applyGroup: condition.applyGroup,
        status: condition.status,
        description: condition.description
    };
    // add to DB
    dbHelper.add(params, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateApply = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        status: condition.status
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


