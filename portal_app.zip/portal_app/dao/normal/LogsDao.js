var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_LOGS";

exports.searchLogs = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName, "where logType = 1", null, " order by logTime desc", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};


exports.searchEventLogs = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName, "where logType > 1", null, " order by logTime desc", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchOneLog = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "where id = @id";
    var whereParams = {id: condition.id};

    dbHelper.select(tableName, whereSql, whereParams, "", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.addLogs = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        logType: condition.logType,
        userId: condition.userId,
        userName: condition.userName,
        logTime: condition.logTime,
        region: condition.region,
        pool: condition.pool,
        adGroup: condition.adGroup,
        agentName: condition.agentName,
        status: condition.status,
        description: condition.description
    };
    // add to DB
    dbHelper.add(params, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateLogs = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        status: condition.status
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};

exports.delLogs = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "where id = @id";
    var whereParams = {id: condition.id};
    // delete DB
    dbHelper.del(whereSql, whereParams, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


