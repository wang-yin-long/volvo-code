var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_BOOKING";

exports.searchBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "";
    dbHelper.select(tableName, whereSql, null, " order by bookStart desc", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchNextBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "";
    dbHelper.select(tableName, whereSql, null, " order by bookStart", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchAllBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "";
    dbHelper.select(tableName, whereSql, null, " order by bookStart desc", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchOneBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "where id = @id";
    var whereParams = {id: condition.id};

    dbHelper.select(tableName, whereSql, whereParams, "", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.addBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        userId: condition.userId,
        userName: condition.userName,
        bookStart: condition.bookStart,
        bookEnd: condition.bookEnd,
        bookRegion: condition.bookRegion,
        bookPool: condition.bookPool,
        status: condition.status,
        description: condition.description
    };
    console.log(params);
    // add to DB
    dbHelper.add(params, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.addQuickBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        bookType: 1,
        userId: condition.userId,
        userName: condition.userName,
        bookStart: condition.bookStart,
        bookEnd: condition.bookEnd,
        bookRegion: condition.bookRegion,
        bookPool: condition.bookPool,
        status: condition.status,
        description: condition.description,
        useStart: condition.useStart
    };
    // console.log(params);
    // add to DB
    dbHelper.add(params, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        bookStart: condition.bookStart,
        bookEnd: condition.bookEnd,
        bookRegion: condition.bookRegion,
        bookPool: condition.bookPool,
        description: condition.description
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateBookingDes = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        description: condition.description
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateLoginBook = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        status: condition.status,
        agentName: condition.agentName,
        remarks: condition.remarks,
        useStart: condition.useStart
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};

exports.delBooking = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "where id = @id";
    var whereParams = {id: condition.id};
    // delete DB
    dbHelper.del(whereSql, whereParams, tableName, function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};
// 使用中book信息
exports.searchBookUsing = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "";
    dbHelper.select("V_BOOKING_USING", whereSql, null, " order by bookStart", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};


