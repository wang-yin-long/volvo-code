var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_ELSE_CONFIG";

exports.searchAgentTime = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;

    dbHelper.select(tableName,"",null,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });

};

exports.addAgentTime = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    // sql params
    var params={
        code:condition.code,
        dataKey:condition.dataKey,
        value:condition.value,
        remarks:condition.remarks
    };
    // add to DB
    dbHelper.add(params,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateAgentTime = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params={
        code:condition.code,
        dataKey:condition.dataKey,
        value:condition.value,
        remarks:condition.remarks
    };
    var where={id:condition.id};
    // update DB
    dbHelper.update(params,where,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


