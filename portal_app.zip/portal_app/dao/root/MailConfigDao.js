var express = require('express');
var utilUrl = "../../routes/dbUtil.js";

exports.searchMailInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var adInfo = req.body;

    dbHelper.select("V_MAIL", "", null, "", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });

};

exports.addMailInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    // sql params
    var params = {
        type: condition.type,
        userName: condition.userName,
        passWord: condition.passWord,
        ip: condition.ip,
        remarks: condition.remarks
    };
    // add to DB
    dbHelper.add(params, "V_MAIL", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateMailInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        userName: condition.userName,
        passWord: condition.passWord,
        ip: condition.ip,
        remarks: condition.remarks
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, "V_MAIL", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.resetUcpRoot = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        passWord: condition.passWord,
    };
    var where = {id: condition.id};
    // update DB
    dbHelper.update(params, where, "V_MAIL", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.delMailInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql = "where id = @id";
    var whereParams = {id: condition.id};
    // delete DB
    dbHelper.del(whereSql, whereParams, "V_MAIL", function (err, result) {
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


