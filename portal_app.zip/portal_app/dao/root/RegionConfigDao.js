var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_REGION";

exports.searchRegionList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName,"",null,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchOneRegion = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql="where id = @id";
    var whereParams={ id:condition.id };

    dbHelper.select(tableName,whereSql,whereParams,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.addRegionList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    // sql params
    var params={
        regionID:condition.regionID,
        regionName:condition.regionName,
        description:condition.description,
        remarks:condition.remarks
    };
    // add to DB
    dbHelper.add(params,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateRegionList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params={
        regionID:condition.regionID,
        regionName:condition.regionName,
        description:condition.description,
        remarks:condition.remarks
    };
    var where={id:condition.id};
    // update DB
    dbHelper.update(params,where,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};

exports.delRegionList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;

    var whereSql="where id = @id";
    var whereParams={ id:condition.id };
    // delete DB
    dbHelper.del(whereSql, whereParams, tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


