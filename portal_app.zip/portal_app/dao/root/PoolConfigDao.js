var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_POOL";

exports.searchPoolList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName,"",null,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchOnePool = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql="where id = @id";
    var whereParams={ id:condition.id };

    dbHelper.select(tableName,whereSql,whereParams,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.addPoolList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        poolType:condition.poolType,
        poolID:condition.poolID,
        poolCode:condition.poolCode,
        poolName:condition.poolName,
        maxUser:condition.maxUser,
        region:condition.region,
        status:condition.status,
        description:condition.description
    };
    // add to DB
    dbHelper.add(params,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updatePoolList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        poolType:condition.poolType,
        poolID:condition.poolID,
        poolCode:condition.poolCode,
        poolName:condition.poolName,
        maxUser:condition.maxUser,
        region:condition.region,
        status:condition.status,
        description:condition.description
    };
    var where={id:condition.id};
    // update DB
    dbHelper.update(params,where,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};

exports.delPoolList = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;

    var whereSql="where id = @id";
    var whereParams={ id:condition.id };
    // delete DB
    dbHelper.del(whereSql, whereParams, tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


