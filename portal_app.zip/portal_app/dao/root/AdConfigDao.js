var express = require('express');
var utilUrl = "../../routes/dbUtil.js";

exports.searchADInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var adInfo = req.body;
    console.log(adInfo);

    dbHelper.select("V_AD","",null,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });

};

exports.saveInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var adInfo = req.body;
    console.log(adInfo);
    // sql params
    var params={
        userName:adInfo.userName,
        passWord:adInfo.passWord,
        path:adInfo.path,
        remarks:adInfo.remarks
    };
    // add to DB
    dbHelper.add(params,"V_AD",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateADInfo = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    console.log(condition);

    var params={
        userName:condition.userName,
        passWord:condition.passWord,
        path:condition.path,
        remarks:condition.remarks
    };
    var where={id:condition.id};
    // update DB
    dbHelper.update(params,where,"V_AD",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


