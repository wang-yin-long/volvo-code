var express = require('express');
var utilUrl = "../../routes/dbUtil.js";
/**
 * data table name
 * @type {string}
 */
var tableName = "V_AD_GROUP";

exports.searchAdGroup = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    dbHelper.select(tableName,"",null,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.searchOneAdGroup = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var whereSql="where id = @id";
    var whereParams={ id:condition.id };

    dbHelper.select(tableName,whereSql,whereParams,"",function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json("Error");
        } else {
            res.json(result);
        }
    });
};

exports.addAdGroup = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        groupID:condition.groupID,
        groupName:condition.groupName,
        region:condition.region,
        pool:condition.pool,
        description:condition.description
    };
    // add to DB
    dbHelper.add(params,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });
};

exports.updateAdGroup = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;
    var params = {
        groupID:condition.groupID,
        groupName:condition.groupName,
        region:condition.region,
        pool:condition.pool,
        description:condition.description
    };
    var where={id:condition.id};
    // update DB
    dbHelper.update(params,where,tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};

exports.delAdGroup = function (req, res) {
    var dbHelper = require(utilUrl);
    // data
    var condition = req.body;

    var whereSql="where id = @id";
    var whereParams={ id:condition.id };
    // delete DB
    dbHelper.del(whereSql, whereParams, tableName,function(err,result){
        if (err && err != null) {
            console.log(err);
            res.json(false);
        } else {
            res.json(true);
        }
    });

};


