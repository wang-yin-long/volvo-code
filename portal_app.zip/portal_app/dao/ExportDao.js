var path = require('path');
var fs = require("fs");
var utilUrl = "../routes/exportUtil.js";
var dbUtilUrl = "../routes/dbUtil.js";

/**
 * User Statistic 导出 Excel 文件
 * @param req
 * @param res
 */
exports.exportExcel = function (req, res) {

    var excel = require(utilUrl);// 导出文件 Util

    var Start_condi = req.query.start;
    var End_condi = req.query.end;
    var Name_condi = req.query.userName;

    var dbHelper = require(dbUtilUrl);// 数据库操作 Util
    var sql = "select distinct a.*,b.regionName as bookRegionName,c.poolName as bookPoolName "
        + "from V_BOOKING_USING as a left join V_REGION as b on a.bookRegion = b.id "
        + "left join  V_POOL as c on a.bookPool = c.id order by a.bookStart "

    dbHelper.search(sql, function (err, result) {
        if (err && err != null) {
            console.log(err);
        } else {
            var books = [];
            // 按 时间段 筛选 数据
            for (var i = 0; i < result.length; i++) {
                var one = result[i];
                var s_book = one.bookStart.valueOf();
                // 用户名不选,导出全部信息
                if (Name_condi + "" == "0") {
                    if (s_book >= Start_condi && s_book <= End_condi) {
                        books.push(one);
                    }
                } else {
                    if (s_book >= Start_condi && s_book <= End_condi && Name_condi == one.userName) {
                        books.push(one);
                    }
                }
            }
            console.log("222222222");
            console.log(books);
            var rows_data = [];
            for (var j = 0; j < books.length; j++) {
                var book = books[j];
                var one_row = [];
                one_row.push((j + 1).toString());// 序号
                one_row.push(book.bookId.toString());
                one_row.push(book.userId);
                one_row.push(book.userName);
                one_row.push(book.bookStart != null ? book.bookStart.toLocaleString() : "");
                one_row.push(book.bookEnd != null ? book.bookEnd.toLocaleString() : "");
                one_row.push(book.bookRegionName != null ? book.bookRegionName.toString() : "");
                one_row.push(book.bookPoolName != null ? book.bookPoolName.toString() : "");
                // one_row.push(book.bookGroup.toString());// AD域 组名
                one_row.push(book.agentName);
                one_row.push(book.useMinutes != null ? book.useMinutes.toString() : "");
                one_row.push(book.description);

                rows_data.push(one_row);
            }
            var conf = {};
            conf.cols = [
                {caption: 'NO', type: 'string'},
                {caption: 'BOOK ID', type: 'string'},
                {caption: 'USER ID', type: 'string'},
                {caption: 'USER NAME', type: 'string'},
                {caption: 'BOOK START', type: 'string'},
                {caption: 'BOOK END', type: 'string'},
                {caption: 'BOOK REGION', type: 'string'},
                {caption: 'BOOK POOL', type: 'string'},
                {caption: 'Agent NAME', type: 'string'},
                {caption: 'Using MINUTES', type: 'string'},
                {caption: 'DESCRIPTION', type: 'string'}
            ];
            conf.rows = rows_data;
            var filepath =  path.resolve(__dirname, '..');
            console.log(filepath + "/files/");

            var filename = "UserStatistics.xls";
            res.setHeader('Content-Disposition', 'attachment; filename=' + encodeURIComponent(filename));
            excel.createExcel({
                data: conf,
                savePath: filepath + "/files/",
                cb: function (path) {
                    // console.log(path);
                    excel.download(path, req, res, true);
                }
            });
        }
    });

}