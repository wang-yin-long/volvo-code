var mssql = require('mssql');
var express = require('express');
var sqlConfig = require('../config');
var fs = require('fs');
var log = require('./../libs/log');

var config = sqlConfig.connSQLServer;
/**
 * @param user
 * @param password
 * @param server
 * @param database
 */
var initConfig = function (user, password, server, database) {
    config = sqlConfig.connSQLServer;
};

/**
 *
 */
var restoreDefaults = function () {
    config = sqlConfig.connSQLServer;
};

/**
 * @param sql
 * @params
 * @param callBack(err,recordset)
 */
var querySql = function (sql, params, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        if (params != "") {
            for (var index in params) {
                if (typeof params[index] == "number") {
                    ps.input(index, mssql.Int);
                } else if (typeof params[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                }
            }
        }
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute(params, function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param tableName
 * @param topNumber
 * @param whereSql
 * @param params
 * @param orderSql
 * @param callBack
 */
var select = function (tableName, whereSql, params, orderSql, callBack) {

    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;

    //console.log(config);
    console.time("New Connection To SqlServer");

    var connection = new mssql.Connection(config, function (err) {

        console.timeEnd("New Connection To SqlServer");

        console.time("PreparedStatement SqlServer Config");

        var ps = new mssql.PreparedStatement(connection);

        console.timeEnd("PreparedStatement SqlServer Config");

        console.time("prepare from SqlServer");

        var sql = "select * from " + tableName + " ";
        sql += whereSql + " ";
        if (params != "" && params != null) {
            for (var index in params) {
                if (typeof params[index] == "number") {
                    ps.input(index, mssql.Int);
                } else if (typeof params[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                }
            }
        }
        sql += orderSql;

        console.log(sql);

        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);

            console.timeEnd("prepare from SqlServer");

            console.time("Execute Sql On SqlServer");

            ps.execute(params, function (err, recordset) {

                console.timeEnd("Execute Sql On SqlServer");

                console.time("CallBack To Client");

                callBack(err, recordset);

                console.timeEnd("CallBack To Client");

                console.log("------------------------------------------------------");
                ps.unprepare(function (err) {

                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param tableName
 * @param callBack
 */
var selectAll = function (tableName, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        var sql = "select * from " + tableName + " ";
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute("", function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param addObj
 * @param tableName
 * @param callBack
 */
var add = function (addObj, tableName, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        var sql = "insert into " + tableName + "(";
        if (addObj != "") {
            for (var index in addObj) {
                if (typeof addObj[index] == "number") {
                    ps.input(index, mssql.Int);
                } else if (typeof addObj[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                }
                sql += index + ",";
            }
            sql = sql.substring(0, sql.length - 1) + ") values(";
            for (var index in addObj) {
                if (typeof addObj[index] == "number") {
                    sql += addObj[index] + ",";
                } else if (typeof addObj[index] == "string") {
                    sql += "'" + addObj[index] + "'" + ",";
                } else if (typeof addObj[index] == "object") {
                    sql += addObj[index] + ",";
                }
            }
        }
        sql = sql.substring(0, sql.length - 1) + ")";
        console.log(sql);
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute(addObj, function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param updateObj
 * @param whereObj
 * @param tableName
 * @param callBack
 */
var update = function (updateObj, whereObj, tableName, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        var sql = "update " + tableName + " set ";
        if (updateObj != "") {
            for (var index in updateObj) {
                if (typeof updateObj[index] == "number") {
                    ps.input(index, mssql.Int);
                    sql += index + "=" + updateObj[index] + ",";
                } else if (typeof updateObj[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                    sql += index + "=" + "'" + updateObj[index] + "'" + ",";
                }
            }
        }
        sql = sql.substring(0, sql.length - 1) + " where ";
        if (whereObj != "") {
            for (var index in whereObj) {
                if (typeof whereObj[index] == "number") {
                    ps.input(index, mssql.Int);
                    sql += index + "=" + whereObj[index] + " and ";
                } else if (typeof whereObj[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                    sql += index + "=" + "'" + whereObj[index] + "'" + " and ";
                }
            }
        }
        sql = sql.substring(0, sql.length - 5);
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute(updateObj, function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param modifyObj
 * @param whereObj
 * @param tableName
 * @param callBack
 */
var modify = function (updateObj, whereSql, tableName, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        var sql = "update " + tableName + " set ";
        if (updateObj != "") {
            for (var index in updateObj) {
                if (typeof updateObj[index] == "number") {
                    ps.input(index, mssql.Int);
                    sql += index + "=" + updateObj[index] + ",";
                } else if (typeof updateObj[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                    sql += index + "=" + "'" + updateObj[index] + "'" + ",";
                }
            }
        }
        sql = sql.substring(0, sql.length - 1) + whereSql;

        console.log(sql);

        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute(updateObj, function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *  search only by sql
 */
var search = function (sql, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        console.log(sql);
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute("", function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

/**
 *
 * @param whereSql
 * @param params
 * @param tableName
 * @param callBack
 */
var del = function (whereSql, params, tableName, callBack) {
    var sqlConfig = require('../config');
    config = sqlConfig.connSQLServer;
    var connection = new mssql.Connection(config, function (err) {
        var ps = new mssql.PreparedStatement(connection);
        var sql = "delete from " + tableName + " ";
        if (params != "") {
            for (var index in params) {
                if (typeof params[index] == "number") {
                    ps.input(index, mssql.Int);
                } else if (typeof params[index] == "string") {
                    ps.input(index, mssql.NVarChar);
                }
            }
        }
        sql += whereSql;
        ps.prepare(sql, function (err) {
            if (err)
                console.log(err);
            ps.execute(params, function (err, recordset) {
                callBack(err, recordset);
                ps.unprepare(function (err) {
                    if (err)
                        console.log(err);
                });
            });
        });
    });
    restoreDefaults();
};

exports.initConfig = initConfig;
exports.config = config;
exports.del = del;
exports.select = select;
exports.search = search;
exports.update = update;
exports.modify = modify;
exports.querySql = querySql;
exports.restoreDefaults = restoreDefaults;
exports.selectAll = selectAll;
exports.add = add;