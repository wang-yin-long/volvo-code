var express = require('express');
var path = require('path');
var config = require('../config');
var utilUrl = "./dbUtil.js";

exports.login = function (req, res) {
    var condition = req.body;
    var admin = condition.adConfig;

    // ldap  check userName and pwd
    var ldap = require("ldapjs");
    console.log("------------------ AD Info ------------------");
    console.log(admin);
    if (admin == null) {
        res.json(false);
        return;
    }

    var client = ldap.createClient({
        url: 'ldap://' + admin.path + ':' + config.adPort
    });
    var opts = {
        filter: '(cn=' + condition.name + ')',
        scope: 'sub',
        timeLimit: 500,
    };
    // bind client and LDAP Server
    client.bind(admin.userName + config.adMail, admin.passWord, function (err, res1) {

        client.bind(condition.name + config.adMail, condition.password, function (err, res3) {
            if (err != null) {
                res.json(false);
                req.session["loginUser"] = null;
                client.unbind();
            } else {
                client.search(config.adPath, opts, function (error, res2) {
                    res2.on('searchEntry', function (entry) {
                        var user = entry.object;
                        res.json(true);
                        // bind user to session
                        var obj = new Object();

                        // 2016-08-03  用户名都改为大写
                        obj.loginName = user.name.toUpperCase();
                        obj.loginID = user.userPrincipalName;
                        obj.urgentFlg = "1";
                        req.session["loginUser"] = obj;

                        client.unbind();
                    });
                    res2.on('searchReference', function (referral) {
                        console.log('reference: ' + referral.uris.join());
                    });
                    res2.on('error', function (err) {
                        console.log('error: ' + err.message);
                        res.json(false);
                    });
                    res2.on('end', function (result) {
                        console.log('status: ' + result);
                    });
                });
            }
        });

    });


};

exports.bizLogin = function (req, res) {
    var dbHelper = require(utilUrl);
    var condition = req.body;
    // console.log(condition);
    var whereSql = "where type = @type and userName = @userName ";
    // type == 2 bizAdmin
    var whereParams = {type: 2, userName: condition.name};
    // console.log(condition);
    dbHelper.select("V_MAIL", whereSql, whereParams, "", function (err, result) {
        if (result && result.length > 0) {
            // console.log(result);
            var obj = new Object();
            obj.loginName = result[0].userName;
            obj.loginID = result[0].id;
            obj.urgentFlg = "1";
            req.session["loginUser"] = obj;
            res.json(true);
        } else {
            console.log(err);
            res.json(false);
        }
    });
};

exports.rootLogin = function (req, res) {
    var dbHelper = require(utilUrl);
    var condition = req.body;
    var whereSql = "where type = @type and userName = @userName ";
    // type == 1 rootAdmin
    var whereParams = {type: 1, userName: condition.name};
    // console.log(condition);
    dbHelper.select("V_MAIL", whereSql, whereParams, "", function (err, result) {
        if (result && result.length > 0) {
            var obj = new Object();
            obj.loginName = result[0].userName;
            obj.loginID = result[0].id;
            obj.urgentFlg = "1";
            req.session["loginUser"] = obj;
            res.json(true);
        } else {
            console.log(err);
            res.json(false);
        }
    });
};

exports.rootAccount = function (req, res) {
    var dbHelper = require(utilUrl);
    var condition = req.body;
    var whereSql = "where type = @type and userName = @userName and passWord = @passWord";
    // type == 1 rootAdmin
    var whereParams = {type: 3, userName: condition.name, passWord: condition.password};
    // console.log(condition);
    dbHelper.select("V_MAIL", whereSql, whereParams, "", function (err, result) {
        if (result && result.length > 0) {
            var obj = new Object();
            obj.loginName = result[0].userName;
            obj.loginID = result[0].id;
            obj.urgentFlg = "1";
            req.session["loginUser"] = obj;
            res.json(true);
        } else {
            console.log(err);
            res.json(false);
        }
    });
};


exports.logout = function (req, res) {
    req.session["loginUser"] = null;
};

exports.searchLogin = function (req, res) {
    var user = req.session["loginUser"];
    if (user) {
        res.json(user);
    } else {
        res.json(null);
    }
};


