/**
 * To change this template use File | Settings | File Templates.
 */
var index = require('./index');
var user = require('./user');
var adConfigDao = require('../dao/root/AdConfigDao.js');
var mailCfgDao = require('../dao/root/MailConfigDao.js');
var regionConfigDao = require('../dao/root/RegionConfigDao.js');
var poolConfigDao = require('../dao/root/PoolConfigDao.js');
var groupConfigDao = require('../dao/root/AdGroupConfigDao.js');
var agentTimeDao = require('../dao/root/AgentTimeConfigDao.js');

var applyDao = require('../dao/normal/ApplyDao.js');
var bookingDao = require('../dao/normal/BookingDao.js');
var logsDao = require('../dao/normal/LogsDao.js');

var interfaceDao = require('../dao/InterfaceDao.js');
var exportDao = require('../dao/ExportDao.js');
var bookExportDao = require('../dao/BookExportDao.js');

module.exports = function (app) {
    app.get('/', index.index);
    app.post('/login', user.login);
    app.post('/bizLogin', user.bizLogin);
    app.post('/rootLogin', user.rootLogin);
    app.post('/searchLogin', user.searchLogin);
    /**
     *  root Account Admin
     */
    app.post('/rootAccount', user.rootAccount);
    /**
     *  root AD Config
     */
    app.post('/addADInfo', adConfigDao.saveInfo);
    app.post('/searchADInfo', adConfigDao.searchADInfo);
    app.post('/updateADInfo', adConfigDao.updateADInfo);
    /**
     * root Mail Config
     */
    app.post('/searchMailInfo', mailCfgDao.searchMailInfo);
    app.post('/addMailInfo', mailCfgDao.addMailInfo);
    app.post('/updateMailInfo', mailCfgDao.updateMailInfo);
    app.post('/delMailInfo', mailCfgDao.delMailInfo);
    app.post('/resetUcpRoot', mailCfgDao.resetUcpRoot);
    /**
     * root Region Config
     */
    app.post('/searchRegionList', regionConfigDao.searchRegionList);
    app.post('/searchOneRegion', regionConfigDao.searchOneRegion);
    app.post('/addRegionList', regionConfigDao.addRegionList);
    app.post('/updateRegionList', regionConfigDao.updateRegionList);
    app.post('/delRegionList', regionConfigDao.delRegionList);
    /**
     * root Pool Config
     */
    app.post('/searchPoolList', poolConfigDao.searchPoolList);
    app.post('/searchOnePool', poolConfigDao.searchOnePool);
    app.post('/addPoolList', poolConfigDao.addPoolList);
    app.post('/updatePoolList', poolConfigDao.updatePoolList);
    app.post('/delPoolList', poolConfigDao.delPoolList);
    /**
     * root AD Group Config
     */
    app.post('/searchAdGroup', groupConfigDao.searchAdGroup);
    app.post('/searchOneAdGroup', groupConfigDao.searchOneAdGroup);
    app.post('/addAdGroup', groupConfigDao.addAdGroup);
    app.post('/updateAdGroup', groupConfigDao.updateAdGroup);
    app.post('/delAdGroup', groupConfigDao.delAdGroup);
    /**
     *  About Time Config (Else Config)
     */
    app.post('/searchAgentTime', agentTimeDao.searchAgentTime);
    app.post('/addAgentTime', agentTimeDao.addAgentTime);
    app.post('/updateAgentTime', agentTimeDao.updateAgentTime);
    /**
     *  normal Apply
     */
    app.post('/searchApply', applyDao.searchApply);
    app.post('/addApply', applyDao.addApply);
    app.post('/updateApply', applyDao.updateApply);
    /**
     * normal Booking
     */
    app.post('/searchBooking', bookingDao.searchBooking);
    app.post('/searchNextBooking', bookingDao.searchNextBooking);
    app.post('/searchAllBooking', bookingDao.searchAllBooking);
    app.post('/searchOneBooking', bookingDao.searchOneBooking);
    app.post('/addBooking', bookingDao.addBooking);
    app.post('/addQuickBooking', bookingDao.addQuickBooking);
    app.post('/updateBooking', bookingDao.updateBooking);
    app.post('/updateBookingDes', bookingDao.updateBookingDes);
    app.post('/updateLoginBook', bookingDao.updateLoginBook);
    app.post('/delBooking', bookingDao.delBooking);

    app.post('/searchBookUsing', bookingDao.searchBookUsing);
    /**
     * normal logs
     */
    app.post('/searchLogs', logsDao.searchLogs);
    app.post('/searchEventLogs', logsDao.searchEventLogs);
    app.post('/searchOneLog', logsDao.searchOneLog);
    app.post('/addLogs', logsDao.addLogs);
    app.post('/updateLogs', logsDao.updateLogs);
    app.post('/delLogs', logsDao.delLogs);
    /**
     * Interface Dao
     */
    app.post('/getuserbooks', interfaceDao.getuserbooks);// 获取当前时间用户对应的预定信息
    app.post('/userHeartBeat', interfaceDao.userHeartBeat);// 心跳通信
    app.post('/agentLoginOff', interfaceDao.agentLoginOff);// agent用户下线
    app.post('/forceLoginOff', interfaceDao.forceLoginOff);// agent用户强制下线
    app.post('/addQuickBook', interfaceDao.addQuickBook);// agent端添加快速预定
    app.post('/addExtentTime', interfaceDao.addExtentTime);// agent端添加快速预定
    /**
     * user statistic Export Dao
     */
    app.get('/exportExcel', exportDao.exportExcel);
    /**
     * booking Export Dao
     */
    app.get('/bookingExport', bookExportDao.exportExcel);


};