/**
 * SqlServer connect
 * To change this template use File | Settings | File Templates.
 */
module.exports = {

    connSQLServer: {
        server: '192.168.96.247',
        port: '1433',
        database: 'portalDBQA',
        user: 'portal_user_QA',
        password: 'VDIpilot@001',
        options: {
            encrypt: true
        },
        pool: {
            max:10,
            min: 0,
            idleTimeoutMillis: 30000
        }
    },
    adPath: 'cn=Users,dc=test,dc=com',
    adMail: '@test.com',
    adPort: '389'

    //connSQLServer: {
    //    server: 'jiasvw3006.jia.volvocars.net',
    //    port: '1433',
    //    database: 'portalDBQA',
    //    user: 'portal_user_QA',
    //    password: 'VDIpilot@001',
    //    options: {
    //        encrypt: true
    //    },
    //    pool: {
    //        min: 0,
    //        idleTimeoutMillis: 30000
    //    }
    //},
    //adPath: 'dc=vccnet,dc=volvocars,dc=net',
    //adMail: '@volvocars.com',
    //adPort: '389'
};