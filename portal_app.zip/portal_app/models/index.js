var express = require('express');
var mongoose = require('mongoose');
var mssql = require('mssql');
var config = require('../config');
var fs = require('fs');
var log = require('./../libs/log');

var connection = new mssql.Connection(config.connSQLServer, function (err) {
    var ps = new mssql.PreparedStatement(connection);
    var sql = "SELECT Name FROM SysDatabases ORDER BY Name";
    ps.prepare(sql, function (err) {
        if (err){
            console.log(err);
        }
        ps.execute(null, function (err, data) {
            if (data && data.length > 0) {
                console.log("------Connect SqlServer Success------");
            }
        });
    });
});

var models_path = __dirname + '/../models/mapping'
fs.readdirSync(models_path).forEach(function (file) {
    require(models_path + '/' + file);
    var modelName = file.replace('Model.js', '');
    exports[modelName] = mongoose.model(modelName);
});
