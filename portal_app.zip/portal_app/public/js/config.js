/**
 * Module: config.js
 * App routes and resources configuration
 */
App.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', 'RouteHelpersProvider',
    function ($stateProvider, $locationProvider, $urlRouterProvider, helper) {
        'use strict';

        /**
         *  Set the following to true to enable the HTML5 Mode
         *  You may have to set <base> tag in index and a routing configuration in your server
         */
        $locationProvider.html5Mode(false);

        /**
         * defaults to dashboard
         */
        $urlRouterProvider.otherwise('/page/login');

        /**
         *  Application Routes
         */
        $stateProvider

            .state('page', {
                url: '/page',
                templateUrl: 'pages/page.html',
                controller: ["$rootScope", function ($rootScope) {
                    $rootScope.app.layout.isBoxed = false;
                }]
            })
            /**
             *  add menus html
             */
            .state('app', {
                url: '/app',
                abstract: true,
                templateUrl: helper.basepath('common/app.html'),
                controller: 'AppController',
                resolve: helper.resolveFor('fastclick', 'modernizr', 'icons', 'screenfull', 'animo', 'sparklines', 'slimscroll', 'classyloader', 'toaster', 'whirl')
            })
            .state('page.login', {
                url: '/login',
                title: "Login",
                templateUrl: 'pages/loginuser.html',
                resolve: helper.resolveFor('ngDialog', 'icons')
            })
            .state('bizAdmin', {
                url: '/biz',
                title: "bizAdmin",
                templateUrl: 'pages/loginnormal.html',
                resolve: helper.resolveFor('ngDialog', 'icons')
            })
            .state('rootAdmin', {
                url: '/admin',
                title: "RootAdmin",
                templateUrl: 'pages/loginroot.html',
                resolve: helper.resolveFor('ngDialog', 'icons')
            })

            /**
             * normal user
             */
            .state('app.home', {
                url: '/home',
                title: 'home',
                templateUrl: helper.basepath('volvo/home.html'),
                resolve: helper.resolveFor('ngDialog')
            })
            .state('app.mybooking', {
                url: '/mybooking',
                title: 'mybooking',
                templateUrl: helper.basepath('volvo/mybooking.html'),
                resolve: helper.resolveFor('ngTable', 'ngDialog')
            })
            .state('app.mybookingdetail', {
                url: '/mybookingdetail?mybookingid',
                title: 'mybookingdetail',
                templateUrl: helper.basepath('volvo/mybookingdetail.html')
            })

            .state('app.resources', {
                url: '/resources',
                title: 'resources',
                templateUrl: helper.basepath('volvo/resources.html')
            })
            .state('app.quickbooking', {
                url: '/quickbooking?userpoolid',
                title: 'quickbooking',
                templateUrl: helper.basepath('volvo/quickbookconfirm.html')
            })
            .state('app.nomalbooking', {
                url: '/nomalbooking?userpoolid',
                title: 'nomalbooking',
                templateUrl: helper.basepath('volvo/nomalbookconfirm.html'),
                resolve: helper.resolveFor('ngDialog', 'jquery-ui', 'jquery-ui-widgets', 'moment', 'fullcalendar')
            })
            .state('app.userprofile', {
                url: '/userprofile',
                title: 'userprofile',
                templateUrl: helper.basepath('volvo/userprofile.html')
            })
            .state('app.apply', {
                url: '/apply',
                title: 'apply',
                templateUrl: helper.basepath('volvo/apply.html')
            })

            /**
             * root admin
             */
            .state('root', {
                url: '/root',
                abstract: true,
                templateUrl: helper.basepath('common/root.html'),
                controller: 'AppController',
                resolve: helper.resolveFor('fastclick', 'modernizr', 'icons', 'screenfull',
                    'animo', 'sparklines', 'slimscroll', 'classyloader', 'toaster', 'whirl')
            })
            .state('root.adconfig', {
                url: '/adconfig',
                title: 'adconfig',
                templateUrl: helper.basepath('root/adconfig.html'),
                resolve: helper.resolveFor('ngDialog'),
            })
            .state('root.mailaccout', {
                url: '/mailaccout',
                title: 'mailaccout',
                templateUrl: helper.basepath('root/mailaccout.html')
            })
            .state('root.regionconfig', {
                url: '/regionconfig',
                title: 'regionconfig',
                templateUrl: helper.basepath('root/regionconfig.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })
            .state('root.poolconfig', {
                url: '/poolconfig',
                title: 'poolconfig',
                templateUrl: helper.basepath('root/poolconfig.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })
            .state('root.adgroupconfig', {
                url: '/adgroupconfig',
                title: 'adgroupconfig',
                templateUrl: helper.basepath('root/adgroupconfig.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })
            .state('root.detailgroup', {
                url: '/detailgroup?adgroupid',
                title: 'detailgroup',
                templateUrl: helper.basepath('root/detailgroup.html')
            })
            .state('root.detailpool', {
                url: '/detailpool?poolid',
                title: 'detailpool',
                templateUrl: helper.basepath('root/detailpool.html'),
                resolve: helper.resolveFor('ngDialog')
            })
            .state('root.detailregion', {
                url: '/detailregion?regionId',
                title: 'detailregion',
                templateUrl: helper.basepath('root/detailregion.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')

            })
            .state('root.agenttime', {
                url: '/agenttime',
                title: 'agenttime',
                templateUrl: helper.basepath('root/agenttime.html')
            })
            .state('root.mailaddress', {
                url: '/mailaddress',
                title: 'mailaddress',
                templateUrl: helper.basepath('root/mailaddress.html'),
                resolve: helper.resolveFor('ngDialog'),
            })
            .state('root.faqcalladmin', {
                url: '/faqcalladmin',
                title: 'faqcalladmin',
                templateUrl: helper.basepath('root/faqcalladmin.html')
            })
            .state('root.eventLogs', {
                url: '/eventLogs',
                title: 'eventLogs',
                templateUrl: helper.basepath('root/eventlogs.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })

            /**
             * Business admin
             */
            .state('biz', {
                url: '/biz',
                abstract: true,
                templateUrl: helper.basepath('common/normal.html'),
                controller: 'AppController',
                resolve: helper.resolveFor('fastclick', 'modernizr', 'icons', 'screenfull', 'animo', 'sparklines', 'slimscroll', 'classyloader', 'toaster', 'whirl')
            })
            .state('biz.policymanage', {
                url: '/policymanage',
                title: 'policymanage',
                templateUrl: helper.basepath('normal/policymanage.html')
            })
            .state('biz.applylist', {
                url: '/applylist',
                title: 'applylist',
                templateUrl: helper.basepath('normal/applylist.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })

            .state('biz.logs', {
                url: '/logs',
                title: 'logs',
                templateUrl: helper.basepath('normal/logs.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })
            .state('biz.booklist', {
                url: '/booklist',
                title: 'booklist',
                templateUrl: helper.basepath('normal/booklist.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })
            .state('biz.bookdetail', {
                url: '/bookdetail?bookingid',
                title: 'bookdetail',
                templateUrl: helper.basepath('normal/bookingdetail.html')
            })
            .state('biz.agentusers', {
                url: '/agentusers',
                title: 'agentusers',
                templateUrl: helper.basepath('normal/agentusers.html'),
                resolve: helper.resolveFor('ngDialog', 'ngTable')
            })

            .state('biz.resourcechart', {
                url: '/resourcechart',
                title: 'resourcechart',
                templateUrl: helper.basepath('normal/resourcechart.html'),
                resolve: helper.resolveFor('ngDialog','chartjs', 'ngTable', 'flot-chart', 'flot-chart-plugins')
            })
            .state('biz.userstatistic', {
                url: '/statistic',
                title: 'statistic',
                templateUrl: helper.basepath('normal/userstatistic.html'),
                resolve: helper.resolveFor('chartjs','ngDialog','flot-chart','flot-chart-plugins','localytics.directives')
            })

            /**
             * Single Page Routes
             */
            .state('page.register', {
                url: '/register',
                title: "Register",
                templateUrl: 'app/pages/register.html'
            })
            .state('page.recover', {
                url: '/recover',
                title: "Recover",
                templateUrl: 'app/pages/recover.html'
            })
            .state('page.lock', {
                url: '/lock',
                title: "Lock",
                templateUrl: 'app/pages/lock.html'
            })
            .state('page.404', {
                url: '/404',
                title: "Not Found",
                templateUrl: 'app/pages/404.html'
            })
        ;


    }]).config(['$ocLazyLoadProvider', 'APP_REQUIRES', function ($ocLazyLoadProvider, APP_REQUIRES) {
    'use strict';

    // Lazy Load modules configuration
    $ocLazyLoadProvider.config({
        debug: false,
        events: true,
        modules: APP_REQUIRES.modules
    });

}]).config(['$controllerProvider', '$compileProvider', '$filterProvider', '$provide',
    function ($controllerProvider, $compileProvider, $filterProvider, $provide) {
        'use strict';
        // registering components after bootstrap
        App.controller = $controllerProvider.register;
        App.directive = $compileProvider.directive;
        App.filter = $filterProvider.register;
        App.factory = $provide.factory;
        App.service = $provide.service;
        App.constant = $provide.constant;
        App.value = $provide.value;

    }]).config(['$translateProvider', function ($translateProvider) {

    $translateProvider.useStaticFilesLoader({
        prefix: 'i18n/',
        suffix: '.json'
    });
    $translateProvider.preferredLanguage('en');
    $translateProvider.useLocalStorage();
    $translateProvider.usePostCompiling(true);

}]).config(['tmhDynamicLocaleProvider', function (tmhDynamicLocaleProvider) {

    tmhDynamicLocaleProvider.localeLocationPattern('vendor/angular-i18n/angular-locale_{{locale}}.js');

}]).config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {

    cfpLoadingBarProvider.includeBar = true;
    cfpLoadingBarProvider.includeSpinner = false;
    cfpLoadingBarProvider.latencyThreshold = 500;
    cfpLoadingBarProvider.parentSelector = '.wrapper > section';

}]).config(['$tooltipProvider', function ($tooltipProvider) {

    $tooltipProvider.options({appendToBody: true});

}]);