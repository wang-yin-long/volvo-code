/**=========================================================
 * Module: RegionConfigTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('RegionConfigTableCtrl', RegionConfigTableCtrl);
function RegionConfigTableCtrl($scope, $filter, $http, ngTableParams, Notify, ngDialog, $resource, $timeout, ngTableDataService) {
    'use strict';

    var all_region = [];

    $scope.searchRegionConfig = function () {
        var data = [];
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
            } else if (result && result.length > 0) {
                data = result;
                all_region = result;
                $scope.initRegionList(data);
            }
        });

    }
    $scope.searchRegionConfig();

    $scope.refreshInitLogin = function () {
        Notify.alert("Refresh success", "success");
        $scope.searchRegionConfig();
    }

    $scope.initRegionList = function (data) {
        for (var i = 0; i < data.length; i++) {
            var one = data[i];
            one.index = i + 1;
        }
        $scope.data = data;
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
            page: 1,            // show first page
            count: 10,          // count per page
            filter: {}
        }, {
            total: $scope.data.length, // length of data
            getData: function ($defer, params) {
                // use build-in angular filter
                var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                params.total(orderedData.length);
                $defer.resolve(users);
            }
        });
    }

    /**
     * region delete
     * @param condi
     */
    $scope.delRegionInfo = function (obj) {
        ngDialog.openConfirm({
            template: 'deleteDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            $http.post('/delRegionList', condition).success(function (result) {
                var msg = result ? "Delete Success" : "Delete Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    // location.reload();
                    var backs = [];
                    for (var i = 0; i < all_region.length; i++) {
                        var region = all_region[i];
                        if (condition.id != region.id) {
                            backs.push(region);
                        }
                    }
                    for (var z = 0; z < backs.length; z++) {
                        var oo = backs[z];
                        oo.index = z + 1;
                    }
                    // 列表刷新
                    all_region = backs;
                    $scope.data = backs;
                    $scope.tableParams2.reload();
                }
            });
        }, function (reason) {
            console.log("CANCEL" + reason);
        });
    }

}

/**
 * Region Config Detail Ctrl
 */
App.controller('RegionDetailCtrl', ['$scope', '$http', '$state', '$timeout', '$stateParams', "Notify", "ngDialog",
    function ($scope, $http, $state, $timeout, $stateParams, Notify, ngDialog) {

        // url  params
        var regionID = $stateParams.regionId;

        // Prefix 机器信息前缀
        var prefixs = [];

        if ((regionID + "") == "0") {
            var obj = new Object();
            obj.id = 0;
            obj.regionID = "";
            obj.regionName = "";
            obj.description = "";
            obj.remarks = "";
            $scope.regionDetail = obj;
            $scope.prefixs = [];
        } else {
            var condition = new Object();
            condition.id = regionID;
            $http.post('/searchOneRegion', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (result && result.length > 0) {
                    var region = result[0];
                    $scope.regionDetail = region;
                    // 初始化region的前缀信息
                    var prefixStr = region.regionID;
                    if (prefixStr.indexOf(",") >= 0) {
                        var strs = prefixStr.split(",");
                        for (var s = 0; s < strs.length; s++) {
                            var one = strs[s];
                            if (one != "") {
                                var obj = new Object();
                                obj.name = one;
                                prefixs.push(obj);
                            }
                        }
                        $scope.prefixs = prefixs;
                    }
                }
            });
        }
        /**
         * 添加 region 的前缀信息
         */
        $scope.addPrefix = function () {
            var obj = new Object();
            obj.name = "";
            ngDialog.openConfirm({
                template: 'addPrefixDialog',
                className: 'ngdialog-theme-default',
                data: {condition: obj}
            }).then(function (value) {
                var prefix = new Object();
                prefix.name = value.name;
                prefixs.push(prefix);
                $scope.prefixs = prefixs;
            }, function (reason) {
                console.log("CANCEL" + reason);
            });
        }
        /**
         * 删除 region 的前缀信息
         */
        $scope.deletePrefix = function (c) {
            ngDialog.openConfirm({
                template: 'delPrefixDialog',
                className: 'ngdialog-theme-default',
                data: {condition: c}
            }).then(function (value) {
                var pres = [];
                for (var i = 0; i < prefixs.length; i++) {
                    var pre = prefixs[i];
                    if (pre.name != c.name) {
                        pres.push(pre);
                    }
                }
                prefixs = pres;
                $scope.prefixs = pres;
            }, function (reason) {
                console.log("CANCEL" + reason);
            });
        }

        /**
         * region save or update
         * @param condi
         */
        $scope.addOrUpRegionInfo = function () {
            var condition = $scope.regionDetail;
            // console.log(condition);

            // region 的前缀
            var regionIDStr = "";
            if (prefixs && prefixs.length > 0) {
                for (var i = 0; i < prefixs.length; i++) {
                    var pre = prefixs[i];
                    regionIDStr = regionIDStr + pre.name + ",";
                }
            }
            condition.regionID = regionIDStr;

            var postUrl = "";
            if (condition.id == 0) {
                postUrl = "/addRegionList";
            } else {
                postUrl = "/updateRegionList";
            }
            $http.post(postUrl, condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    window.location.href = "#/root/regionconfig";
                }
            });
        }

    }]);

