/**
 * Ad Config Controller
 */
App.controller('AdConfigController', ['$scope', '$http', '$state', '$timeout', "ngDialog", "Notify",
    function ($scope, $http, $state, $timeout, ngDialog, Notify) {

        var adInfo = new Object();
        adInfo.id = 0;
        adInfo.userName = "";
        adInfo.passWord = "";
        adInfo.path = "";
        adInfo.remarks = "";
        $scope.adConfigInfo = adInfo;

        $scope.searchADConfig = function () {
            var condition = new Object();
            $http.post('/searchADInfo', condition).success(function (data) {
                //console.log(data);
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    $scope.adConfigInfo = data[0];
                }
            });

        }
        $scope.searchADConfig();

        $scope.saveADConfig = function () {
            var condition = $scope.adConfigInfo;
            //console.log(condition);

            if (condition.id == 0) {
                $http.post('/addADInfo', condition).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                });
            } else {
                $http.post('/updateADInfo', condition).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                });
            }

        }

    }]);

/**
 * Mail Config Controller
 */
App.controller('MailConfigController', ['$scope', '$http', '$state', '$timeout', "Notify", function ($scope, $http, $state, $timeout, Notify) {

    var mailConfigInfo = new Object();
    mailConfigInfo.id = 0;
    mailConfigInfo.type = 0;
    mailConfigInfo.userName = "";
    mailConfigInfo.passWord = "";
    mailConfigInfo.path = "";
    mailConfigInfo.remarks = "Mail Account SMTP";
    $scope.mailConfigInfo = mailConfigInfo;

    $scope.searchMailConfig = function () {
        var condition = new Object();
        $http.post('/searchMailInfo', condition).success(function (data) {
            //console.log(data);
            if (data == "Error") {
                Notify.alert("Confirm Error", "danger");
            } else if (data && data.length > 0) {
                for (var n = 0; n < data.length; n++) {
                    var one = data[n];
                    if (one.type == 0) {
                        $scope.mailConfigInfo = one;
                        break;
                    }
                }
            }
        });

    }
    $scope.searchMailConfig();

    $scope.saveMailConfig = function () {
        var condition = $scope.mailConfigInfo;
        //console.log(condition);

        if (condition.id == 0) {
            $http.post('/addMailInfo', condition).success(function (data) {
                var msg = data ? "Confirm Success" : "Confirm Error";
                var type = data ? "success" : "danger";
                Notify.alert(msg, type);
                if (data) {
                    $scope.searchMailConfig();
                }
            });
        } else {
            $http.post('/updateMailInfo', condition).success(function (data) {
                var msg = data ? "Confirm Success" : "Confirm Error";
                var type = data ? "success" : "danger";
                Notify.alert(msg, type);
                if (data) {
                    $scope.searchMailConfig();
                }
            });
        }
    }

}]);

/**
 * Account Manage Controller
 */
App.controller('AccountManageController', ['$scope', '$http', '$state', '$timeout', "ngDialog", "Notify",
    function ($scope, $http, $state, $timeout, ngDialog, Notify) {

        var rootAccounts = [];
        var bizAccounts = [];
        var ucproot = [];
        $scope.rootAccounts = [];
        $scope.bizAccounts = [];
        /**
         * search Account Manage
         */
        $scope.searchAccountConfig = function () {
            var condition = new Object();
            $http.post('/searchMailInfo', condition).success(function (data) {
                //console.log(data);
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    rootAccounts = [];
                    bizAccounts = [];
                    ucproot = [];
                    for (var i = 0; i < data.length; i++) {
                        var one = data[i];
                        if (one.type == 1) {
                            rootAccounts.push(one);
                        }
                        if (one.type == 2) {
                            bizAccounts.push(one);
                        }
                        if (one.type == 3) {
                            ucproot.push(one);
                        }
                    }
                    for (var m = 0; m < rootAccounts.length; m++) {
                        var mail = rootAccounts[m];
                        mail.index = m + 1;
                    }
                    for (var n = 0; n < bizAccounts.length; n++) {
                        var one = bizAccounts[n];
                        one.index = n + 1;
                    }
                    for (var j = 0; j < ucproot.length; j++) {
                        var one = ucproot[j];
                        one.index = j + 1;
                    }
                    $scope.rootAccounts = rootAccounts;
                    $scope.bizAccounts = bizAccounts;
                    $scope.ucproot = ucproot;
                }
            });
        }
        $scope.searchAccountConfig();
        /**
         * reset  ucproot password
         */
        $scope.resetUcpRoot = function (info) {
            var password = "";

            ngDialog.openConfirm({
                template: 'resetUcpRootID',
                className: 'ngdialog-theme-default',
                data: {condition: password}
            }).then(function (value) {
                var url = '/resetUcpRoot';
                var obj = info;
                obj.passWord = value;
                $http.post(url, obj).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (data) {
                        $scope.searchAccountConfig();
                    }
                });
            }, function (reason) {
                //console.log("CANCEL" + reason);
            });
        }

        /**
         * root Account
         */
        $scope.rootAccountManage = function (info) {
            var condi = new Object();
            condi.title = "Root Account";
            condi.accountName = info == "" ? "" : info.userName;
            condi.ip = info == "" ? "" : info.ip;
            condi.remarks = info == "" ? "" : info.remarks;

            ngDialog.openConfirm({
                template: 'addAddressDialogID',
                className: 'ngdialog-theme-default',
                data: {condition: condi}
            }).then(function (value) {
                var url = "";
                var obj = new Object();
                if (info == "") {
                    url = '/addMailInfo';
                } else {
                    url = '/updateMailInfo';
                    obj.id = info.id;
                }
                obj.type = 1;
                obj.userName = value.accountName;
                obj.passWord = "";
                obj.path = "";
                obj.ip = value.ip;
                obj.remarks = value.remarks;
                $http.post(url, obj).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (data) {
                        $scope.searchAccountConfig();
                    }
                });
            }, function (reason) {
                //console.log("CANCEL" + reason);
            });
        }
        /**
         * business Account
         */
        $scope.bizAccountManage = function (info) {
            var condi = new Object();
            condi.title = "Business Account";
            condi.accountName = info == "" ? "" : info.userName;
            condi.ip = info == "" ? "" : info.ip;
            condi.remarks = info == "" ? "" : info.remarks;

            ngDialog.openConfirm({
                template: 'addAddressDialogID',
                className: 'ngdialog-theme-default',
                data: {condition: condi}
            }).then(function (value) {
                var url = "";
                var obj = new Object();
                if (info == "") {
                    url = '/addMailInfo';
                } else {
                    url = '/updateMailInfo';
                    obj.id = info.id;
                }
                obj.type = 2;
                obj.userName = value.accountName;
                obj.passWord = "";
                obj.path = "";
                obj.ip = value.ip;
                obj.remarks = value.remarks;
                $http.post(url, obj).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (data) {
                        $scope.searchAccountConfig();
                    }
                });
            }, function (reason) {
                //console.log("CANCEL" + reason);
            });
        }
        /**
         * delete Account Manage
         * @param obj
         */
        $scope.deleteAddress = function (obj) {
            ngDialog.openConfirm({
                template: 'deleteDialogId',
                className: 'ngdialog-theme-default',
            }).then(function (value) {
                $http.post('/delMailInfo', obj).success(function (data) {
                    var msg = data ? "Confirm Success" : "Confirm Error";
                    var type = data ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (data) {
                        $scope.searchAccountConfig();
                    }
                });
            }, function (reason) {
                //console.log("CANCEL" + reason);
            });
        }

    }]);

/**
 * Agent Time Config Ctrl
 */
App.controller('AgentTimeConfigCtrl', ['$scope', '$http', '$state', '$timeout', "Notify",
    function ($scope, $http, $state, $timeout, Notify) {

        var obj1 = new Object();
        obj1.code = 0;
        obj1.dataKey = "AgentHeartbeatTime";
        obj1.value = "5";
        obj1.remarks = "";
        $scope.agentHeartbeatTime = obj1;
        var obj2 = new Object();
        obj2.code = 0;
        obj2.dataKey = "AgentAlertTime";
        obj2.value = "15";
        obj2.remarks = "";
        $scope.agentAlertTime = obj2;

        var heartbeatFlg = true;
        var alertFlg = true;

        $scope.searchAgentTime = function () {
            var condition = new Object();
            $http.post('/searchAgentTime', condition).success(function (data) {
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    var configs = data;
                    for (var n = 0; n < configs.length; n++) {
                        var one = configs[n];
                        if (one.dataKey == "AgentHeartbeatTime") {
                            $scope.agentHeartbeatTime = one;
                            heartbeatFlg = false;
                        }
                        if (one.dataKey == "AgentAlertTime") {
                            $scope.agentAlertTime = one;
                            alertFlg = false;
                        }
                    }
                }
            });

        }
        $scope.searchAgentTime();
        /**
         * Confirm Agent Time Config
         */
        $scope.saveAgentTime = function () {
            var url = "";
            var agentHeartbeat = $scope.agentHeartbeatTime;
            if (heartbeatFlg) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, agentHeartbeat).success(function (data) {
                if (data) {
                    $scope.saveAlertTime();
                } else {
                    Notify.alert("Error", "danger");
                    return;
                }
            });
        }
        $scope.saveAlertTime = function () {
            var url = "";
            var agentAlert = $scope.agentAlertTime;
            if (alertFlg) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, agentAlert).success(function (data) {
                var msg = data ? "Confirm Success" : "Confirm Error";
                var type = data ? "success" : "danger";
                Notify.alert(msg, type);
            });
        }

    }]);
