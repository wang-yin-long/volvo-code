/**
 * Module: Pool Config Table Ctrl.js
 * Controller for ngTables
 */
App.controller('PoolConfigTableCtrl', PoolConfigTableCtrl);
function PoolConfigTableCtrl($scope, $filter, $http, ngTableParams, Notify, ngDialog, $timeout) {
    'use strict';

    var data = [];
    var all_pool = [];
    /**
     * search region dropdown
     */
    $scope.initStart = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regionList = result;
                $scope.searchPoolConfig(regionList);
            }
        });
    }
    $scope.initStart();

    $scope.refreshInitLogin = function () {
        Notify.alert("Refresh success", "success");
        $scope.initStart();
    }
    /**
     * search Pool List
     * @param regionList
     */
    $scope.searchPoolConfig = function (regionList) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
            } else if (result && result.length > 0) {
                data = result;
                for (var i = 0; i < data.length; i++) {
                    var one = data[i];
                    one.index = i + 1;
                    if (one.poolType == 1) {
                        one.poolTypeName = "Shared";
                    } else {
                        one.poolTypeName = "Booking";
                    }
                    // search region name
                    for (var n = 0; n < regionList.length; n++) {
                        var region = regionList[n];
                        if (one.region == region.id) {
                            one.regionName = region.regionName;
                        }
                    }
                }
                all_pool = data;
                $scope.initPoolList();
            }
        });
    }
    /**
     * init table
     */
    $scope.initPoolList = function () {
        $scope.data = data;
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
            page: 1,            // show first page
            count: 10
        }, {
            total: $scope.data.length, // length of data
            getData: function ($defer, params) {
                // use build-in angular filter
                var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                params.total(orderedData.length); // set total for recalc pagination
                $defer.resolve(users);
            }
        });
    }

    /**
     * region delete
     * @param condi
     */
    $scope.delPoolInfo = function (obj) {
        ngDialog.openConfirm({
            template: 'deleteDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            $http.post('/delPoolList', condition).success(function (result) {
                var msg = result ? "Delete Success" : "Delete Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    // location.reload();
                    var backs = [];
                    for (var i = 0; i < all_pool.length; i++) {
                        var pool = all_pool[i];
                        if (condition.id != pool.id) {
                            backs.push(pool);
                        }
                    }
                    for (var z = 0; z < backs.length; z++) {
                        var oo = backs[z];
                        oo.index = z + 1;
                    }
                    // 列表刷新
                    all_pool = backs;
                    $scope.data = backs;
                    $scope.tableParams2.reload();
                }
            });
        }, function (reason) {
            console.log("CANCEL-----" + reason);
        });

    }

}

/**
 * Pool Detail Ctrl
 */
App.controller('PoolDetailCtrl', ['$scope', '$http', '$state', '$timeout', '$stateParams', "Notify","ngDialog",
    function ($scope, $http, $state, $timeout, $stateParams, Notify,ngDialog) {
        /**
         * url  params
         */
        var poolId = $stateParams.poolid;
        // pool的身份信息
        var identitys = [];
        $scope.identitys = [];
        /**
         * search region dropdown
         * @type {Object}
         */
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
            } else if (result && result.length > 0) {
                $scope.regionDrop = result;
                $timeout(function () {
                    $scope.initPool();
                }, 20);
            }
        });

        /**
         * 添加 pool 的身份ID
         */
        $scope.addIdentity = function () {
            var obj = new Object();
            obj.name = "";
            ngDialog.openConfirm({
                template: 'addIdentityDialog',
                className: 'ngdialog-theme-default',
                data: {condition: obj}
            }).then(function (value) {
                var identity = new Object();
                identity.name = value.name;
                identitys.push(identity);
                $scope.identitys = identitys;
            }, function (reason) {
                console.log("CANCEL" + reason);
            });
        }
        /**
         * 删除 pool 的身份ID
         */
        $scope.deleteIdentity = function (c) {
            ngDialog.openConfirm({
                template: 'delIdentityDialog',
                className: 'ngdialog-theme-default',
                data: {condition: c}
            }).then(function (value) {
                var ides = [];
                for (var i = 0; i < identitys.length; i++) {
                    var ide = identitys[i];
                    if (ide.name != c.name) {
                        ides.push(ide);
                    }
                }
                identitys = ides;
                $scope.identitys = ides;
            }, function (reason) {
                console.log("CANCEL" + reason);
            });
        }

        /**
         * init pool info (add or update)
         */
        $scope.initPool = function () {
            if ((poolId + "") == "0") {
                var obj = new Object();
                obj.id = 0;
                obj.poolType = 0;
                obj.poolID = "";
                obj.poolName = "";
                obj.maxUser = 0;
                obj.region = 0;
                obj.status = 0;
                obj.description = "";
                $scope.poolDetail = obj;
                $scope.identitys = [];
            } else {
                var condition = new Object();
                condition.id = poolId;
                $http.post('/searchOnePool', condition).success(function (result) {
                    if (result == "Error") {
                        Notify.alert("Confirm Error", "danger");
                    } else if (result && result.length > 0) {
                        var pool = result[0];
                        $scope.poolDetail = pool;
                        // 初始化pool的身份ID
                        var ideStr = pool.poolID;
                        if (ideStr.indexOf(",") >= 0) {
                            var strs = ideStr.split(",");
                            for (var s = 0; s < strs.length; s++) {
                                var one = strs[s];
                                if (one != "") {
                                    var obj = new Object();
                                    obj.name = one;
                                    identitys.push(obj);
                                }
                            }
                            $scope.identitys = identitys;
                        }
                    }
                });
            }
        }
        /**
         * region save or update
         * @param condi
         */
        $scope.addOrUpPoolInfo = function () {
            var condition = $scope.poolDetail;
            //console.log(condition);

            // region 的前缀
            var poolIDStr = "";
            if (identitys && identitys.length > 0) {
                for (var i = 0; i < identitys.length; i++) {
                    var pre = identitys[i];
                    poolIDStr = poolIDStr + pre.name + ",";
                }
            }
            condition.poolID = poolIDStr;
            var postUrl = "";
            if (condition.id == 0) {
                postUrl = "/addPoolList";
            } else {
                postUrl = "/updatePoolList";
            }
            $http.post(postUrl, condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    window.location.href = "#/root/poolconfig";
                }
            });
        }

    }]);

