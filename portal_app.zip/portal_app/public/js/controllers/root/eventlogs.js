/**=========================================================
 * Module: LogsTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('EventLogsTableCtrl', LogsTableCtrl);
function LogsTableCtrl($scope, $filter, ngTableParams, ngDialog, $timeout, $http, $state, Notify) {
    /**
     * search Login
     */
    var loginUser = null;
    $scope.initLogin = function (type) {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.initRegion();
                if (type == "1"){
                    Notify.alert("Refresh success", "success");
                }
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('bizAdmin');
                return;
            }
        });
    }
    $scope.initLogin("");

    $scope.refreshInitLogin = function () {
        $scope.initLogin("1");
    }
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regions = result;
                $scope.initPool(regions);
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $scope.searchLogs(regions, pools);
            }
        });
    }
    /**
     * search logs
     * @param regions
     * @param pools
     */
    $scope.searchLogs = function (regions, pools) {
        var data = [];
        var condition = new Object();
        $http.post('/searchEventLogs', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                data = result;
                var logs = [];
                for (var i = 0; i < data.length; i++) {
                    var one = data[i];
                    var now_condi = new Date().valueOf();
                    var logTime = new Date(new Date(one.logTime).valueOf() - 8 * 60 * 60 * 1000);
                    var jiange = now_condi - logTime;

                    // 过去7天内时间日志
                    if (jiange <= 7 * 24 * 60 * 60 * 1000) {

                        var sMonth = logTime.getMonth() + 1 < 10 ? "0" + (logTime.getMonth() + 1) : logTime.getMonth() + 1;
                        var SDay = logTime.getDate() < 10 ? "0" + logTime.getDate() : logTime.getDate();
                        var SHour = logTime.getHours() < 10 ? "0" + logTime.getHours() : logTime.getHours();
                        var sMinite = logTime.getMinutes() < 10 ? "0" + logTime.getMinutes() : logTime.getMinutes();
                        var seconds = logTime.getSeconds() < 10 ? "0" + logTime.getSeconds() : logTime.getSeconds();

                        one.logTimeView = logTime.getFullYear() + "-" + sMonth + "-" + SDay + " " + SHour + ":" + sMinite + ":" + seconds;
                        /**
                         *  search region name
                         */
                        for (var n = 0; n < regions.length; n++) {
                            var region = regions[n];
                            if (one.region == region.id) {
                                one.regionName = region.regionName;
                            }
                        }
                        /**
                         * set pool name
                         */
                        for (var m = 0; m < pools.length; m++) {
                            var pool = pools[m];
                            if (one.pool == pool.id) {
                                one.poolName = pool.poolName;
                            }
                        }
                        logs.push(one);
                    }
                }
                for (var z = 0; z < logs.length; z++) {
                    var log = logs[z];
                    log.index = z + 1;
                }
                $scope.initTableList(logs);
            }
        });
    }

    $scope.initTableList = function (data) {
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {
                    userName: '',
                    bookPoolName: '',
                    description: ''
                }
            },
            {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * delete logs
     */
    $scope.deleteInfo = function (obj) {
        ngDialog.openConfirm({
            template: 'confirmDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            $http.post('/delLogs', condition).success(function (result) {
                var msg = result ? "Success" : "Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    location.reload();
                }
            });
        }, function (reason) {
        });
    }

}

