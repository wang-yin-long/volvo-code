/**=========================================================
 * Module: AD Group Config Table Ctrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('ADGroupConfigTableCtrl', PoolConfigTableCtrl);
function PoolConfigTableCtrl($scope, $filter, $http, ngTableParams, Notify, ngDialog, $timeout, ngTableDataService) {
    'use strict';
    // required for inner references
    var data = [];
    var all_group = [];
    /**
     * search region dropdown
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regionList = result;
                $scope.initPool(regionList);
            }
        });
    }
    $scope.initRegion();
    /**
     * search pool dropdown
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $timeout(function () {
                    $scope.searchAdGroup(regions, pools);
                }, 20);
            }
        });
    }
    /**
     * search Ad Group List
     * @param regionList
     */
    $scope.searchAdGroup = function (regions, pools) {
        var condition = new Object();
        $http.post('/searchAdGroup', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Confirm Error", "danger");
            } else if (result && result.length > 0) {
                data = result;
                for (var i = 0; i < data.length; i++) {
                    var one = data[i];
                    one.index = i + 1;
                    // search region name
                    for (var n = 0; n < regions.length; n++) {
                        var region = regions[n];
                        if (one.region == region.id) {
                            one.regionName = region.regionName;
                        }
                    }
                    // search pool name
                    for (var m = 0; m < pools.length; m++) {
                        var pool = pools[m];
                        if (one.pool == pool.id) {
                            one.poolName = pool.poolName;
                        }
                    }
                }
                all_group = data;
                $scope.initADGroupList();
            }
        });
    }
    /**
     * init table
     */
    $scope.initADGroupList = function () {

        $scope.data = data;
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
            page: 1,            // show first page
            count: 10,          // count per page
            filter: {}
        }, {
            total: $scope.data.length, // length of data
            getData: function ($defer, params) {
                // use build-in angular filter
                var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                params.total(orderedData.length); // set total for recalc pagination
                $defer.resolve(users);
            }
        });
    }

    /**
     * region delete
     * @param condi
     */
    $scope.delAdGroup = function (obj) {
        ngDialog.openConfirm({
            template: 'deleteDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {

            var condition = obj;
            $http.post('/delAdGroup', condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    // location.reload();
                    var backs = [];
                    for (var i = 0; i < all_group.length; i++) {
                        var group = all_group[i];
                        if (condition.id != group.id) {
                            backs.push(group);
                        }
                    }
                    for (var z = 0; z < backs.length; z++) {
                        var oo = backs[z];
                        oo.index = z + 1;
                    }
                    // 列表刷新
                    all_group = backs;
                    $scope.data = backs;
                    $scope.tableParams2.reload();
                }
            });
        }, function (reason) {
            console.log("CANCEL" + reason);
        });
    }

}

/**
 * AD Group Detail Ctrl
 */
App.controller('ADGroupDetailCtrl', ['$scope', '$http', '$state', '$timeout', '$stateParams', "Notify",
    function ($scope, $http, $state, $timeout, $stateParams, Notify) {
        /**
         * url  params
         */
        var ADGroupID = $stateParams.adgroupid;
        console.log(ADGroupID);
        var regions = [];
        var pools = [];
        /**
         * search region dropdown
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    $scope.regionDrop = result;
                    $scope.initPool();
                }
            });
        }
        $scope.initRegion();
        /**
         * search pool dropdown
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    $scope.poolDrop = result;
                    $timeout(function () {
                        $scope.initAdGroup();
                    }, 20);
                }
            });
        }
        /**
         * region change
         */
        $scope.regionChange = function () {
            var datas = [];
            var id = $scope.groupDetail.region;
            for (var m = 0; m < pools.length; m++) {
                var pool = pools[m];
                if (id == pool.region) {
                    datas.push(pool);
                }
            }
            $scope.poolDrop = datas;
        }
        /**
         * init pool info (add or update)
         */
        $scope.initAdGroup = function () {
            if ((ADGroupID + "") == "0") {
                var obj = new Object();
                obj.id = 0;
                obj.groupID = "";
                obj.groupName = "";
                obj.region = 0;
                obj.pool = 0;
                obj.description = "";
                $scope.groupDetail = obj;
            } else {
                var condition = new Object();
                condition.id = ADGroupID;
                $http.post('/searchOneAdGroup', condition).success(function (result) {
                    if (result == "Error") {
                        Notify.alert("Confirm Error", "danger");
                    } else if (result && result.length > 0) {
                        $scope.groupDetail = result[0];
                    }
                });
            }
        }
        /**
         * region save or update
         * @param condi
         */
        $scope.addOrUpAdGroupInfo = function () {
            var condition = $scope.groupDetail;
            console.log(condition);
            var postUrl = "";
            if (condition.id == 0) {
                postUrl = "/addAdGroup";
            } else {
                postUrl = "/updateAdGroup";
            }
            $http.post(postUrl, condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    window.location.href = "#/root/adgroupconfig";
                }
            });
        }

    }]);

