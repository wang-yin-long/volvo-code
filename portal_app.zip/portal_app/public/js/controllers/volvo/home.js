/**
 * add  by  wyl  2016.05.04
 */
App.controller('HomeManageCtrl', ['$rootScope', '$scope', '$state', '$http', '$timeout', 'ngDialog', 'Notify',
    function ($rootScope, $scope, $state, $http, $timeout, ngDialog, Notify) {

        var loginUser = null;
        var regions = [];
        var pools = [];
        var nextBook = null;
        $scope.loginFlg = true;
        $scope.nextBookShow = true;
        /**
         * search Login
         */
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                if (result != null) {
                    loginUser = result;
                    $scope.loginName = loginUser.loginName;
                    if (loginUser.urgentFlg == "0") {
                        $scope.urgentFlg = false;
                    } else {
                        $scope.urgentFlg = true;
                    }

                    $scope.initApply();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * search Apply
         * @type {Object}
         */
        $scope.initApply = function () {
            var condition = new Object();
            $http.post('/searchApply', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Search Data Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    var applies = [];
                    for (var i = 0; i < result.length; i++) {
                        var one = result[i];
                        if (one.userID == loginUser.loginID && one.status == 1) {
                            applies.push(one);
                        }
                    }
                    $scope.initRegion(applies);
                }
            });
        }
        /**
         * search regions
         */
        $scope.initRegion = function (applies) {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = [];
                    /**
                     * set region access
                     */

                    for (var i = 0; i < result.length; i++) {
                        var region = result[i];

                        // ------------------- modify by wyl 2016 06 28 --------------------------
                        var flg = true;
                        for (var m = 0; m < regions.length; m++) {
                            var re = regions[m];
                            if (re.id == region.id) {
                                flg = false;
                            }
                        }
                        if (flg) {
                            regions.push(region);
                        }
                        //for (var j = 0; j < applies.length; j++) {
                        //    var apply = applies[j];
                        //    if (apply.applyRegion == region.id) {
                        //        /**
                        //         *  if region is repeat
                        //         * @type {boolean}
                        //         */
                        //        var flg = true;
                        //        for (var m = 0; m < regions.length; m++) {
                        //            var re = regions[m];
                        //            if (re.id == region.id) {
                        //                flg = false;
                        //            }
                        //        }
                        //        if (flg) {
                        //            regions.push(region);
                        //        }
                        //    }
                        //}
                    }
                    for (var n = 0; n < regions.length; n++) {
                        var one = regions[n];
                        one.index = n + 1;
                    }

                    $scope.initPool(applies);
                }
            });
        }
        /**
         * search pools
         */
        $scope.initPool = function (applies) {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = [];
                    /**
                     * set pool access
                     */
                    for (var i = 0; i < result.length; i++) {
                        var pool = result[i];

                        // ------------------- modify by wyl 2016 06 28 --------------------------
                        if (pool.region == regions[0].id) {
                            pools.push(pool);
                        }
                        //for (var j = 0; j < applies.length; j++) {
                        //    var apply = applies[j];
                        //    if (apply.applyRegion == pool.region && apply.applyPool == pool.id) {
                        //        pools.push(pool);
                        //    }
                        //}
                    }
                    for (var i = 0; i < pools.length; i++) {
                        var one = pools[i];
                        one.index = i + 1;
                    }
                    $scope.regions = regions;
                    $scope.pools = pools;
                    $scope.searchBookings();
                }
            });
        }
        /**
         * search Booking
         */
        $scope.bookPoolName = "";
        $scope.nextBookStart = new Object();
        $scope.nextBookEnd = new Object();
        $scope.searchBookings = function () {
            var condition = new Object();
            $http.post('/searchNextBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Search Data Error", "danger");
                } else if (result && result.length > 0) {
                    for (var i = 0; i < result.length; i++) {
                        var one = result[i];
                        // search region name
                        for (var n = 0; n < regions.length; n++) {
                            var region = regions[n];
                            if (one.bookRegion == region.id) {
                                one.bookRegionName = region.regionName;
                            }
                        }
                        /**
                         * set pool name
                         */
                        for (var m = 0; m < pools.length; m++) {
                            var pool = pools[m];
                            if (one.bookPool == pool.id) {
                                one.bookPoolName = pool.poolName;
                            }
                        }
                    }
                    $scope.getAndSetNextBook(result);
                }
            });
        }
        /**
         * get and set next  booking
         */
        $scope.getAndSetNextBook = function (result) {
            //console.log(result);
            var now = new Date().valueOf();
            var books = [];
            for (var i = 0; i < result.length; i++) {
                var one = result[i];
                if (loginUser.loginID == one.userId) {
                    books.push(one);
                }
            }
            for (var m = 0; m < books.length; m++) {
                var one = books[m];
                var startTime = new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000;
                if (startTime > now && one.status < 2) {
                    nextBook = one;
                    /**
                     * get pool name
                     */
                    for (var n = 0; n < pools.length; n++) {
                        var pool = pools[n];
                        if (one.bookPool == pool.id) {
                            $scope.bookPoolName = pool.poolName;
                            $scope.bookPoolCode = pool.poolCode;
                            // console.log($scope.bookPoolName);
                        }
                    }
                    /**
                     * get and set next  booking
                     */
                    var start = new Date(new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                    var nextBookStart = new Object();
                    nextBookStart.year = start.getFullYear();
                    nextBookStart.month = start.getMonth() + 1 < 10 ? "0" + (start.getMonth() + 1) : start.getMonth() + 1;
                    nextBookStart.day = start.getDate() < 10 ? "0" + start.getDate() : start.getDate();
                    nextBookStart.hour = start.getHours();
                    nextBookStart.minite = start.getMinutes() == 0 ? "00" : start.getMinutes();
                    $scope.nextBookStart = nextBookStart;
                    var end = new Date(new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
                    var nextBookEnd = new Object();
                    nextBookEnd.year = end.getFullYear();
                    nextBookEnd.month = end.getMonth() + 1 < 10 ? "0" + (end.getMonth() + 1) : end.getMonth() + 1;
                    nextBookEnd.day = end.getDate() < 10 ? "0" + end.getDate() : end.getDate();
                    nextBookEnd.hour = end.getHours();
                    nextBookEnd.minite = end.getMinutes() == 0 ? "00" : end.getMinutes();
                    $scope.nextBookEnd = nextBookEnd;
                    break;
                }
            }

            if (nextBook == null) {
                $scope.nextBookShow = false;
                Notify.alert("No Next Booking", "danger");
                return;
            }

        }

        /**
         * login to agent ( interface )
         */
        $scope.loginOn = function () {


            console.log("----------loginOn----------");
            console.log(nextBook);
            if (nextBook != null) {
                var postUrl = "";
                var condition = JSON.stringify(nextBook);
                $http.post(postUrl, condition).success(function (result) {
                    $scope.loginOnAgent(result);
                });
            } else {
                Notify.alert("No Next Booking", "danger");
                return;
            }
        }
        /**
         * agent login on
         */
        $scope.loginOnAgent = function (condi) {

            if (nextBook != null) {
                var condition = nextBook;
                condition.remarks = "";
                condition.status = 1;
                condition.agentName = "";
                condition.useStart = new Date(new Date().valueOf() + 8 * 60 * 60 * 1000);

                // 判断 当前时间点是否有预定信息
                var book_start = new Date(nextBook.bookStart).valueOf();
                var book_end = new Date(nextBook.bookEnd).valueOf();
                if (condition.useStart.valueOf() < book_start || condition.useStart.valueOf() > book_end) {
                    Notify.alert("No booking now", "danger");
                    return;
                }
                var postUrl = "/updateLoginBook";
                $http.post(postUrl, condition).success(function (result) {
                    var msg = result ? "Login Success" : "Login Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        $scope.loginFlg = false;

                        // TODO 通过网站系统登陆到Agent
                        var vdiStr = "vmware-view://" + "vdichina.jia.volvocars.net"
                            + "/cn=" + $scope.bookPoolCode
                            + ",ou=applications,dc=vdi,dc=vmware,dc=int";
                        console.log(vdiStr);
                        location.href = vdiStr;
                    }
                });
            } else {
                Notify.alert("No Next Booking", "danger");
                return;
            }
        }

    }]);