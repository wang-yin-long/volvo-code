/**
 * update  by  wyl  2016.04.29
 */
App.controller('UserProfileController', ['$rootScope', '$scope', '$state', '$http', '$timeout', 'Notify',
    function ($rootScope, $scope, $state, $http, $timeout, Notify) {

        var loginUser = null;
        var regions = [];
        var pools = [];
        var selectRegion = null;
        var selectPool = null;
        $scope.regionListId = "_user_profile_region_";
        $scope.poolListId = "_user_profile_pool_";
        /**
         * search Login
         */
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.loginName = loginUser.loginName;
                    $scope.initApply();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * search Apply
         * @type {Object}
         */
        $scope.initApply = function () {
            var condition = new Object();
            $http.post('/searchApply', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    var applies = [];
                    for (var i = 0; i < result.length; i++) {
                        var one = result[i];
                        if (one.userID == loginUser.loginID && one.status == 1) {
                            applies.push(one);
                        }
                    }
                    $scope.initRegion(applies);
                }
            });
        }
        /**
         * search regions
         */
        $scope.initRegion = function (applies) {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = []
                    /**
                     * set region access
                     */
                    for (var i = 0; i < result.length; i++) {
                        var region = result[i];
                        for (var j = 0; j < applies.length; j++) {
                            var apply = applies[j];
                            if (apply.applyRegion == region.id) {
                                /**
                                 *  if region is repeat
                                 * @type {boolean}
                                 */
                                var flg = true;
                                for (var m = 0; m < regions.length; m++) {
                                    var re = regions[m];
                                    if (re.id == region.id) {
                                        flg = false;
                                    }
                                }
                                if (flg) {
                                    regions.push(region);
                                }
                            }
                        }
                    }
                    for (var n = 0; n < regions.length; n++) {
                        var one = regions[n];
                        one.index = n + 1;
                    }
                    $scope.initPool(applies);
                }
            });
        }
        /**
         * search pools
         */
        $scope.initPool = function (applies) {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = [];
                    /**
                     * set pool access
                     */
                    for (var i = 0; i < result.length; i++) {
                        var pool = result[i];
                        for (var j = 0; j < applies.length; j++) {
                            var apply = applies[j];
                            if (apply.applyRegion == pool.region && apply.applyPool == pool.id) {
                                pools.push(pool);
                            }
                        }
                    }
                    for (var i = 0; i < pools.length; i++) {
                        var one = pools[i];
                        one.index = i + 1;
                    }
                    // 初始化用户存在权限的region , pool
                    $scope.regions = regions;
                    $scope.pools = pools;
                }
            });
        }

        $scope.userRegionPools = function () {
            $scope.regions = regions;
            $scope.pools = pools;
        }

        $scope.poolChange = function (obj) {
            var region = obj;
            var condiPools = [];
            for (var i = 0; i < pools.length; i++) {
                var one = pools[i];
                if (region.id == one.region) {
                    condiPools.push(one);
                }
            }
            for (var n = 0; n < condiPools.length; n++) {
                var one = condiPools[n];
                one.index = n + 1;
            }
            $scope.pools = condiPools;
        }
        $scope.selectApplyRegion = function (obj) {
            selectRegion = obj;
            var type = obj.index;
            //for (var i = 1; i < 20; i++) {
            //    if ((type + "") == (i + "")) {
            //        angular.element('#_user_profile_region_' + i).addClass('apply-region-selected');
            //        angular.element('#_user_profile_region_' + i).removeClass('apply-region-button');
            //    } else {
            //        angular.element('#_user_profile_region_' + i).removeClass('apply-region-selected');
            //        angular.element('#_user_profile_region_' + i).addClass('apply-region-button');
            //    }
            //}
            $scope.poolChange(obj);
        }

    }]);