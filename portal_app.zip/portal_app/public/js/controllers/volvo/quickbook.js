/**
 * quickBookControler  add  by  wyl  2016.04.29
 */
App.controller('QuickBookController', ['$rootScope', '$scope', '$state', '$http', '$timeout', '$stateParams', 'Notify',
    function ($rootScope, $scope, $state, $http, $timeout, $stateParams, Notify) {


        var quickEnd = new Object();
        var now_time = new Date();
        var now_hour = now_time.getHours();
        var now_minute = now_time.getMinutes();
        if (now_minute < 30) {
            quickEnd.endTime1 = (now_hour + 1) + ":00"
            quickEnd.endTime2 = (now_hour + 1) + ":30"
            quickEnd.endTime3 = (now_hour + 2) + ":00"
            quickEnd.endTime4 = (now_hour + 2) + ":30"
        } else {
            quickEnd.endTime1 = (now_hour + 1) + ":30"
            quickEnd.endTime2 = (now_hour + 2) + ":00"
            quickEnd.endTime3 = (now_hour + 2) + ":30"
            quickEnd.endTime4 = (now_hour + 3) + ":00"
        }
        $scope.quickEnd = quickEnd;
        var select_end = quickEnd.endTime4;
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                if (result != null) {
                    loginUser = result;
                    $scope.initPool();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * url  params
         */
        var poolId = $stateParams.userpoolid;
        /**
         * search Pools
         * @type {Object}
         */
        $scope.initPool = function () {
            var condition = new Object();
            condition.id = poolId;
            $http.post('/searchOnePool', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (result && result.length > 0) {
                    $scope.poolDetail = result[0];
                }
            });
        }

        $scope.selectHour = function (type) {

            if (type == 1) {
                select_end = quickEnd.endTime1;
            }
            if (type == 2) {
                select_end = quickEnd.endTime2;
            }
            if (type == 3) {
                select_end = quickEnd.endTime3;
            }
            if (type == 4) {
                select_end = quickEnd.endTime4;
            }
            for (var i = 1; i < 5; i++) {
                if ((type + "") == (i + "")) {
                    angular.element('#_valid_hour_' + i).addClass('quick-book-select');
                    angular.element('#_valid_hour_' + i).removeClass('quick-book-hour');
                } else {
                    angular.element('#_valid_hour_' + i).removeClass('quick-book-select');
                    angular.element('#_valid_hour_' + i).addClass('quick-book-hour');
                }

            }
            $timeout(function () {
                angular.element('#_valid_hour_pool').trigger("click");
            }, 1);
        }
        /**
         * 快速预定 先sql添加quick book数据 再登陆
         */
        $scope.quickLoginToAgent = function () {
            // select_end
            var strs = select_end.split(":");
            var condition = new Object();
            condition.bookType = 1;// 快速预定
            condition.userId = loginUser.loginID;
            condition.userName = loginUser.loginName;
            var s = null;
            // 快速预定book的开始结束时间
            if (now_time.getMinutes() < 30) {
                s = new Date(now_time.getFullYear(), now_time.getMonth(), now_time.getDate(), now_time.getHours(), 0, 0, 0);
                condition.bookStart = new Date(s.valueOf() + 8 * 60 * 60 * 1000);
            } else {
                s = new Date(now_time.getFullYear(), now_time.getMonth(), now_time.getDate(), now_time.getHours(), 30, 0, 0);
                condition.bookStart = new Date(s.valueOf() + 8 * 60 * 60 * 1000);
            }
            var e = new Date(now_time.getFullYear(), now_time.getMonth(), now_time.getDate(), Number(strs[0]), Number(strs[1]), 0, 0);
            condition.bookEnd = new Date(e.valueOf() + 8 * 60 * 60 * 1000);

            condition.bookRegion = $scope.poolDetail.region;
            condition.bookPool = $scope.poolDetail.id;
            condition.status = 1; // 说明使用中
            condition.description = "Add quick booing on server";
            // 开始使用时间
            condition.useStart = new Date(now_time.valueOf() + 8 * 60 * 60 * 1000);
            // console.log(condition);
            $http.post("/addQuickBooking", condition).success(function (result) {
                var msg = result ? "Success" : "Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    $timeout(function () {
                        // TODO 快速预定成功启动Agent的接口
                        var vdiStr = "vmware-view://" + "vdichina.jia.volvocars.net"
                            + "/cn=" + $scope.poolDetail.poolCode
                            + ",ou=applications,dc=vdi,dc=vmware,dc=int";

                        console.log(vdiStr);
                        location.href = vdiStr;
                    }, 500);
                }
            });
        }

    }]);