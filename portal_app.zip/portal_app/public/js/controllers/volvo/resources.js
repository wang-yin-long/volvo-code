/**
 * add  by  wyl  2016.04.20
 * update  by  wyl  2016.04.29
 */
App.controller('NormalUserResourcesCtrl', ['$rootScope', '$scope', '$state', '$http', '$timeout', 'Notify',
    function ($rootScope, $scope, $state, $http, $timeout, Notify) {

        var loginUser = null;
        var regions = [];
        var pools = [];
        var needBookools = [];
        var nextBook = null;
        $scope.loginFlg = true;
        $scope.nextBookShow = true;
        var allBooks = [];
        $scope.regionListId = "_resources_region_";
        /**
         * search Login
         */
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.loginName = loginUser.loginName;
                    if (loginUser.urgentFlg == "0") {
                        $scope.urgentFlg = false;
                    } else {
                        $scope.urgentFlg = true;
                    }

                    $scope.initApply();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * search Apply
         * @type {Object}
         */
        $scope.initApply = function () {
            var condition = new Object();
            $http.post('/searchApply', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                } else if (result && result.length > 0) {
                    var applies = [];
                    for (var i = 0; i < result.length; i++) {
                        var one = result[i];
                        if (one.userID == loginUser.loginID && one.status == 1) {
                            applies.push(one);
                        }
                    }

                    $scope.initRegion(applies);
                }
            });
        }
        /**
         * search regions
         */
        $scope.initRegion = function (applies) {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    for (var i = 0; i < regions.length; i++) {
                        var one = regions[i];
                        one.index = i + 1;
                    }

                    $scope.initPool(applies);
                }
            });
        }

        /**
         * search pools
         */
        $scope.initPool = function (applies) {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = [];
                    /**
                     * set pool access
                     */
                    for (var i = 0; i < result.length; i++) {
                        var pool = result[i];

                        // ------------------- modify by wyl 2016 06 28 --------------------------
                        //for (var j = 0; j < applies.length; j++) {
                        //    var apply = applies[j];
                        //    if (apply.applyRegion == pool.region && apply.applyPool == pool.id) {
                        //        pools.push(pool);
                        //    }
                        //}
                        pools.push(pool);
                    }
                    for (var m = 0; m < pools.length; m++) {
                        var one = pools[m];
                        one.index = m + 1;
                        if (one.poolType == 0) {
                            one.needBookFlg = true;
                            needBookools.push(one);
                        } else {
                            one.needBookFlg = false;
                        }
                    }
                    $scope.getPoolsInRegion();
                    $scope.searchPoolBooks(needBookools);
                }
            });
        }

        /**
         * region 包含的 pools
         */
        $scope.getPoolsInRegion = function (obj) {
            for (var i = 0; i < regions.length; i++) {
                var region = regions[i];
                region.poolsInRegion = [];
                for (var j = 0; j < pools.length; j++) {
                    var pool = pools[j];
                    if (region.id == pool.region) {
                        region.poolsInRegion.push(pool);
                    }
                }
            }
            $scope.regions = regions;
            $scope.pools = pools;

        }
        /**
         * search all  books
         */
        $scope.searchPoolBooks = function (needBookools) {
            var condition = new Object();
            $http.post('/searchBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                } else if (result && result.length > 0) {
                    allBooks = result;
                    var urgentShowFlg = $scope.checkCanUseUrgent(needBookools);
                    $scope.urgentShowFlg = urgentShowFlg;

                    $scope.searchBookings();
                }
            });
        }
        /**
         *  check Urgent can use
         */
        $scope.checkCanUseUrgent = function (needBookpools) {
            var time = new Date().valueOf();
            var flg = false;
            for (var m = 0; m < needBookpools.length; m++) {
                var poolDetail = needBookpools[m];

                var infos = [];
                for (var j = 0; j < allBooks.length; j++) {
                    var book = allBooks[j];
                    if (book.bookPool == poolDetail.id) {
                        infos.push(book);
                    }
                }
                var outs = [];
                for (var i = 0; i < infos.length; i++) {
                    var obj = infos[i];
                    var start = new Date(obj.bookStart);
                    var end = new Date(obj.bookEnd);
                    if (time >= (start.valueOf() - 8 * 60 * 60 * 1000) && time <= (end.valueOf() - 8 * 60 * 60 * 1000)) {
                        outs.push(obj);
                    }
                }
                if (outs.length < poolDetail.maxUser) {
                    flg = false;
                } else {
                    flg = true;
                }
                if (flg) {
                    break;
                }
            }
            return flg;
        }
        /**
         * click region
         * @param obj
         */
        $scope.poolChange = function (obj) {
            var region = obj;
            var condiPools = [];
            for (var i = 0; i < pools.length; i++) {
                var one = pools[i];
                if (region.id == one.region) {
                    condiPools.push(one);
                }
            }
            for (var n = 0; n < condiPools.length; n++) {
                var one = condiPools[n];
                one.index = n + 1;
            }
            $scope.pools = condiPools;
        }
        $scope.changeRegion = function (obj) {
            var type = obj.index;
            for (var i = 1; i < 50; i++) {
                if ((type + "") == (i + "")) {
                    angular.element('#_resources_region_' + i).addClass('book-top-selected');
                    angular.element('#_resources_region_' + i).removeClass('book-top-button');
                } else {
                    angular.element('#_resources_region_' + i).removeClass('book-top-selected');
                    angular.element('#_resources_region_' + i).addClass('book-top-button');
                }
            }
            $scope.poolChange(obj);
        }

        /**
         * search next Booking
         */
        $scope.bookPoolName = "";
        $scope.nextBookStart = new Object();
        $scope.nextBookEnd = new Object();
        $scope.searchBookings = function () {
            var condition = new Object();
            $http.post('/searchNextBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Search Data Error", "danger");
                } else if (result && result.length > 0) {
                    for (var i = 0; i < result.length; i++) {
                        var one = result[i];
                        // search region name
                        for (var n = 0; n < regions.length; n++) {
                            var region = regions[n];
                            if (one.bookRegion == region.id) {
                                one.bookRegionName = region.regionName;
                            }
                        }
                        /**
                         * set pool name
                         */
                        for (var m = 0; m < pools.length; m++) {
                            var pool = pools[m];
                            if (one.bookPool == pool.id) {
                                one.bookPoolName = pool.poolName;
                            }
                        }
                    }
                    $scope.getAndSetNextBook(result);
                }
            });
        }
        /**
         * get and set next  booking
         */
        $scope.getAndSetNextBook = function (result) {
            //console.log(result);
            var now = new Date().valueOf();
            var books = [];
            for (var i = 0; i < result.length; i++) {
                var one = result[i];
                if (loginUser.loginName.toLowerCase() == one.userName.toLowerCase()) {
                    books.push(one);
                }
            }
            for (var m = 0; m < books.length; m++) {
                var one = books[m];
                var startTime = new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000;
                if (startTime > now && one.status < 2) {
                    nextBook = one;
                    /**
                     * get pool name
                     */
                    for (var n = 0; n < pools.length; n++) {
                        var pool = pools[n];
                        if (one.bookPool == pool.id) {
                            $scope.bookPoolName = pool.poolName;
                            $scope.bookPoolCode = pool.poolCode;
                            // console.log($scope.bookPoolName);
                        }
                    }
                    /**
                     * get and set next  booking
                     */
                    var start = new Date(new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                    var nextBookStart = new Object();
                    nextBookStart.year = start.getFullYear();
                    nextBookStart.month = start.getMonth() + 1 < 10 ? "0" + (start.getMonth() + 1) : start.getMonth() + 1;
                    nextBookStart.day = start.getDate() < 10 ? "0" + start.getDate() : start.getDate();
                    nextBookStart.hour = start.getHours();
                    nextBookStart.minite = start.getMinutes() == 0 ? "00" : start.getMinutes();
                    $scope.nextBookStart = nextBookStart;
                    var end = new Date(new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
                    var nextBookEnd = new Object();
                    nextBookEnd.year = end.getFullYear();
                    nextBookEnd.month = end.getMonth() + 1 < 10 ? "0" + (end.getMonth() + 1) : end.getMonth() + 1;
                    nextBookEnd.day = end.getDate() < 10 ? "0" + end.getDate() : end.getDate();
                    nextBookEnd.hour = end.getHours();
                    nextBookEnd.minite = end.getMinutes() == 0 ? "00" : end.getMinutes();
                    $scope.nextBookEnd = nextBookEnd;
                    break;
                }
            }

            if (nextBook == null) {
                $scope.nextBookShow = false;
                Notify.alert("No Next Booking", "danger");
                return;
            }

        }

        /**
         * login to agent ( interface )
         */
        $scope.loginOn = function () {


            console.log("----------loginOn----------");
            console.log(nextBook);
            if (nextBook != null) {
                var postUrl = "";
                var condition = JSON.stringify(nextBook);
                $http.post(postUrl, condition).success(function (result) {
                    $scope.loginOnAgent(result);
                });
            } else {
                Notify.alert("No Next Booking", "danger");
                return;
            }
        }
        /**
         * agent login on
         */
        $scope.loginOnAgent = function (condi) {

            if (nextBook != null) {
                var condition = nextBook;
                condition.remarks = "";
                condition.status = 1;
                condition.agentName = "";
                condition.useStart = new Date(new Date().valueOf() + 8 * 60 * 60 * 1000);

                // 判断 当前时间点是否有预定信息
                var book_start = new Date(nextBook.bookStart).valueOf();
                var book_end = new Date(nextBook.bookEnd).valueOf();
                if (condition.useStart.valueOf() < book_start || condition.useStart.valueOf() > book_end) {
                    Notify.alert("No booking now", "danger");
                    return;
                }
                var postUrl = "/updateLoginBook";
                $http.post(postUrl, condition).success(function (result) {
                    var msg = result ? "Login Success" : "Login Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        $scope.loginFlg = false;

                        // TODO 通过网站系统登陆到Agent
                        var vdiStr = "vmware-view://" + "vdichina.jia.volvocars.net"
                            + "/cn=" + $scope.bookPoolCode
                            + ",ou=applications,dc=vdi,dc=vmware,dc=int";
                        console.log(vdiStr);
                        location.href = vdiStr;
                    }
                });
            } else {
                Notify.alert("No Next Booking", "danger");
                return;
            }
        }

    }]);