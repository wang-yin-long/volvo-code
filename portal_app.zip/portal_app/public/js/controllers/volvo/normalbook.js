/**
 * Module: CalendarController.js   Calendar and Events  wangyl   update   2016-04-08
 * events and events creations
 */
App.controller('CalendarController', ['$scope', '$http', '$stateParams', '$state', '$timeout', 'ngDialog', 'Notify',
    function ($scope, $http, $stateParams, $state, $timeout, ngDialog, Notify) {

        if (!$.fn.fullCalendar) return;
        // global shared var to know what we are dragging
        var draggingEvent = null;

        var datas = []; // all events
        var infos = [];
        var loginUser = null;
        /**
         * url  params
         */
        var poolId = $stateParams.userpoolid;
        var poolDetail = null;
        /**
         * search Login
         */
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.loginName = loginUser.loginName;
                    $scope.searchPolicyManage();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        // 获取 配置信息
        $scope.searchPolicyManage = function () {
            var condition = new Object();
            $http.post('/searchAgentTime', condition).success(function (data) {
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    var configs = data;
                    for (var n = 0; n < configs.length; n++) {
                        var one = configs[n];
                        if (one.dataKey == "MinBookTime") {
                            $scope.minBookTime = one;
                        }
                        if (one.dataKey == "MaxBookTime") {
                            $scope.maxBookTime = one;
                        }
                    }
                    $scope.initPool();
                }
            });

        }

        /**
         * search Pools
         */
        $scope.initPool = function () {
            var condition = new Object();
            condition.id = poolId;
            $http.post('/searchOnePool', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    poolDetail = result[0];
                    $scope.poolDetail = poolDetail;
                    $scope.initBooks();

                }
            });
        }
        $scope.srchPoolBook = function () {
            infos = [];
            var condition = new Object();
            $http.post('/searchBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                } else if (result && result.length > 0) {
                    infos = [];
                    for (var i = 0; i < result.length; i++) {
                        var book = result[i];
                        if (book.bookPool == poolDetail.id) {
                            infos.push(book);
                        }
                    }
                }
            });
        }
        /**
         * search Books
         */
        $scope.initBooks = function () {
            var books = [];
            var condition = new Object();
            $http.post('/searchBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                } else if (result && result.length > 0) {
                    for (var i = 0; i < result.length; i++) {
                        var book = result[i];
                        if (loginUser.loginName.toLowerCase() == book.userName.toLowerCase() && book.bookPool == poolDetail.id) {
                            books.push(book);
                        }
                    }
                    $scope.initView(books);
                    $scope.srchPoolBook();
                } else {
                    $scope.initView(books);
                }
            });
        }
        /**
         * init Calendar and Events
         */
        function initCalendar(calElement, events) {
            // check to remove elements from the list
            var removeAfterDrop = $('#remove-after-drop');
            calElement.fullCalendar({
                isRTL: $scope.app.layout.isRTL,
                header: {
                    left: 'prev,next today', center: 'title', right: 'month,agendaWeek,agendaDay'
                },
                buttonIcons: {
                    prev: ' fa fa-caret-left', next: ' fa fa-caret-right'
                },
                buttonText: {
                    today: 'today', month: 'month', week: 'week', day: 'day'
                },
                firstHour: 8,
                scrollTime:'08:00:00',
                contentHeight:600,
                defaultView: 'agendaWeek',
                allDaySlot:false,
                editable: true,
                droppable: true,
                events: events,
                drop: function (date, allDay) {
                    var $this = $(this),
                        originalEventObject = $this.data('calendarEventObject');
                    if (!originalEventObject) return;
                    var clonedEventObject = $.extend({}, originalEventObject);
                    clonedEventObject.start = date;
                    clonedEventObject.allDay = allDay;
                    clonedEventObject.backgroundColor = $this.css('background-color');
                    clonedEventObject.borderColor = $this.css('border-color');
                    calElement.fullCalendar('renderEvent', clonedEventObject, true);
                    if (removeAfterDrop.is(':checked')) {
                        $this.remove();
                    }
                },
                dayClick: function (event, js, ui) {
                    var time = event._d.valueOf() - 8 * 60 * 60 * 1000;
                    $scope.addBookEvent(new Date(time), "clickCalendar");
                },
                eventDragStart: function (event, js, ui) {
                    // Events Moving
                    draggingEvent = event;
                },
                eventDrop: function (event, js, ui) {
                    // Events Drop
                    draggingEvent = event;
                    refreshCalendar(event, "");
                },
                eventResize: function (event, js, ui) {
                    // Events reSize
                    draggingEvent = event;
                    refreshCalendar(event, "");
                },
                eventClick: function (event, js, ui) {
                    draggingEvent = event;
                    // Events Update Dialog
                    ngDialog.openConfirm({
                        template: 'nomalBookEventDialog',
                        className: 'ngdialog-theme-default',
                        data: {bookObj: event}
                    }).then(function (value) {
                        draggingEvent = value;

                        var calendar = $('#calendar');// get Calendar Object
                        var events = [];
                        var condition = new Object();
                        condition.id = value.id;
                        condition.description = value.title;
                        $http.post("/updateBookingDes", condition).success(function (result) {
                            var msg = result ? "Update Booking Success" : "Update Booking Error";
                            var type = result ? "success" : "danger";
                            Notify.alert(msg, type);
                            if (result) {
                                calendar.fullCalendar('removeEventSource', datas);
                                $scope.srchPoolBook();
                                // View Event Info Refresh
                                for (var i = 0; i < datas.length; i++) {
                                    var one = datas[i];
                                    if (one.id == value.id) {
                                        one.title = value.title;
                                        events.push(one);
                                    } else {
                                        events.push(one);
                                    }
                                }
                                datas = events;
                                calendar.fullCalendar('addEventSource', datas);
                            }
                        });
                    }, function (reason) {
                        // Events Update Dialog Confirm or Cancel
                        if (reason != "cancel" && reason != "$closeButton") {
                            refreshCalendar(reason, "del");
                        }
                    });
                }
            });
        }

        /**
         *  检测pool中是否预定满了
         */
        $scope.checkCanAddBook = function (s, e) {
            var outs = [];
            var time_S = (s.valueOf());
            var time_e = (e.valueOf());
            for (var i = 0; i < infos.length; i++) {
                var obj = infos[i];
                var start = new Date(obj.bookStart);
                var end = new Date(obj.bookEnd);
                console.log("-----" + time_S);
                console.log(start.valueOf());
                console.log(end.valueOf());
                console.log("-----" + time_e);
                if (time_S >= start.valueOf() && time_S < end.valueOf()) {
                    outs.push(obj);
                    continue;
                }
                if (time_e > start.valueOf() && time_e <= end.valueOf()) {
                    outs.push(obj);
                    continue;
                }
                if (time_S <= start.valueOf() && time_e >= end.valueOf()) {
                    outs.push(obj);
                    continue;
                }
            }
            console.log(outs.length);
            console.log(poolDetail.maxUser);
            if (outs.length < poolDetail.maxUser) {
                return false;
            } else {
                return true;
            }
        }
        /**
         *  click day to add book event   add by wyl
         */
        $scope.clickDayAddBookEvent = function (condi) {
            var calendar = $('#calendar');
            calendar.fullCalendar('removeEventSource', datas);
            var now = condi;
            //console.log(condi);
            var obj = new Object();
            obj.id = new Date().valueOf();
            obj.title = "My Booking";
            obj.start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() - 8, 0);
            obj.end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() - 6, 0);
            obj.allDay = false;
            obj.backgroundColor = '#1797be'; //blue
            obj.borderColor = '#1797be'; //blue
            datas.push(obj);
            calendar.fullCalendar('addEventSource', datas);
        }
        /**
         * click button add book event   add by wyl
         */
        $scope.addBookEvent = function (condition, type) {
            /**
             * init dialog info
             */
            var obj = new Object();
            obj.description = "";
            if (condition == "") { // 条件为空表示是add的情况
                obj.SDate = "";
                obj.SHour = 0;
                obj.SMinite = 0;
                obj.EDate = "";
                obj.EHour = 0;
                obj.EMinite = 0;
            } else { // 条件不为空表示是点击日历中得时间的情况
                //console.log(condition);
                obj.SDate = condition.getFullYear() + "/" + (condition.getMonth() + 1) + "/" + condition.getDate();
                obj.SHour = condition.getHours();
                obj.SMinite = condition.getMinutes();
                obj.EDate = condition.getFullYear() + "/" + (condition.getMonth() + 1) + "/" + condition.getDate();
                obj.EHour = condition.getHours() + 2;
                obj.EMinite = condition.getMinutes();
            }
            //console.log(obj);

            ngDialog.openConfirm({
                template: 'bookNewEvent',
                className: 'ngdialog-theme-default',
                data: {bookObj: obj}
            }).then(function (value) {
                var sdate = new Date(value.SDate);
                var edate = new Date(value.EDate);
                var condition = new Object();
                var start = new Date(sdate.getFullYear(), sdate.getMonth(), sdate.getDate(), value.SHour, value.SMinite);
                var end = new Date(edate.getFullYear(), edate.getMonth(), edate.getDate(), value.EHour, value.EMinite);
                condition.bookStart = new Date(start.valueOf() + 8 * 60 * 60 * 1000);
                condition.bookEnd = new Date(end.valueOf() + 8 * 60 * 60 * 1000);

                // 检查预定时间是否超出范围
                if (!$scope.checkTimeLimit(condition.bookStart, condition.bookEnd)) {
                    Notify.alert("Booking is too long or short", "danger");
                    return;
                }
                // 检查同一时间段  一个用户只能预定一次
                if (!$scope.checkCanSaveOrUpBook(condition)) {
                    Notify.alert("Booking is repetitious", "danger");
                    return;
                }

                // 检查pool中是否预定满了
                if ($scope.checkCanAddBook(condition.bookStart, condition.bookEnd)) {
                    Notify.alert(poolDetail.poolName + "  is  full at this time ", "danger");
                    return;
                }

                condition.description = value.description;
                condition.userId = loginUser.loginID;
                condition.userName = loginUser.loginName;
                condition.bookRegion = poolDetail.region;
                condition.bookPool = poolDetail.id;
                condition.status = 0;

                //console.log(condition);
                $http.post("/addBooking", condition).success(function (result) {
                    var msg = result ? "Book Success" : "Book Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        location.reload();
                        addBookLog();
                    }
                });
            }, function (reason) {
                // cancel or close dialog
            });

            $timeout(function () {
                // 条件为空表示是add的情况
                if (condition != "") {
                    angular.element('#new_book_sHour')[0].value = condition.getHours();
                    angular.element('#new_book_eHour')[0].value = condition.getHours() + 2;
                }
            }, 50);

        }
        /**
         * update or delete event   add by wyl
         */
        function refreshCalendar(event, type) {
            var calendar = $('#calendar');// get Calendar Object
            var events = [];
            if (type == "del") {
                if (event.id && event.id < 100000000000) { // 日历控件的vent的默认ID为很长的字符串
                    var condition = new Object();
                    condition.id = event.id;
                    $http.post('/delBooking', condition).success(function (result) {
                        var msg = result ? "Confirm Success" : "Confirm Error";
                        var type = result ? "success" : "danger";
                        Notify.alert(msg, type);
                        if (result) {
                            $scope.srchPoolBook();
                            calendar.fullCalendar("removeEvents", event._id);// delete Event
                        }
                    });
                } else {
                    calendar.fullCalendar("removeEvents", event._id);// delete Event
                    $scope.srchPoolBook();
                }
                // refresh events
                calendar.fullCalendar('removeEventSource', datas);
                var outs = [];
                for (var i = 0; i < datas.length; i++) {
                    var one = datas[i];
                    if (one.id != event.id) {
                        outs.push(one);
                    }
                }
                datas = outs;
                calendar.fullCalendar('addEventSource', datas);

            } else {
                var changeFlg = false;
                var start = null;
                var end = null;
                if (event._start != null) {
                    // if date bookstart or bookend change
                    for (var j = 0; j < datas.length; j++) {
                        var one = datas[j];
                        if (one.id && one.id == event.id) {
                            if (one.start.valueOf() == event._start._d.valueOf()
                                && one.end.valueOf() == event._end._d.valueOf()) {
                                changeFlg = true;
                            }
                        }
                    }
                    // event start and end time
                    start = new Date(changeFlg ? event._start._d.valueOf() + 8 * 60 * 60 * 1000 : event._start._d.valueOf());
                    end = new Date(changeFlg ? event._end._d.valueOf() + 8 * 60 * 60 * 1000 : event._end._d.valueOf());
                }
                // Update or Add Event
                var condition = new Object();
                var URL = "";
                var add = true;
                condition.bookStart = start;
                condition.bookEnd = end;
                if (!$scope.checkTimeLimit(start, end)) {
                    Notify.alert("Booking is too long or short", "danger");
                    return;
                }
                condition.description = event.title;
                if (event.id && event.id != 0 && event.id < 100000000000) { // 日历控件的vent的默认ID为很长的字符串
                    condition.id = event.id;
                    URL = "/updateBooking";
                    add = false;
                } else {
                    condition.userId = loginUser.loginID;
                    condition.userName = loginUser.loginName;
                    condition.bookRegion = poolDetail.region;
                    condition.bookPool = poolDetail.id;
                    condition.status = 0;
                    URL = "/addBooking";
                    add = true;
                }
                if (add && !$scope.checkCanSaveOrUpBook(condition)) {
                    Notify.alert("Booking is repetitious", "danger");
                    $timeout(function () {
                        location.reload();
                    }, 2000);
                }

                $http.post(URL, condition).success(function (result) {
                    var msg = result ? "Update Booking Success" : "Update Booking Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        $scope.srchPoolBook();
                        calendar.fullCalendar('removeEventSource', datas);
                        // View Event Info Refresh
                        var flg = true;
                        for (var i = 0; i < datas.length; i++) {
                            var one = datas[i];
                            if (one.id == event.id) {
                                events.push(event);
                                flg = false;
                            } else {
                                events.push(one);
                            }
                        }
                        if (flg) {
                            events.push(event);
                        }
                        datas = events;
                        calendar.fullCalendar('addEventSource', datas);
                        if (add) {
                            addBookLog();
                        }
                    }
                });
            }
        }

        /**
         *  检查 预定时间是否超出范围
         */
        $scope.checkTimeLimit = function (start, end) {
            var flg = false;
            var xiangcha = (end.valueOf() - start.valueOf()) / (60 * 60 * 1000);
            //console.log(xiangcha);
            //console.log(Number($scope.minBookTime.value));
            //console.log(Number($scope.maxBookTime.value));
            if (xiangcha >= Number($scope.minBookTime.value) && xiangcha <= Number($scope.maxBookTime.value)) {
                flg = true;
            } else {
                flg = false;
            }
            return flg;
        }

        /**
         *  check can save or update book
         */
        $scope.checkCanSaveOrUpBook = function (condition) {
            var time_S = condition.bookStart.valueOf() - 8 * 60 * 60 * 1000;
            var time_e = condition.bookEnd.valueOf() - 8 * 60 * 60 * 1000;
            var flg = true;
            for (var i = 0; i < datas.length; i++) {
                var obj = datas[i];
                var start = new Date(obj.start);
                var end = new Date(obj.end);
                if (time_S >= start.valueOf() && time_S < end.valueOf()) {
                    flg = false;
                    break;
                }
                if (time_e > start.valueOf() && time_e <= end.valueOf()) {
                    flg = false;
                    break;
                }
                if (time_S <= start.valueOf() && time_e >= end.valueOf()) {
                    flg = false;
                    break;
                }
            }
            return flg;
        }
        /**
         * add  book log
         */
        function addBookLog() {
            var URL = "/addLogs";
            var condition = new Object();
            condition.logType = 1;
            condition.userId = loginUser.loginID;
            condition.userName = loginUser.loginName;
            condition.logTime = new Date(new Date().valueOf() + 8 * 60 * 60 * 1000);
            condition.region = poolDetail.region;
            condition.pool = poolDetail.id;
            condition.adGroup = 0;
            condition.agentName = "";
            condition.status = 0;
            condition.description = "Normal Booking";
            $http.post(URL, condition).success(function (result) {
                var msg = result ? "Add Log Success" : "Add Log  Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
            });
        }

        /**
         * Creates an array of events to display in the first load of the calendar
         */
        function createDemoEvents(books) {
            var returnInfos = [];
            if (books.length && books.length > 0) {
                for (var i = 0; i < books.length; i++) {
                    var book = books[i];
                    // books  in  which  pool
                    if (book.bookRegion == poolDetail.region && book.bookPool == poolDetail.id) {
                        var start = book.bookStart;
                        var end = book.bookEnd;

                        var returnInfo = new Object();
                        returnInfo.id = book.id;
                        returnInfo.title = book.description;
                        returnInfo.start = new Date(new Date(start).valueOf() - 8 * 60 * 60 * 1000);
                        returnInfo.end = new Date(new Date(end).valueOf() - 8 * 60 * 60 * 1000);
                        returnInfo.allDay = false;
                        returnInfo.backgroundColor = '#1797be'; //blue
                        returnInfo.borderColor = '#1797be'; //blue
                        returnInfos.push(returnInfo);
                    }
                }
            }
            return returnInfos;
        }

        /**
         * init calendar and events
         */
        $scope.initView = function (books) {
            var calendar = $('#calendar');
            var demoEvents = createDemoEvents(books);
            datas = demoEvents;
            initCalendar(calendar, demoEvents);
        }

    }]);

/**
 *  my book detail drop down
 */
App.controller('MyBookDetailDropCtrl', ['$rootScope', '$scope', function ($rootScope, $scope) {
    var hours = [];
    for (var m = 1; m < 25; m++) {
        var obj = new Object();
        obj.key = m + "";
        obj.value = m + "";
        hours.push(obj);
    }
    $scope.dropHours = hours;
}]);