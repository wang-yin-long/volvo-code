/**
 * add  by  wyl  2016.04.20
 */
App.controller('NormalUserApplyCtrl', ['$rootScope', '$scope', '$state', '$http', '$timeout', 'Notify',
    function ($rootScope, $scope, $state, $http, $timeout, Notify) {

        var loginUser = null;
        var regions = [];
        var pools = [];
        var selectRegion = null;
        var selectPool = null;
        $scope.regionListId = "_apply_region_";
        $scope.poolListId = "_apply_pool_";
        $scope.applyDescription = "";
        /**
         * search Login
         */
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.loginName = loginUser.loginName;
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * search regions
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    for (var i = 0; i < regions.length; i++) {
                        var one = regions[i];
                        one.index = i + 1;
                    }
                    $scope.initPool();
                }
            });
        }
        $scope.initRegion();
        /**
         * search pools
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    for (var i = 0; i < pools.length; i++) {
                        var one = pools[i];
                        one.index = i + 1;
                    }
                    $scope.regions = regions;
                    if (regions && regions.length > 0) {
                        $scope.poolChange(regions[0]);// 第一个region对应的pool
                        // 默认选中第一个region
                        $timeout(function () {
                            angular.element('#_apply_region_1').addClass('apply-region-selected');
                            angular.element('#_apply_region_1').removeClass('apply-region-button');
                        }, 50);
                    }
                }
            });
        }

        // region点击变化,得到对应的pool
        $scope.poolChange = function (obj) {
            selectRegion = obj;
            var region = obj;
            var condiPools = [];
            for (var i = 0; i < pools.length; i++) {
                var one = pools[i];
                if (region.id == one.region) {
                    condiPools.push(one);
                }
            }
            for (var n = 0; n < condiPools.length; n++) {
                var one = condiPools[n];
                one.index = n + 1;
            }
            $scope.pools = condiPools;
        }
        $scope.selectApplyRegion = function (obj) {
            var type = obj.index;
            for (var i = 1; i < 20; i++) {
                if ((type + "") == (i + "")) {
                    angular.element('#_apply_region_' + i).addClass('apply-region-selected');
                    angular.element('#_apply_region_' + i).removeClass('apply-region-button');
                } else {
                    angular.element('#_apply_region_' + i).removeClass('apply-region-selected');
                    angular.element('#_apply_region_' + i).addClass('apply-region-button');
                }
            }
            $scope.poolChange(obj);
        }
        $scope.selectApplyPool = function (obj) {
            selectPool = obj;
            var type = obj.index;
            for (var i = 1; i < 20; i++) {
                if ((type + "") == (i + "")) {
                    angular.element('#_apply_pool_' + i).addClass('apply-region-selected');
                    angular.element('#_apply_pool_' + i).removeClass('apply-region-button');
                } else {
                    angular.element('#_apply_pool_' + i).removeClass('apply-region-selected');
                    angular.element('#_apply_pool_' + i).addClass('apply-region-button');
                }
            }
        }

        /**
         * save apply info
         */
        $scope.confirmInfo = function () {
            var apply = new Object();
            apply.userID = loginUser != null ? loginUser.loginID : "";
            apply.userName = loginUser != null ? loginUser.loginName : "";
            apply.applyRegion = selectRegion != null ? selectRegion.id : 0;
            apply.applyPool = selectPool != null ? selectPool.id : 0;
            apply.applyGroup = 0;
            apply.status = 0;
            apply.description = $scope.applyDescription;
            console.log(apply);

            $http.post("/addApply", apply).success(function (result) {
                var msg = result ? "Apply Success" : "Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
            });
        }

    }]);