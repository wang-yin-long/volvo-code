/**=========================================================
 * Module: NGTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('MyBookingTableCtrl', MyBookingTableCtrl);
function MyBookingTableCtrl($scope, $filter, ngTableParams, $http, $timeout, $state, Notify, ngDialog) {

    var allbooks = [];
    var loginUser = null;
    /**
     * search Login
     */
    $scope.initLogin = function (type) {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.loginName = loginUser.loginName;
                $scope.initRegion();
                if (type == "1"){
                    Notify.alert("Refresh success", "success");
                }
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin("");

    $scope.refreshInitLogin = function () {
        $scope.initLogin("1");
    }
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regions = result;
                $scope.initPool(regions);
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $scope.searchBookings(regions, pools);
            }
        });
    }
    /**
     * search Booking
     * @param regions
     * @param pools
     */
    var nowTime = new Date().valueOf();
    $scope.searchBookings = function (regions, pools) {
        var data = [];
        var condition = new Object();
        $http.post('/searchBooking', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
            } else if (result && result.length > 0) {
                for (var i = 0; i < result.length; i++) {
                    var one = result[i];
                    var s_str = new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000;
                    var e_str = new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000;
                    var start = new Date(s_str);
                    var end = new Date(e_str);

                    one.overdueFlg = false;
                    if (e_str <= nowTime) {
                        one.overdueFlg = true;
                    }
                    if (one.status > 1) {
                        one.overdueFlg = true;
                    }

                    var sMonth = start.getMonth() + 1 < 10 ? "0" + (start.getMonth() + 1) : start.getMonth() + 1;
                    var eMonth = end.getMonth() + 1 < 10 ? "0" + (end.getMonth() + 1) : end.getMonth() + 1;
                    var sMinite = start.getMinutes() == 0 ? "00" : start.getMinutes();
                    var eMinite = end.getMinutes() == 0 ? "00" : end.getMinutes();
                    var SDay = start.getDate() < 10 ? "0" + start.getDate() : start.getDate();
                    var EDay = end.getDate() < 10 ? "0" + end.getDate() : end.getDate();
                    var SHour = start.getHours() < 10 ? "0" + start.getHours() : start.getHours();
                    var EHour = end.getHours() < 10 ? "0" + end.getHours() : end.getHours();

                    one.bookStartView = start.getFullYear() + "-" + sMonth + "-" + SDay + " " + SHour + ":" + sMinite;
                    one.bookEndView = end.getFullYear() + "-" + eMonth + "-" + EDay + " " + EHour + ":" + eMinite;
                    /**
                     *  search region name
                     */
                    for (var n = 0; n < regions.length; n++) {
                        var region = regions[n];
                        if (one.bookRegion == region.id) {
                            one.bookRegionName = region.regionName;
                        }
                    }
                    /**
                     * get pool name
                     */
                    for (var m = 0; m < pools.length; m++) {
                        var pool = pools[m];
                        if (one.bookPool == pool.id) {
                            one.bookPoolName = pool.poolName;
                        }
                    }
                    if (loginUser.loginName.toLowerCase() == one.userName.toLowerCase()) {
                        data.push(one);
                    }
                }
                allbooks = data;
                $scope.initTableList(data);
            }
        });
    }

    $scope.initTableList = function (data) {

        for (var i = 0; i < data.length; i++) {
            var one = data[i];
            one.index = i + 1;
        }
        $scope.data = data;
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {
                    userName: '',
                    bookPoolName: '',
                    description: ''
                }
            },
            {
                total: $scope.data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * delete Booking
     */
    $scope.deleteInfo = function (obj) {
        ngDialog.openConfirm({
            template: 'confirmDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            $http.post('/delBooking', condition).success(function (result) {
                var msg = result ? "Delete Success" : "Delete Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    // location.reload();
                    var backs = [];
                    for (var i = 0; i < allbooks.length; i++) {
                        var onebook = allbooks[i];
                        if (obj.id != onebook.id) {
                            backs.push(onebook);
                        }
                    }
                    for (var z = 0; z < backs.length; z++) {
                        var oo = backs[z];
                        oo.index = z + 1;
                    }
                    // 列表刷新
                    allbooks = backs;
                    $scope.data = backs;
                    $scope.tableParams2.reload();
                }
            });
        }, function (reason) {
        });
    }
}

/**
 * my Booking Detail Ctrl
 */
App.controller('MyBookingDetailCtrl', ['$scope', '$http', '$state', '$timeout', '$stateParams', "Notify",
    function ($scope, $http, $state, $timeout, $stateParams, Notify) {
        /**
         * url  params
         */
        var bookid = $stateParams.mybookingid;
        /**
         * init condition
         */
        var regions = [];
        var pools = [];
        var hours = [];
        for (var m = 1; m < 25; m++) {
            var obj = new Object();
            obj.key = m + "";
            obj.value = m + "";
            hours.push(obj);
        }
        $scope.hours = hours;
        /**
         * init time info
         * @type {Object}
         */
        var startTime = new Object();
        startTime.hour = "";
        startTime.minute = "";
        $scope.startTime = startTime;
        var endTime = new Object();
        endTime.hour = "";
        endTime.minute = "";
        $scope.endTime = endTime;
        /**
         * search region dropdown
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    $scope.regionDrop = result;
                    $scope.initPool();
                }
            });
        }
        $scope.initRegion();
        /**
         * search pool dropdown
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    $scope.poolDrop = result;
                    $timeout(function () {
                        $scope.initBookDetail();
                    }, 20);
                }
            });
        }
        /**
         * region change
         */
        $scope.regionChange = function () {
            var datas = [];
            var id = $scope.bookingDetail.bookRegion;
            for (var m = 0; m < pools.length; m++) {
                var pool = pools[m];
                if (id == pool.region) {
                    datas.push(pool);
                }
            }
            $scope.poolDrop = datas;
        }
        /**
         * search One Booking
         * @type {Object}
         */
        $scope.initBookDetail = function () {
            var condition = new Object();
            condition.id = bookid;
            $http.post('/searchOneBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (result && result.length > 0) {
                    $scope.bookingDetail = result[0];
                    $scope.detailInitTime(result[0]);
                }
            });
        }
        $scope.detailInitTime = function (obj) {
            var start = new Date(new Date(obj.bookStart).valueOf() - 8 * 60 * 60 * 1000);
            var end = new Date(new Date(obj.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
            var sMonth = start.getMonth() + 1;
            var eMonth = end.getMonth() + 1;
            $scope.bookStart = start.getFullYear() + "/" + sMonth + "/" + start.getDate();
            $scope.bookEnd = end.getFullYear() + "/" + eMonth + "/" + end.getDate();
            $scope.startTime.hour = start.getHours();
            $scope.startTime.minute = start.getMinutes();
            $scope.endTime.hour = end.getHours();
            $scope.endTime.minute = end.getMinutes();
        }
        /**
         * booking detail update
         * @param condi
         */
        $scope.updateBookingDetail = function () {
            var condition = $scope.bookingDetail;
            var startC = angular.element('#_book_start_id')[0].value;
            var endC = angular.element('#_book_end_id')[0].value;
            condition.bookStart = $scope.getDateTime(startC, $scope.startTime.hour, $scope.startTime.minute);
            condition.bookEnd = $scope.getDateTime(endC, $scope.endTime.hour, $scope.endTime.minute);
            /**
             * http post
             * @type {string}
             */
            var postUrl = "/updateBooking";
            $http.post(postUrl, condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    $state.go('app.mybooking');
                }
            });
        }
        /**
         * get date time by condition
         * @param condi
         */
        $scope.getDateTime = function (dateString, hh, mm) {
            if (dateString != "" && dateString.indexOf("/") >= 0) {
                var strs = dateString.split("/");
                var out = new Date(strs[0], strs[1] - 1, strs[2], hh, mm);
                return new Date(out.valueOf() + 8 * 60 * 60 * 1000);
            } else {
                return "";
            }
        }

    }]);

