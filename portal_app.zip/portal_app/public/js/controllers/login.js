/**
 * Module: access-login.js
 * Demo for login api
 */
App.controller('LoginFormController', ['$scope', '$http', '$state', '$timeout', 'ngDialog', 'Notify',
    function ($scope, $http, $state, $timeout, ngDialog, Notify) {

        var obj = new Object();
        obj.type = 1;
        $scope.account = obj;
        $scope.authMsg = '';
        var FAQ = null;
        var callAdmin = null;
        var adConfig = null;
        /**
         * search  FAQ and CallAdmin
         */
        $scope.searchFaqCallAdmin = function () {
            var condition = new Object();
            $http.post('/searchAgentTime', condition).success(function (data) {
                if (data == "Error") {
                    console.log("Get FAQ and CallAdmin Error");
                } else if (data && data.length > 0) {
                    var configs = data;
                    for (var n = 0; n < configs.length; n++) {
                        var one = configs[n];
                        if (one.dataKey == "FAQ") {
                            FAQ = one;
                        }
                        if (one.dataKey == "CallAdmin") {
                            callAdmin = one;
                        }
                    }

                    $scope.searchADConfig();
                }
            });

        }
        $scope.searchFaqCallAdmin();
        /**
         * search  Ldap config
         */
        $scope.searchADConfig = function () {
            var condition = new Object();
            $http.post('/searchADInfo', condition).success(function (data) {
                // console.log(data);
                if (data == "Error") {
                    console.log("Search AD Config Error");
                } else if (data && data.length > 0) {
                    adConfig = data[0];
                }
            });
        }
        /**
         *
         * @param type user or bussines or admin
         */
        $scope.login = function (type) {
            $scope.authMsg = '';
            var user = $scope.account;
            user.adConfig = adConfig;
            user.loginType = type;
            // check login
            if ($scope.loginForm.$valid) {
                // normal user Ldap check
                if (type == "1") {
                    $http.post('/login', user).success(function (result) {
                        if (result) {
                            $state.go('app.home');
                        } else {
                            Notify.alert(" UserName or Password  Error ", "danger");
                            return;
                        }
                    });
                }
                // normal admin check
                if (type == "2") {
                    $http.post('/bizLogin', user).success(function (result) {
                        if (result) {
                            $http.post('/login', user).success(function (result) {
                                if (result) {
                                    $state.go('biz.policymanage');
                                } else {
                                    Notify.alert(" UserName or Password  Error ", "danger");
                                    return;
                                }
                            });
                        } else {
                            Notify.alert(" No Permissions ", "danger");
                            return;
                        }
                    });
                }
                // root admin check
                if (type == "3") {
                    if (user.name == "ucproot") {
                        $http.post('/rootAccount', user).success(function (result) {
                            if (result) {
                                $state.go('root.adconfig');
                            } else {
                                Notify.alert(" UserName or Password  Error ", "danger");
                                return;
                            }
                        });
                    } else {
                        $http.post('/rootLogin', user).success(function (result) {
                            if (result) {
                                $http.post('/login', user).success(function (result) {
                                    if (result) {
                                        $state.go('root.adconfig');
                                    } else {
                                        Notify.alert(" UserName or Password  Error ", "danger");
                                        return;
                                    }
                                });
                            } else {
                                Notify.alert(" No Permissions ", "danger");
                                return;
                            }
                        });
                    }
                }
            } else {
                // 表单验证不通过
                $scope.loginForm.account_email.$dirty = true;
                $scope.loginForm.account_password.$dirty = true;
            }
        };
        /**
         * open FAQ or CallAdmin
         */
        $scope.openFaqOrCallAdmin = function (type) {
            var condition = new Object();
            if (type == "faq") {
                condition.content = FAQ != null ? FAQ.value : "";
                condition.title = "FAQ";
            } else {
                condition.content = callAdmin != null ? callAdmin.value : "";
                condition.title = "Call Admin";
            }
            ngDialog.openConfirm({
                template: 'confirmDialogId',
                className: 'ngdialog-theme-default',
                data: {condition: condition}
            }).then(function (value) {
                // confirm
            }, function (reason) {
                // cancel
            });
        }

    }]);

/**
 * User Block Controller
 */
App.controller('UserBlockController', ['$scope', '$http', '$state', 'Notify', function ($scope, $http, $state, Notify) {

    $scope.userBlockVisible = false;

    var loginUser = null;
    $scope.initLogin = function () {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.loginUser = loginUser;
            } else {
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin();

    $scope.$on('toggleUserBlock', function (event, args) {

        $scope.userBlockVisible = !$scope.userBlockVisible;

    });

}]);