/**=========================================================
 * Module: ApplyLIstTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('ApplyListTableCtrl', ApplyListTableCtrl);
function ApplyListTableCtrl($scope, $filter, ngTableParams, ngDialog, $timeout, $http, $state, Notify) {

    var allApplys = [];
    /**
     * search Login
     */
    var loginUser = null;
    $scope.initLogin = function () {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.initRegion();
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin();
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regions = result;
                $scope.initPool(regions);
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $scope.searchApplys(regions, pools);
            }
        });
    }
    /**
     * search Apply
     * @param regions
     * @param pools
     */
    $scope.searchApplys = function (regions, pools) {
        var data = [];
        var condition = new Object();
        $http.post('/searchApply', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
            } else if (result && result.length > 0) {
                data = result;
                for (var i = 0; i < data.length; i++) {
                    var one = data[i];
                    one.index = i + 1;
                    if (one.status == 1) {
                        one.statusName = "Yes";
                        one.statusStyle = "apply-yes";
                    } else if (one.status == 2) {
                        one.statusName = "No";
                        one.statusStyle = "apply-no";
                    } else {
                        one.statusName = "Pending";
                        one.statusStyle = "apply-pending";
                    }
                    // search region name
                    for (var n = 0; n < regions.length; n++) {
                        var region = regions[n];
                        if (one.applyRegion == region.id) {
                            one.regionName = region.regionName;
                        }
                    }
                    // search pool name
                    for (var m = 0; m < pools.length; m++) {
                        var pool = pools[m];
                        if (one.applyPool == pool.id) {
                            one.poolName = pool.poolName;
                        }
                    }
                }
                allApplys = data;
                $scope.initTableList(data);
            }
        });

    }

    $scope.initTableList = function (data) {
        $scope.data = data;
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {}
            },
            {
                total: $scope.data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * Apply status Update
     */
    $scope.updateApplyStatus = function (condition) {
        $http.post('/updateApply', condition).success(function (result) {
            var msg = result ? "Success" : "Error";
            var type = result ? "success" : "danger";
            Notify.alert(msg, type);
            if (result) {
                // location.reload();
                for (var i = 0; i < allApplys.length; i++) {
                    var oneapply = allApplys[i];
                    if (condition.id == oneapply.id) {
                        if (oneapply.status == 1) {
                            oneapply.statusName = "Yes";
                            oneapply.statusStyle = "apply-yes";
                        } else if (oneapply.status == 2) {
                            oneapply.statusName = "No";
                            oneapply.statusStyle = "apply-no";
                        } else {
                            oneapply.statusName = "Pending";
                            oneapply.statusStyle = "apply-pending";
                        }
                    }
                }
                // 列表刷新
                $scope.data = allApplys;
                $scope.tableParams.reload();
            }
        });
    }
    /**
     * Apply Update
     * @param condi
     */
    $scope.updateApply = function (obj) {
        ngDialog.openConfirm({
            template: 'confirmDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            condition.status = 1;
            $scope.updateApplyStatus(condition);

        }, function (reason) {
            if (reason == "NO") {
                var condition = obj;
                condition.status = 2;
                $scope.updateApplyStatus(condition);
            }
        });
    }

}
