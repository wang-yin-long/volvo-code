/**
 * user  book  statistic  -> UserStatChartCtrl
 */
App.controller('UserStatChartCtrl', UserStatChartCtrl);
function UserStatChartCtrl($scope, $http, $state, Notify, ngDialog) {

    var bookUsing = [];
    var books = [];
    var loginUser = null;
    var condition = new Object();
    condition.startTime = null;
    condition.endTime = null;
    condition.selectUser = 0;
    condition.selectPeriod = 30;

    var nowTime = new Date();
    condition.nowDate = nowTime.getFullYear()
        + "-" + (nowTime.getMonth() + 1 < 10 ? "0" + (nowTime.getMonth() + 1) : nowTime.getMonth() + 1)
        + "-" + (nowTime.getDate() < 10 ? "0" + nowTime.getDate() : nowTime.getDate());

    $scope.condition = condition;

    $scope.showPeriodFlg = false;
    /**
     * search Login
     */
    $scope.initLogin = function () {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.searchBookings();
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin();
    /**
     * search Booking
     */
    $scope.searchBookings = function () {
        var users = [];
        var condition = new Object();
        $http.post('/searchBooking', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                books = result;
                for (var i = 0; i < books.length; i++) {
                    var one = books[i];
                    var flg = true;
                    for (var j = 0; j < users.length; j++) {
                        var user = users[j];
                        if (user.userName == one.userName) {
                            flg = false;
                        }
                    }
                    if (flg) {
                        users.push(one)
                    }
                }
                $scope.usersDrops = users;
                $scope.searchBookingsUsing();
            }
        });
    }
    /**
     * search Booking
     */
    $scope.searchBookingsUsing = function () {
        var condition = new Object();
        $http.post('/searchBookUsing', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Search using book error", "danger");
                return;
            } else if (result && result.length > 0) {
                // 默认显示第一个人得数据 , 姓名无先后顺序
                if ($scope.usersDrops && $scope.usersDrops.length > 0) {
                    $scope.condition.selectUser = $scope.usersDrops[0].userName;
                }
                bookUsing = result;
                $scope.initChart(result, loginUser.loginName, 30, "");
            }
        });
    }
    /**
     * 时间段变化
     */
    $scope.dateChange = function (user_name) {
        if (user_name == "") {
            user_name = $scope.condition.selectUser;
        }
        var outs = [];
        var start = $scope.condition.startTime;
        var end = $scope.condition.endTime;
        if (start && end && start != null && end != null && start != "" && end != "") {
            var xiangcha = end.valueOf() - start.valueOf();

            // 时间 间隔 最少为一周 ( 7天 )
            if (xiangcha >= 7 * 24 * 60 * 60 * 1000) {
                for (var i = 0; i < bookUsing.length; i++) {
                    var one = bookUsing[i];

                    var start_time = new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000;
                    // book信息 是否在 时间区间内
                    if (user_name == one.userName && start_time >= start.valueOf() && start_time <= end.valueOf()) {
                        outs.push(one);
                    }
                }
                $scope.initChart(outs, loginUser.loginName, Math.round(xiangcha / (24 * 60 * 60 * 1000)) + 1, end);
            } else {
                Notify.alert("Period error", "danger");
                return;
            }
        }
    }
    /**
     * user change
     */
    $scope.userChange = function () {
        var days = $scope.condition.selectPeriod;
        var user_name = $scope.condition.selectUser;
        // 已经选择时间区间
        if (days == 0) {
            $scope.dateChange(user_name);
        } else {
            $scope.initChart(bookUsing, user_name, days, "");
        }
        // console.log($scope.condition.selectUser);
    }
    /**
     * period change
     */
    $scope.periodChange = function () {
        var days = $scope.condition.selectPeriod;
        var user_name = $scope.condition.selectUser;
        // 时间区间初始化
        $scope.condition.startTime = null;
        $scope.condition.endTime = null;
        if (days == 0) {
            $scope.showPeriodFlg = true;
        } else {
            $scope.showPeriodFlg = false;
        }
        $scope.initChart(bookUsing, user_name, days, "");
        // console.log($scope.condition.selectPeriod);
    }
    /**
     * 初始化图表信息
     */
    $scope.initChart = function (condition, userName, days, type) {
        var datas = condition;
        var booksUse = [];
        var now_time = 0;

        if (type == "") {
            now_time = new Date().valueOf(); // 固定 一周  一月  一年
        } else {
            now_time = type.valueOf();// 自选统计时间段
        }
        // 筛 选 数 据
        for (var i = 0; i < datas.length; i++) {
            var one = datas[i];
            var start_time = new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000;
            // 筛选 时间段内的 数据
            if (userName == one.userName && start_time >= (now_time - days * 24 * 60 * 60 * 1000)) {
                booksUse.push(one);
            }
        }

        var labelsTextShow = [];
        var labelsText = [];
        var numsBook = [];
        var numsUsing = [];
        // 初始化图表的 labels , 图表数据

        if (days < 60) { // 按 天 生成图表label
            for (var j = days; j > 0; j--) {
                var condi_date = new Date(now_time - (j - 1) * 24 * 60 * 60 * 1000);
                // 图表按每日显示
                var day_month = ((condi_date.getMonth() + 1) < 10 ? "0" + (condi_date.getMonth() + 1) : (condi_date.getMonth() + 1))
                    + "-" + (condi_date.getDate() < 10 ? "0" + condi_date.getDate() : condi_date.getDate());

                labelsTextShow.push(day_month);
                labelsText.push(day_month);
                numsBook.push(0);
                numsUsing.push(0);
            }
        } else {
            for (var j = days; j > 0; j--) {

                var condi_date = new Date(now_time - (j - 1) * 24 * 60 * 60 * 1000);
                // 图表按每日显示
                var day_month = ((condi_date.getMonth() + 1) < 10 ? "0" + (condi_date.getMonth() + 1) : (condi_date.getMonth() + 1))
                    + "-" + (condi_date.getDate() < 10 ? "0" + condi_date.getDate() : condi_date.getDate());

                labelsText.push(day_month);

                // 时间超过 60天后,每隔7天 显示一个label.
                if (j%7 == 0) {
                    labelsTextShow.push(day_month);
                } else {
                    labelsTextShow.push("");
                }
                numsBook.push(0);
                numsUsing.push(0);
            }

            // 按 周 生成图表label
            //for (var j = 52; j > 0; j--) {
            //    var start = now_time - j * 7 * 24 * 60 * 60 * 1000;
            //    var E_date = new Date(now_time - (j - 1) * 7 * 24 * 60 * 60 * 1000);
            //
            //    var S_date = new Date(start + 24 * 60 * 60 * 1000);
            //    // 图表按每日显示
            //    var s_d_m = ((S_date.getMonth() + 1) < 10 ? "0" + (S_date.getMonth() + 1) : (S_date.getMonth() + 1))
            //        + "-" + (S_date.getDate() < 10 ? "0" + S_date.getDate() : S_date.getDate());
            //
            //    var e_d_m = ((E_date.getMonth() + 1) < 10 ? "0" + (E_date.getMonth() + 1) : (E_date.getMonth() + 1))
            //        + "-" + (E_date.getDate() < 10 ? "0" + E_date.getDate() : E_date.getDate());
            //
            //    var day_month = s_d_m + "~" + e_d_m;
            //    labelsText.push(day_month);
            //    numsBook.push(0);
            //    numsUsing.push(0);
            //}
        }

        // 统计预订时间 , 及 使用时间
        // console.log(booksUse);
        for (var m = 0; m < booksUse.length; m++) {
            var book = booksUse[m];

            var start = new Date(new Date(book.bookStart).valueOf() - 8 * 60 * 60 * 1000);
            var end = new Date(new Date(book.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
            var startH = start.getHours();
            var endH = end.getHours();
            var startM = start.getMinutes();
            var endM = end.getMinutes();
            var elseHour = 0;
            if (startM > 0 && endM == 0) {
                elseHour = elseHour - 0.5;
            }
            if (startM == 0 && endM > 0) {
                elseHour = elseHour + 0.5;
            }
            var bookHours = endH - startH + elseHour;
            // 判断是否属于某天的数据
            var month_Day = ((start.getMonth() + 1) < 10 ? "0" + (start.getMonth() + 1) : (start.getMonth() + 1))
                + "-" + (start.getDate() < 10 ? "0" + start.getDate() : start.getDate());

            var else_month_Day = Number((start.getMonth() + 1) + ""
                + (start.getDate() < 10 ? "0" + start.getDate() : start.getDate()));

            for (var n = 0; n < labelsText.length; n++) {
                var str = labelsText[n];
                if (str == month_Day) {
                    numsBook[n] = numsBook[n] + bookHours;
                    numsUsing[n] = numsUsing[n] + book.useMinutes;
                }
            }
            //// 预定时间,使用时间,与label信息对应绑定
            //if (days < 100) { // 按 天 统计图表数据
            //    for (var n = 0; n < labelsText.length; n++) {
            //        var str = labelsText[n];
            //        if (str == month_Day) {
            //            numsBook[n] = numsBook[n] + bookHours;
            //            numsUsing[n] = numsUsing[n] + book.useMinutes;
            //        }
            //    }
            //} else {
            //    // 按 周 统计图表数据 labelsText数组每周的开始 , 结束日期
            //    for (var l = 0; l < labelsText.length; l++) {
            //        var str = labelsText[l];
            //        var strs = str.split("~");
            //        var S_time = Number(strs[0].replace("-", ""));
            //        var E_time = Number(strs[1].replace("-", ""));
            //        if (else_month_Day >= S_time && else_month_Day <= E_time) {
            //            numsBook[l] = numsBook[l] + bookHours;
            //            numsUsing[l] = numsUsing[l] + book.useMinutes;
            //        }
            //    }
            //}

        }
        // 使用时间由 分钟 转为 小时
        for (var b = 0; b < numsUsing.length; b++) {
            numsUsing[b] = (numsUsing[b] / 60).toFixed(2);
        }
        // 图表 绑定数据
        //$scope.barData = {
        //    labels: labelsText,
        //    datasets: [
        //        {
        //            fillColor: 'rgba(36,182,233,1)',
        //            strokeColor: 'rgba(36,182,233,1)',
        //            highlightFill: 'rgba(36,182,233,1)',
        //            highlightStroke: 'rgba(36,182,233,1)',
        //            data: numsBook
        //        },
        //        {
        //            fillColor: 'rgba(42,149,121,1)',
        //            strokeColor: 'rgba(42,149,121,1)',
        //            highlightFill: 'rgba(42,149,121,1)',
        //            highlightStroke: 'rgba(42,149,121,1)',
        //            data: numsUsing
        //        }
        //    ]
        //};
        //$scope.barOptions = {
        //    scaleBeginAtZero: true,
        //    scaleShowGridLines: true,
        //    scaleGridLineColor: 'rgba(0,0,0,.05)',
        //    scaleGridLineWidth: 1,
        //    barShowStroke: false,
        //    barStrokeWidth: 1,
        //    barValueSpacing: 0,
        //    barDatasetSpacing: -13,
        //};

        // Line chart
        // -----------------------------------
        console.log(labelsTextShow);
        console.log(booksUse);
        console.log(numsBook);
        console.log(numsUsing);

        $scope.lineData = {
            labels: labelsTextShow,
            datasets: [
                {
                    label: 'All',
                    fillColor: 'rgba(35,183,229,0.5)',
                    strokeColor: 'rgba(35,183,229,1)',
                    pointColor: 'rgba(35,183,229,1)',
                    pointStrokeColor: '#23b7e5',
                    pointHighlightFill: '#23b7e5',
                    pointHighlightStroke: 'rgba(35,183,229,1)',
                    data: numsBook
                }, {
                    label: 'Login',
                    fillColor: 'rgba(42,149,121,0)',
                    strokeColor: 'rgba(42,149,121,1)',
                    pointColor: 'rgba(42,149,121,1)',
                    pointStrokeColor: '#32ac8e',
                    pointHighlightFill: '#32ac8e',
                    pointHighlightStroke: 'rgba(0,201,87,1)',
                    data: numsUsing
                }
            ]
        };

        $scope.lineOptions = {
            scaleShowGridLines: true,
            scaleGridLineColor: 'rgba(0,0,0,.05)',
            scaleGridLineWidth: 1,
            bezierCurve: true,
            bezierCurveTension: 0.4,
            pointDot: true,
            pointDotRadius: 0,
            pointDotStrokeWidth: 1,
            pointHitDetectionRadius: 20,
            datasetStroke: true,
            datasetStrokeWidth: 1.5,
            datasetFill: true,
        };

    }

    /**
     *  Export Xls File
     */
    $scope.exportXlsFile = function () {
        var start = "";
        var end = "";
        var userName = "0"; // 全部人员
        var days = $scope.condition.selectPeriod;
        var user_name = $scope.condition.selectUser;
        var C_start = $scope.condition.startTime;
        var C_end = $scope.condition.endTime;
        // 自选时间段
        if (days == 0) {
            userName = user_name;
            if (C_start && C_end && C_start != null && C_end != null && C_start != "" && C_end != "") {
                start = C_start.valueOf();
                end = C_end.valueOf() + 24 * 60 * 60 * 1000;
            } else {
                Notify.alert("Date Period error", "danger");
                return;
            }
        } else {  // 固定 一周  一月  一年
            userName = user_name;
            end = (new Date()).valueOf();
            start = end - days * 24 * 60 * 60 * 1000;

            end = end + 24 * 60 * 60 * 1000;
        }
        // 将数据导出为Excel文件
        window.location.href = "/exportExcel?start=" + start + "&end=" + end + "&userName=" + userName;
    }


}

/**
 * 用户 统计 列表 分页 形式
 */
App.controller('UserStatisticController', AgentUsersTableCtrl);
function AgentUsersTableCtrl($scope, $filter, ngTableParams, ngDialog, $timeout, $http, $state, Notify) {

    var usingBooks = [];
    var pools = [];
    var regions = [];
    /**
     * search Login
     */
    var loginUser = null;
    $scope.initLogin = function () {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            // console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.initRegion();
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin();
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                regions = result;
                $scope.initPool();
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function () {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                pools = result;
                $scope.searchBookings();
            }
        });
    }
    /**
     * search Booking
     */
    $scope.searchBookings = function () {
        var condition = new Object();
        $http.post('/searchBooking', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                usingBooks = result;
                $scope.statisticBooks(usingBooks);
            }
        });
    }
    /**
     * Statistic Books
     */
    $scope.statisticBooks = function (books) {
        var jsonBook = [];
        for (var j = 0; j < books.length; j++) {
            var flg = true;
            var back = books[j];
            // Statistic Hours
            var startH = new Date(new Date(back.bookStart).valueOf() - 8 * 60 * 60 * 1000).getHours();
            var endH = new Date(new Date(back.bookEnd).valueOf() - 8 * 60 * 60 * 1000).getHours();
            var startM = new Date(new Date(back.bookStart).valueOf() - 8 * 60 * 60 * 1000).getMinutes();
            var endM = new Date(new Date(back.bookEnd).valueOf() - 8 * 60 * 60 * 1000).getMinutes();
            var elseHour = 0;
            if (startM > 0 && endM == 0) {
                elseHour = elseHour - 0.5;
            }
            if (startM == 0 && endM > 0) {
                elseHour = elseHour + 0.5;
            }
            // Statistic Entity
            var obj = new Object();
            obj.userID = back.userId;
            obj.man = back.userName;
            obj.hours = (endH - startH) + elseHour;
            obj.date = $scope.getTypeDate(new Date(back.bookStart));
            obj.region = back.bookRegion;
            obj.pool = back.bookPool;

            for (var m = 0; m < jsonBook.length; m++) {
                var b = jsonBook[m];
                if (b.userID == back.userId && b.date == $scope.getTypeDate(new Date(back.bookStart))
                    && b.region == back.bookRegion && b.pool == back.bookPool) {
                    flg = false;
                    b.hours = b.hours + (endH - startH + elseHour);
                }
            }
            if (flg) {
                jsonBook.push(obj);
            }
        }
        $scope.initTableList(jsonBook);
    }
    /**
     * init Table Data
     * @param data
     */
    $scope.initTableList = function (data) {
        for (var j = 0; j < data.length; j++) {
            var one = data[j];
            one.index = j + 1;
            // search region name
            for (var n = 0; n < regions.length; n++) {
                var region = regions[n];
                if (one.region == region.id) {
                    one.regionName = region.regionName;
                }
            }
            // set pool name
            for (var m = 0; m < pools.length; m++) {
                var pool = pools[m];
                if (one.pool == pool.id) {
                    one.poolName = pool.poolName;
                }
            }
        }
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {}
            },
            {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * get date by format
     * @param condi
     * @returns {string}
     */
    $scope.getTypeDate = function (condi) {
        var bookDay = condi.getDate() < 10 ? "0" + condi.getDate() : condi.getDate();
        var bookMonth = condi.getMonth() < 9 ? "0" + (condi.getMonth() + 1) : (condi.getMonth() + 1);
        var bookYear = condi.getFullYear();
        var bookDate = bookYear + "-" + bookMonth + "-" + bookDay;
        return bookDate;
    }

}

