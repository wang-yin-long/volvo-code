/**=========================================================
 * Module: ResourceChartController.js
 * Controller for ChartJs
 =========================================================*/
App.controller('ResourceChartCtrl', ['$scope', '$http', '$state', '$timeout', "Notify",
    function ($scope, $http, $state, $timeout, Notify) {
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.initChart();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * random values for demo
         * @returns {number}
         */
        var rFactor = function () {
            return Math.round(Math.random() * 35);
        };

        $scope.dateChange = function () {
            console.log("data  change");
            $scope.initChart();
        }
        $scope.initChart = function () {
            var now = new Date();
            var day = now.getDate() < 10 ? "0" + now.getDate() : now.getDate();
            var month = now.getMonth() < 9 ? "0" + (now.getMonth() + 1) : (now.getMonth() + 1);
            var year = now.getFullYear();
            $scope.chartDate = day + "-" + month + "-" + year;
            // Line chart
            // -----------------------------------
            $scope.lineData = {
                labels: ['12am', '1am', '2am', '3am', '4am', '5am', '6am',
                    '7am', '8am', '9am', '10am', '11am', '12am', '1pm', '2pm', '3pm', '4pm', '5pm', '6pm', '7pm',
                    '8pm', '9pm', '10pm', '11pm'],
                datasets: [
                    {
                        label: 'Pool-1',
                        fillColor: 'rgba(114,102,186,0.2)',
                        strokeColor: 'rgba(114,102,186,1)',
                        pointColor: 'rgba(114,102,186,1)',
                        pointStrokeColor: '#fff',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(114,102,186,1)',
                        data: [rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor()]
                    },
                    {
                        label: 'Pool-2',
                        fillColor: 'rgba(35,183,229,0.2)',
                        strokeColor: 'rgba(35,183,229,1)',
                        pointColor: 'rgba(35,183,229,1)',
                        pointStrokeColor: '#fff',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(35,183,229,1)',
                        data: [rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor()]
                    },
                    {
                        label: 'Pool-3',
                        fillColor: 'rgba(0,201,87,0.2)',
                        strokeColor: 'rgba(0,201,87,1)',
                        pointColor: 'rgba(0,201,87,1)',
                        pointStrokeColor: '#fff',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(0,201,87,1)',
                        data: [rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(), rFactor(),
                            rFactor(), rFactor(), rFactor()]
                    }
                ]
            };
            $scope.lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: 'rgba(0,0,0,.05)',
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
            };
        }


    }]);