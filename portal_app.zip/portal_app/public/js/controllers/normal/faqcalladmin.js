/**
 * Faq Call Admin Ctrl
 */
App.controller('FaqCallAdminCtrl', ['$scope', '$http', '$state', '$timeout', "Notify",
    function ($scope, $http, $state, $timeout, Notify) {
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();

        var obj1 = new Object();
        obj1.id = 0;
        obj1.code = 0;
        obj1.dataKey = "FAQ";
        obj1.value = "";
        obj1.remarks = "";
        $scope.faq = obj1;
        var obj2 = new Object();
        obj2.id = 0;
        obj2.code = 0;
        obj2.dataKey = "CallAdmin";
        obj2.value = "";
        obj2.remarks = "";
        $scope.callAdmin = obj2;

        $scope.searchFaqCallAdmin = function () {
            var condition = new Object();
            $http.post('/searchAgentTime', condition).success(function (data) {
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    var configs = data;
                    for (var n = 0; n < configs.length; n++) {
                        var one = configs[n];
                        if (one.dataKey == "FAQ") {
                            $scope.faq = one;
                        }
                        if (one.dataKey == "CallAdmin") {
                            $scope.callAdmin = one;
                        }
                    }
                }
            });

        }
        $scope.searchFaqCallAdmin();
        /**
         * Confirm FAQ
         */
        $scope.confirmInfo = function () {
            var url = "";
            var faq = $scope.faq;
            if (faq.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, faq).success(function (data) {
                if (data) {
                    $scope.saveCallAdmin();
                } else {
                    Notify.alert("Error", "danger");
                    return;
                }
            });
        }
        /**
         * Confirm Call Admin
         */
        $scope.saveCallAdmin = function () {
            var url = "";
            var callAdmin = $scope.callAdmin;
            if (callAdmin.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, callAdmin).success(function (data) {
                var msg = data ? "Confirm Success" : "Confirm Error";
                var type = data ? "success" : "danger";
                Notify.alert(msg, type);
            });
        }

    }]);

