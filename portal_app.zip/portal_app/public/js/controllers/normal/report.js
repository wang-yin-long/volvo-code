/**=========================================================
 * Module: ReportChartController.js
 * Controller for ChartJs
 =========================================================*/

App.controller('ReportChartController', ['$scope', '$http', '$state', '$timeout', "Notify",
    function ($scope, $http, $state, $timeout, Notify) {

        var usingBooks = [];
        /**
         * resource chart init date
         * @type {Date}
         */
        var now = new Date();
        var day = now.getDate() < 10 ? "0" + now.getDate() : now.getDate();
        var month = now.getMonth() < 9 ? "0" + (now.getMonth() + 1) : (now.getMonth() + 1);
        var year = now.getFullYear();
        var obj = new Object();
        obj.selectPool = 0;
        obj.chartDate = year + "/" + month + "/" + day;
        $scope.select = obj;
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.initPool();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * random values for demo
         * @returns {number}
         */
        var rFactor = function () {
            return Math.round(Math.random() * 20);
        };
        /**
         * search pools
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    var pools = result;
                    $scope.pools = pools;
                    $scope.searchBookings();
                }
            });
        }
        /**
         * search Booking
         */
        $scope.searchBookings = function () {
            var condition = new Object();
            $http.post('/searchBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    usingBooks = result;
                    $scope.initChart(usingBooks);
                }
            });
        }
        /**
         * date or pool change
         */
        $scope.dateChange = function () {
            var infos = usingBooks;
            var id = $scope.select.selectPool;
            if (id != 0) {
                infos = [];
                for (var i = 0; i < usingBooks.length; i++) {
                    var one = usingBooks[i];
                    if (one.bookPool == id) {
                        infos.push(one);
                    }
                }
            }
            $scope.initChart(infos);
        }
        /**
         * filter using Books by date , set jsonData
         */
        $scope.filterBooksByDate = function (books) {
            var backs = [];
            /**
             * condition date
             */
            var chartDate = new Date($scope.select.chartDate);
            var selectDate = $scope.getTypeDate(chartDate);
            /**
             * filter by date
             */
            if (books && books.length) {
                for (var i = 0; i < books.length; i++) {
                    var one = books[i];
                    var date = new Date(new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                    var bookDate = $scope.getTypeDate(date);
                    if (bookDate == selectDate) {
                        backs.push(one);
                    }
                }
            }
            var jsonBook = [];
            for (var j = 0; j < backs.length; j++) {
                var flg = true;
                var back = backs[j];

                var startH = new Date(new Date(back.bookStart).valueOf() - 8 * 60 * 60 * 1000).getHours();
                var endH = new Date(new Date(back.bookEnd).valueOf() - 8 * 60 * 60 * 1000).getHours();
                var startM = new Date(new Date(back.bookStart).valueOf() - 8 * 60 * 60 * 1000).getMinutes();
                var endM = new Date(new Date(back.bookEnd).valueOf() - 8 * 60 * 60 * 1000).getMinutes();
                var elseHour = 0;
                if (startM > 0 && endM == 0) {
                    elseHour = elseHour - 0.5;
                }
                if (startM == 0 && endM > 0) {
                    elseHour = elseHour + 0.5;
                }

                var obj = new Object();
                obj.userID = back.userId;
                obj.man = back.userName;
                obj.hours = (endH - startH) + elseHour;

                for (var m = 0; m < jsonBook.length; m++) {
                    var b = jsonBook[m];
                    if (b.userID == back.userId) {
                        flg = false;
                        b.hours = b.hours + (endH - startH + elseHour);
                    }
                }
                if (flg) {
                    jsonBook.push(obj);
                }
            }
            return jsonBook;
        }
        /**
         * init  Chart  view
         */
        $scope.initChart = function (books) {
            var labelInfos = [];
            var labelDatas = [];
            var jsonData = $scope.filterBooksByDate(books);
            for (var m = 0; m < jsonData.length; m++) {
                var b = jsonData[m];
                labelInfos.push(b.man);
                labelDatas.push(b.hours);
            }
            //console.log(jsonData);
            /**
             * Bar chart
             */
            $scope.barData = {
                labels: labelInfos,
                datasets: [
                    {
                        fillColor: '#24b7e2',
                        strokeColor: '#24b7e2',
                        highlightFill: '#24b7e2',
                        highlightStroke: '#24b7e2',
                        data: labelDatas
                    }
                ]
            };

            $scope.barOptions = {
                scaleBeginAtZero: true,
                scaleShowGridLines: true,
                scaleGridLineColor: 'rgba(0,0,0,.05)',
                scaleGridLineWidth: 0,
                barShowStroke: true,
                barStrokeWidth: 0,
                barValueSpacing: 20,
                barDatasetSpacing: 0,
            };
        }
        /**
         * get date by format
         * @param condi
         * @returns {string}
         */
        $scope.getTypeDate = function (condi) {
            var bookDay = condi.getDate() < 10 ? "0" + condi.getDate() : condi.getDate();
            var bookMonth = condi.getMonth() < 9 ? "0" + (condi.getMonth() + 1) : (condi.getMonth() + 1);
            var bookYear = condi.getFullYear();
            var bookDate = bookYear + "/" + bookMonth + "/" + bookDay;
            return bookDate;
        }


    }]);