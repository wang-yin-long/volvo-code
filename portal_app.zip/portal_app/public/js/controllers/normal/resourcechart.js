/**=========================================================
 * Module: ResourceChartController.js
 * Controller for ChartJs
 =========================================================*/
App.controller('ResourceChartController', ['$scope', '$http', '$state', '$timeout', "Notify", 'ngDialog',
    function ($scope, $http, $state, $timeout, Notify, ngDialog) {

        var usingBooks = [];
        var regions = [];
        var pools = [];

        // 时间区域 默认 结束日期
        var e_now = new Date();
        var e_day = e_now.getDate() < 10 ? "0" + e_now.getDate() : e_now.getDate();
        var e_month = e_now.getMonth() < 9 ? "0" + (e_now.getMonth() + 1) : (e_now.getMonth() + 1);
        var e_year = e_now.getFullYear();
        // 时间区域 默认 开始日期
        var s_now = new Date(new Date().valueOf() - 7 * 24 * 60 * 60 * 1000);
        var s_day = s_now.getDate() < 10 ? "0" + s_now.getDate() : s_now.getDate();
        var s_month = s_now.getMonth() < 9 ? "0" + (s_now.getMonth() + 1) : (s_now.getMonth() + 1);
        var s_year = s_now.getFullYear();

        var obj = new Object();
        obj.selectPool = 0;
        obj.selectRegion = 0;
        obj.periodStart = s_year + "-" + s_month + "-" + s_day;
        obj.periodEnd = e_year + "-" + e_month + "-" + e_day;
        $scope.select = obj;
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.initRegion();
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();
        /**
         * search regions
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    $scope.regions = regions;
                    $scope.initPool();
                }
            });
        }
        /**
         * search pools
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    $scope.pools = pools;
                    $scope.searchBookings();
                }
            });
        }
        /**
         * search Booking
         */
        $scope.searchBookings = function () {
            var condition = new Object();
            $http.post('/searchAllBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    usingBooks = result;

                    var s_period = $scope.select.periodStart;
                    var e_period = $scope.select.periodEnd;
                    $scope.initChart(usingBooks, e_period, $scope.getPeriodDays(s_period, e_period));
                }
            });
        }
        /**
         * region change
         */
        $scope.regionChange = function () {
            var datas = [];
            var infos = usingBooks;
            var id = $scope.select.selectRegion;
            if (id != 0) {
                for (var m = 0; m < pools.length; m++) {
                    var pool = pools[m];
                    if (id == pool.region) {
                        datas.push(pool);
                    }
                }
                $scope.pools = datas;
                $scope.select.selectPool = 0;
            } else {
                $scope.pools = pools;
                $scope.select.selectPool = 0;
            }
            if (id != 0) {
                infos = [];
                for (var i = 0; i < usingBooks.length; i++) {
                    var one = usingBooks[i];
                    if (one.bookRegion == id) {
                        infos.push(one);
                    }
                }
            }
            var s_period = $scope.select.periodStart;
            var e_period = $scope.select.periodEnd;
            $scope.initChart(infos, e_period, $scope.getPeriodDays(s_period, e_period));
        }
        /**
         * pool change
         */
        $scope.poolChange = function () {
            var infos = usingBooks;
            var id = $scope.select.selectPool;
            var region_id = $scope.select.selectRegion;
            if (id != 0) {
                infos = [];
                for (var i = 0; i < usingBooks.length; i++) {
                    var one = usingBooks[i];
                    if (one.bookPool == id) {
                        infos.push(one);
                    }
                }
            } else {
                if (region_id != 0) {
                    infos = [];
                    // 选择 All Pool时 , 要根据region筛选
                    for (var j = 0; j < usingBooks.length; j++) {
                        var book = usingBooks[j];
                        if (book.bookRegion == region_id) {
                            infos.push(book);
                        }
                    }
                }
            }
            var s_period = $scope.select.periodStart;
            var e_period = $scope.select.periodEnd;
            $scope.initChart(infos, e_period, $scope.getPeriodDays(s_period, e_period));
        }
        /**
         * date change
         */
        $scope.dateChange = function () {
            var s_period = $scope.select.periodStart;
            var e_period = $scope.select.periodEnd;
            if ((new Date(e_period).valueOf() - new Date(s_period).valueOf()) < (7 * 24 * 60 * 60 * 1000)) {
                Notify.alert("Date interval must be greater than 7 days", "danger");
                return;
            }
            $scope.initChart(usingBooks, e_period, $scope.getPeriodDays(s_period, e_period));
        }

        /**
         * 获取 所选时间间隔天数
         */
        $scope.getPeriodDays = function (start, end) {
            var s_date = new Date(start).valueOf();
            var e_date = new Date(end).valueOf();
            var days_value = e_date - s_date;
            var days = Math.round(days_value / (24 * 60 * 60 * 1000)) + 1;
            return days;
        }


        /**
         *  初始化 图表
         */
        $scope.initChart = function (allBooks, end_date, days) {
            var limitUsers = 0;
            var id = $scope.select.selectPool;
            if (id != 0) {
                // 某一个 pool 用户上限
                for (var m = 0; m < $scope.pools.length; m++) {
                    var pool1 = $scope.pools[m];
                    if (id == pool1.id) {
                        limitUsers = pool1.maxUser;
                        break;
                    }
                }
            } else {
                // 所有 pool 用户上限 总和
                for (var n = 0; n < $scope.pools.length; n++) {
                    var pool2 = $scope.pools[n];
                    limitUsers = limitUsers + pool2.maxUser;
                }
            }
            var limit = []; // pool 用户上限
            var labelsTextShow = [];
            var labelsText = [];
            var maxUsers = []; // 当天中 pool中对应最大用户预订数.
            var maxUsing = []; // 当天中 pool中对应最大用户在线数.
            var selectDateBooks = [];// 选择的时间段内 每天 的预定列表
            var end_date_value = new Date(end_date).valueOf();
            if (days < 60) {
                // 少于 60 天 每天都显示
                for (var j = days; j > 0; j--) {
                    var condi_date = new Date(end_date_value - (j - 1) * 24 * 60 * 60 * 1000);
                    // 具体日期 用于筛选 获得每天的数据
                    var dayStr = condi_date.getFullYear() + "" + condi_date.getMonth() + "" + condi_date.getDate();
                    // 图表 横向 labels
                    var day_month = ((condi_date.getMonth() + 1) < 10 ? "0" + (condi_date.getMonth() + 1) : (condi_date.getMonth() + 1))
                        + "-" + (condi_date.getDate() < 10 ? "0" + condi_date.getDate() : condi_date.getDate());
                    labelsTextShow.push(day_month);
                    labelsText.push(day_month);// 横轴label显示,用于数据筛选
                    limit.push(limitUsers);
                    // 先获取当天数据,再筛选出 最大预订数 和 最大使用数
                    maxUsers.push($scope.filterBooksByDate($scope.getBookOneDay(allBooks, dayStr)));
                    maxUsing.push($scope.filterUsingBooks($scope.getBookOneDay(allBooks, dayStr)));
                }
            } else {
                // 大于 60 天 label横轴 7天显示一次
                for (var j = days; j > 0; j--) {
                    var condi_date = new Date(end_date_value - (j - 1) * 24 * 60 * 60 * 1000);
                    // 具体日期 用于筛选 获得每天的数据
                    var dayStr1 = condi_date.getFullYear() + "" + condi_date.getMonth() + "" + condi_date.getDate();
                    // 图表 横向 labels
                    var day_month = ((condi_date.getMonth() + 1) < 10 ? "0" + (condi_date.getMonth() + 1) : (condi_date.getMonth() + 1))
                        + "-" + (condi_date.getDate() < 10 ? "0" + condi_date.getDate() : condi_date.getDate());
                    // 时间超过 60天后,每隔7天 显示一个label.
                    if (j % 7 == 0) {
                        labelsTextShow.push(day_month);
                    } else {
                        labelsTextShow.push("");
                    }
                    labelsText.push(day_month);// 横轴label显示,用于数据筛选
                    limit.push(limitUsers);
                    // 先获取当天数据,再筛选出 最大预订数 和 最大使用数
                    maxUsers.push($scope.filterBooksByDate($scope.getBookOneDay(allBooks, dayStr1)));
                    maxUsing.push($scope.filterUsingBooks($scope.getBookOneDay(allBooks, dayStr1)));
                }
            }

            //console.log("***************");
            //console.log(selectDateBooks);
            //console.log(maxUsers);
            //console.log(maxUsing);

            $scope.lineData = {
                labels: labelsTextShow,
                datasets: [
                    {
                        label: 'All',
                        fillColor: 'rgba(35,183,229,0.5)',
                        strokeColor: 'rgba(35,183,229,1)',
                        pointColor: 'rgba(35,183,229,1)',
                        pointStrokeColor: '#23b7e5',
                        pointHighlightFill: '#23b7e5',
                        pointHighlightStroke: 'rgba(35,183,229,1)',
                        data: maxUsers
                    }, {
                        label: 'Login',
                        fillColor: 'rgba(42,149,121,0)',
                        strokeColor: 'rgba(42,149,121,1)',
                        pointColor: 'rgba(42,149,121,1)',
                        pointStrokeColor: '#32ac8e',
                        pointHighlightFill: '#32ac8e',
                        pointHighlightStroke: 'rgba(42,149,121,1)',
                        data: maxUsing
                    }
                    , {
                        label: 'Limit',
                        fillColor: 'rgba(255,0,0,0)',
                        strokeColor: 'rgba(255,0,0,1)',
                        pointColor: 'rgba(255,0,0,1)',
                        pointStrokeColor: 'red',
                        pointHighlightFill: 'red',
                        pointHighlightStroke: 'rgba(255,0,0,1)',
                        data: limit
                    }
                ]
            };
            $scope.lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: 'rgba(0,0,0,.05)',
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.3,
                pointDot: true,
                pointDotRadius: 0,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 1.5,
                datasetFill: true,
            };
        }
        /**
         * 筛选当前时间 每半小时的预定人数,并获得当天book最大值
         */
        $scope.filterBooksByDate = function (backs) {
            var jsonBook = [];
            for (var j = 0; j < 48; j++) {
                var one = 0;
                jsonBook.push(one);
            }
            /**
             * 统计每半小时时间点的book数量
             */
            for (var m = 0; m < backs.length; m++) {
                var obj = backs[m];
                var startD = new Date(new Date(obj.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                var startHour = startD.getHours();
                var s_num = (startD.getMinutes() > 0) ? (startHour * 2 + 1) : startHour * 2;

                var endD = new Date(new Date(obj.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
                var endHour = endD.getHours();
                var e_num = (endD.getMinutes() > 0) ? (endHour * 2 + 1) : endHour * 2;
                // 每半小时的预定人数累加
                for (var n = s_num; n <= e_num; n++) {
                    jsonBook[n] = jsonBook[n] + 1;
                }
            }
            var max = jsonBook[0];
            for (var i = 1; i < jsonBook.length; i++) {
                if (max < jsonBook[i])
                    max = jsonBook[i];
            }
            return max;
        }
        /**
         * 筛选当前时间 每半小时的预定人数,并获得当天sing最大值
         */
        $scope.filterUsingBooks = function (backs) {
            var jsonBook = [];
            for (var j = 0; j < 48; j++) {
                var one = 0;
                jsonBook.push(one);
            }
            /**
             * 统计每半小时时间点的book数量
             */
            for (var m = 0; m < backs.length; m++) {
                var obj = backs[m];
                if (obj.useStart != null && obj.useEnd != null) {
                    var startD = new Date(new Date(obj.useStart).valueOf() - 8 * 60 * 60 * 1000);
                    var startHour = startD.getHours();
                    var s_num = (startD.getMinutes() > 0) ? (startHour * 2 + 1) : startHour * 2;

                    var endD = new Date(new Date(obj.useEnd).valueOf() - 8 * 60 * 60 * 1000);
                    var endHour = endD.getHours();
                    var e_num = (endD.getMinutes() > 0) ? (endHour * 2 + 1) : endHour * 2;

                    for (var n = s_num; n <= e_num; n++) {
                        jsonBook[n] = jsonBook[n] + 1;
                    }
                }
            }
            var max = jsonBook[0];
            for (var i = 1; i < jsonBook.length; i++) {
                if (max < jsonBook[i])
                    max = jsonBook[i];
            }
            return max;
        }
        /**
         * 获取某天的预定信息
         */
        $scope.getBookOneDay = function (allBooks, dayStr) {
            var backs = [];
            for (var i = 0; i < allBooks.length; i++) {
                var book = allBooks[i];
                var start = new Date(new Date(book.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                var S_str = start.getFullYear() + "" + start.getMonth() + "" + start.getDate();
                if (S_str == dayStr) {
                    backs.push(book);
                }
            }
            return backs;
        }


        /**
         *  Export booking Xls File
         */
        $scope.exportXlsFile = function () {
            var start = new Date().valueOf() - 30 * 24 * 60 * 60 * 1000;
            // 将数据导出为Excel文件
            window.location.href = "/bookingExport?start=" + start + "&end=" + "0";

        }


    }])
;