/**=========================================================
 * Module: BooklistTableCtrl.js
 * Controller for ngTables
 =========================================================*/
App.controller('BooklistTableCtrl', ['$scope', '$http', '$filter', '$state', 'ngTableParams', 'Notify', 'ngDialog',
    function ($scope, $http, $filter, $state, ngTableParams, Notify, ngDialog) {

        var allbooks = [];
        var condition = new Object();
        //var now_date = new Date(new Date().valueOf() - 30 * 24 * 60 * 60 * 1000);
        //var now_M = (now_date.getMonth() + 1) < 10 ? "0" + (now_date.getMonth() + 1) : (now_date.getMonth() + 1);
        //var now_D = now_date.getDate() < 10 ? "0" + now_date.getDate() : now_date.getDate();
        // condition.startTime = now_date.getFullYear() + "-" + now_M + "-" + now_D; // 数据时间段的开始时间
        condition.startTime = null;
        condition.endTime = null;
        $scope.condition = condition;
        /**
         * search Login
         */
        var loginUser = null;
        var regions = [];
        var pools = [];
        $scope.initLogin = function (type) {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                    $scope.initRegion();
                    if (type == "1") {
                        Notify.alert("Refresh success", "success");
                    }
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin("");

        $scope.refreshInitLogin = function () {
            $scope.initLogin("1");
        }

        /**
         * search regions
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    $scope.initPool(regions);
                }
            });
        }
        /**
         * search pools
         */
        $scope.initPool = function (regions) {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    $scope.searchBookings(regions, pools);
                }
            });
        }
        /**
         * search Booking
         * @param regions
         * @param pools
         */
        // 当前时间 判断预定知否过期
        var nowTime = new Date().valueOf();
        $scope.searchBookings = function (regions, pools) {
            var condition = new Object();
            $http.post('/searchBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    // console.log("当前时间 判断预定知否过期" + nowTime);
                    allbooks = result;

                    // 只显示当前时间前后 近一个月 的数据
                    var bookInfos = [];
                    for (var j = 0; j < allbooks.length; j++) {
                        var bookInfo = allbooks[j];
                        var bookstart = new Date(new Date(bookInfo.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                        if ((nowTime - 30 * 24 * 60 * 60 * 1000) < bookstart && bookstart < (nowTime + 30 * 24 * 60 * 60 * 1000)) {
                            bookInfos.push(bookInfo);
                        }
                    }
                    // 列表时间段选择条件 默认值
                    var s_t = new Date(nowTime - 30 * 24 * 60 * 60 * 1000);
                    var s_m = (s_t.getMonth() + 1) < 10 ? "0" + (s_t.getMonth() + 1) : (s_t.getMonth() + 1);
                    $scope.condition.startTime = s_t.getFullYear() + "/" + s_m + "/" + s_t.getDate();
                    var e_t = new Date(nowTime + 30 * 24 * 60 * 60 * 1000);
                    var e_m = (e_t.getMonth() + 1) < 10 ? "0" + (e_t.getMonth() + 1) : (e_t.getMonth() + 1);
                    $scope.condition.endTime = e_t.getFullYear() + "/" + e_m + "/" + e_t.getDate();
                    $scope.initTableList(bookInfos);
                }
            });
        }

        $scope.initTableList = function (data) {
            for (var i = 0; i < data.length; i++) {
                var one = data[i];
                one.index = i + 1;
                var start = new Date(new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                var end = new Date(new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000);

                one.overdueFlg = false;
                if (end <= nowTime) {
                    one.overdueFlg = true;
                }
                if (one.status > 1) {
                    one.overdueFlg = true;
                }
                var sMonth = start.getMonth() + 1 < 10 ? "0" + (start.getMonth() + 1) : start.getMonth() + 1;
                var eMonth = end.getMonth() + 1 < 10 ? "0" + (end.getMonth() + 1) : end.getMonth() + 1;
                var sMinite = start.getMinutes() == 0 ? "00" : start.getMinutes();
                var eMinite = end.getMinutes() == 0 ? "00" : end.getMinutes();
                var SDay = start.getDate() < 10 ? "0" + start.getDate() : start.getDate();
                var EDay = end.getDate() < 10 ? "0" + end.getDate() : end.getDate();
                var SHour = start.getHours() < 10 ? "0" + start.getHours() : start.getHours();
                var EHour = end.getHours() < 10 ? "0" + end.getHours() : end.getHours();

                one.bookStartView = start.getFullYear() + "-" + sMonth + "-" + SDay + " " + SHour + ":" + sMinite;
                one.bookEndView = end.getFullYear() + "-" + eMonth + "-" + EDay + " " + EHour + ":" + eMinite;

                /**
                 * set pool name
                 */
                for (var m = 0; m < pools.length; m++) {
                    var pool = pools[m];
                    if (one.bookPool == pool.id) {
                        one.bookPoolName = pool.poolName;
                    }
                }
            }
            // console.log(data);
            $scope.data = data;
            // FILTERS
            $scope.tableParams = new ngTableParams({
                    page: 1,
                    count: 10,
                },
                {
                    total: $scope.data.length,
                    getData: function ($defer, params) {
                        var orderedData = params.filter() ? $filter('filter')($scope.data, params.filter()) : $scope.data;
                        var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                        params.total(orderedData.length);
                        $defer.resolve(users);
                    }
                }
            );
        }
        /**
         * delete Booking
         */
        $scope.deleteInfo = function (obj) {
            var backs = [];
            ngDialog.openConfirm({
                template: 'confirmDialogId',
                className: 'ngdialog-theme-default'
            }).then(function (value) {
                var condition = obj;
                $http.post('/delBooking', condition).success(function (result) {
                    var msg = result ? "Delete Success" : "Delete Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        var backs = [];
                        for (var i = 0; i < allbooks.length; i++) {
                            var onebook = allbooks[i];
                            if (obj.id != onebook.id) {
                                backs.push(onebook);
                            }
                        }
                        for (var z = 0; z < backs.length; z++) {
                            var oo = backs[z];
                            oo.index = z + 1;
                        }
                        // 列表刷新
                        allbooks = backs;
                        $scope.data = backs;
                        $scope.tableParams.reload();

                        var log = new Object();
                        log.logType = 4; // 普通管理员删除 booking
                        log.userId = "";
                        log.userName = loginUser.loginName;
                        log.logTime = new Date(new Date().valueOf() + 8 * 60 * 60 * 1000);
                        log.region = obj.bookRegion;
                        log.pool = obj.bookPool;
                        log.adGroup = obj.bookGroup;
                        log.agentName = obj.agentName;
                        log.status = obj.status;
                        log.description = "Biz user delete booking";
                        $http.post('/addLogs', log).success(function (result) {
                            var msg = result ? "Add log success" : "Add log error";
                            var type = result ? "success" : "danger";
                            Notify.alert(msg, type);
                        });
                    }
                });
            }, function (reason) {
            });
        }

        /**
         *  Export booking Xls File
         */
        $scope.exportXlsFile = function () {
            console.log($scope.condition.startTime);
            console.log($scope.condition.endTime);
            var C_start = new Date($scope.condition.startTime);
            var C_end = new Date($scope.condition.endTime);
            console.log(C_start);
            console.log(C_end);
            var start = 0;
            var end = 0;
            if (C_start != null && C_end != null && C_start != "" && C_end != "") {
                start = C_start.valueOf();
                end = C_end.valueOf() + 24 * 60 * 60 * 1000;
            } else {
                start = nowTime - 30 * 24 * 60 * 60 * 1000; // 过期数据 默认选择一个月
                end = 0;
            }
            console.log(start);
            console.log(end);
            // 将数据导出为Excel文件
            window.location.href = "/bookingExport?start=" + start + "&end=" + end;

        }
        /**
         *  时间段变化
         */
        $scope.dateChange = function () {
            var Condi_start = new Date($scope.condition.startTime);
            var Condi_end = new Date($scope.condition.endTime);
            console.log(Condi_start);
            console.log(Condi_end);
            var outs = [];
            if (Condi_start != null && Condi_end != null) {
                var start = Condi_start.valueOf();
                var end = Condi_end.valueOf() + 24 * 60 * 60 * 1000;

                if (start < end) {
                    outs = [];
                    for (var i = 0; i < allbooks.length; i++) {
                        var onebook = allbooks[i];
                        var book_start = new Date(new Date(onebook.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                        if (book_start >= start && book_start <= end) {
                            outs.push(onebook);
                        }
                    }
                    for (var z = 0; z < outs.length; z++) {
                        var oo = outs[z];
                        oo.index = z + 1;
                    }
                    // 列表刷新
                    $scope.data = outs;
                    $scope.tableParams.reload();
                } else {
                    Notify.alert("Time period error", "danger");
                    return;
                }
            }
            if ((Condi_start == "" && Condi_end == "") || (Condi_start == null && Condi_end == null)) {
                // 默认数据
                $scope.data = allbooks;
                $scope.tableParams.reload();
            }
        }


    }]);

/**
 * Booking Detail Ctrl
 */
App.controller('BookingDetailCtrl', ['$scope', '$http', '$state', '$timeout', '$stateParams', "Notify",
    function ($scope, $http, $state, $timeout, $stateParams, Notify) {
        /**
         * url  params
         */
        var bookid = $stateParams.bookingid;
        /**
         * init condition
         */
        var regions = [];
        var pools = [];
        var hours = [];
        for (var m = 1; m < 25; m++) {
            var obj = new Object();
            obj.key = m + "";
            obj.value = m + "";
            hours.push(obj);
        }
        $scope.hours = hours;
        /**
         * init time info
         * @type {Object}
         */
        var startTime = new Object();
        startTime.hour = "";
        startTime.minute = "";
        $scope.startTime = startTime;
        var endTime = new Object();
        endTime.hour = "";
        endTime.minute = "";
        $scope.endTime = endTime;
        /**
         * search region dropdown
         */
        $scope.initRegion = function () {
            var condition = new Object();
            $http.post('/searchRegionList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    regions = result;
                    $scope.regionDrop = result;
                    $scope.initPool();
                }
            });
        }
        $scope.initRegion();
        /**
         * search pool dropdown
         */
        $scope.initPool = function () {
            var condition = new Object();
            $http.post('/searchPoolList', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                    return;
                } else if (result && result.length > 0) {
                    pools = result;
                    $scope.poolDrop = result;
                    $timeout(function () {
                        $scope.initBookDetail();
                    }, 20);
                }
            });
        }
        /**
         * region change
         */
        $scope.regionChange = function () {
            var datas = [];
            var id = $scope.bookingDetail.bookRegion;
            for (var m = 0; m < pools.length; m++) {
                var pool = pools[m];
                if (id == pool.region) {
                    datas.push(pool);
                }
            }
            $scope.poolDrop = datas;
        }
        /**
         * search One Booking
         * @type {Object}
         */
        $scope.initBookDetail = function () {
            var condition = new Object();
            condition.id = bookid;
            $http.post('/searchOneBooking', condition).success(function (result) {
                if (result == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (result && result.length > 0) {
                    $scope.bookingDetail = result[0];
                    $scope.detailInitTime(result[0]);
                }
            });
        }
        $scope.detailInitTime = function (obj) {
            var start = new Date(new Date(obj.bookStart).valueOf() - 8 * 60 * 60 * 1000);
            var end = new Date(new Date(obj.bookEnd).valueOf() - 8 * 60 * 60 * 1000);
            var sMonth = start.getMonth() + 1;
            var eMonth = end.getMonth() + 1;
            $scope.bookStart = start.getFullYear() + "/" + sMonth + "/" + start.getDate();
            $scope.bookEnd = end.getFullYear() + "/" + eMonth + "/" + end.getDate();
            $scope.startTime.hour = start.getHours();
            $scope.startTime.minute = start.getMinutes();
            $scope.endTime.hour = end.getHours();
            $scope.endTime.minute = end.getMinutes();
        }
        /**
         * booking detail update
         * @param condi
         */
        $scope.updateBookingDetail = function () {
            var condition = $scope.bookingDetail;
            var startC = angular.element('#_book_start_id')[0].value;
            var endC = angular.element('#_book_end_id')[0].value;
            condition.bookStart = $scope.getDateTime(startC, $scope.startTime.hour, $scope.startTime.minute);
            condition.bookEnd = $scope.getDateTime(endC, $scope.endTime.hour, $scope.endTime.minute);
            /**
             * http post
             * @type {string}
             */
            var postUrl = "/updateBooking";
            $http.post(postUrl, condition).success(function (result) {
                var msg = result ? "Confirm Success" : "Confirm Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    $state.go('biz.booklist');
                }
            });
        }
        /**
         * get date time by condition
         * @param condi
         */
        $scope.getDateTime = function (dateString, hh, mm) {
            if (dateString != "" && dateString.indexOf("/") >= 0) {
                var strs = dateString.split("/");
                var out = new Date(strs[0], strs[1] - 1, strs[2], hh, mm);
                return new Date(out.valueOf() + 8 * 60 * 60 * 1000);
            } else {
                return "";
            }
        }

    }]);

