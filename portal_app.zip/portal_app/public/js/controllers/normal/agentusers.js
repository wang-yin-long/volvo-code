/**=========================================================
 * Module: AgentUsersTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('AgentUsersTableCtrl', AgentUsersTableCtrl);
function AgentUsersTableCtrl($scope, $filter, ngTableParams, ngDialog, $timeout, $http, $state, Notify) {
    /**
     * search Login
     */
    var loginUser = null;
    $scope.initLogin = function (type) {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.initRegion();
                if (type == "1"){
                    Notify.alert("Refresh success", "success");
                }
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('page.login');
                return;
            }
        });
    }
    $scope.initLogin("");

    $scope.refreshInitLogin = function () {
        $scope.initLogin("1");
    }
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regions = result;
                $scope.initPool(regions);
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $scope.searchBookings(regions, pools);
            }
        });
    }
    /**
     * search Booking
     * @param regions
     * @param pools
     */
    $scope.searchBookings = function (regions, pools) {
        var data = [];
        var condition = new Object();
        $http.post('/searchBooking', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                data = [];
                for (var i = 0; i < result.length; i++) {
                    var one = result[i];
                    /**
                     * user is logined and using (status == 1)
                     */
                    if (one.status == 1) {
                        var start = new Date(new Date(one.bookStart).valueOf() - 8 * 60 * 60 * 1000);
                        var end = new Date(new Date(one.bookEnd).valueOf() - 8 * 60 * 60 * 1000);

                        var sMonth = start.getMonth() + 1 < 10 ? "0" + (start.getMonth() + 1) : start.getMonth() + 1;
                        var eMonth = end.getMonth() + 1 < 10 ? "0" + (end.getMonth() + 1) : end.getMonth() + 1;
                        var sMinite = start.getMinutes() == 0 ? "00" : start.getMinutes();
                        var eMinite = end.getMinutes() == 0 ? "00" : end.getMinutes();
                        var SDay = start.getDate() < 10 ? "0" + start.getDate() : start.getDate();
                        var EDay = end.getDate() < 10 ? "0" + end.getDate() : end.getDate();
                        var SHour = start.getHours() < 10 ? "0" + start.getHours() : start.getHours();
                        var EHour = end.getHours() < 10 ? "0" + end.getHours() : end.getHours();

                        one.bookStartView = start.getFullYear() + "-" + sMonth + "-" + SDay + " " + SHour + ":" + sMinite;
                        one.bookEndView = end.getFullYear() + "-" + eMonth + "-" + EDay + " " + EHour + ":" + eMinite;

                        // search region name
                        for (var n = 0; n < regions.length; n++) {
                            var region = regions[n];
                            if (one.bookRegion == region.id) {
                                one.bookRegionName = region.regionName;
                            }
                        }
                        // pool login time
                        var loginTime = new Date(new Date(one.remarks).valueOf() - 8 * 60 * 60 * 1000);
                        var Month = loginTime.getMonth() + 1;
                        var Minite = loginTime.getMinutes() == 0 ? "00" : loginTime.getMinutes();
                        var time = loginTime.getFullYear() + "-" + Month + "-" + loginTime.getDate() + " " +
                            loginTime.getHours() + ":" + Minite;
                        one.loginTime = (one.remarks == null || one.remarks == "")? "" : time;
                        // set pool name
                        for (var m = 0; m < pools.length; m++) {
                            var pool = pools[m];
                            if (one.bookPool == pool.id) {
                                one.bookPoolName = pool.poolName;
                            }
                        }
                        data.push(one);
                    }
                }
                for (var m = 0; m < data.length; m++) {
                    var d = data[m];
                    d.index = m + 1;
                }
                $scope.initTableList(data);
            }
        });
    }

    $scope.initTableList = function (data) {
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {}
            },
            {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * user login out
     */
    $scope.deleteInfo = function (nextBook) {
        ngDialog.openConfirm({
            template: 'confirmDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            //console.log(value);
            if (nextBook != null) {
                /**
                 * user book login out
                 * @param condi
                 */
                var condition = nextBook;
                condition.status = 0;
                /**
                 * http post
                 * @type {string}
                 */
                var postUrl = "/updateLoginBook";
                $http.post(postUrl, condition).success(function (result) {
                    var msg = result ? "Login Out Success" : "Login Out Error";
                    var type = result ? "success" : "danger";
                    Notify.alert(msg, type);
                    if (result) {
                        location.reload();
                    }
                });
            }
        }, function (reason) {
            //console.log(reason);
        });
    }


}

