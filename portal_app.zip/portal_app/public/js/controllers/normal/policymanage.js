/**
 * Policy Manage Controller
 */
App.controller('PolicyManageCtrl', ['$scope', '$http', '$state', '$timeout', "Notify",
    function ($scope, $http, $state, $timeout, Notify) {
        /**
         * search Login
         */
        var loginUser = null;
        $scope.initLogin = function () {
            var condition = new Object();
            $http.post('/searchLogin', condition).success(function (result) {
                //console.log(result);
                if (result != null) {
                    loginUser = result;
                } else {
                    Notify.alert("Please Login", "danger");
                    $state.go('page.login');
                    return;
                }
            });
        }
        $scope.initLogin();

        var obj1 = new Object();
        obj1.id = 0;
        obj1.code = 0;
        obj1.dataKey = "MinBookTime";
        obj1.value = "0.5";
        obj1.remarks = "";
        $scope.minBookTime = obj1;
        var obj2 = new Object();
        obj2.id = 0;
        obj2.code = 0;
        obj2.dataKey = "MaxBookTime";
        obj2.value = "8";
        obj2.remarks = "";
        $scope.maxBookTime = obj2;
        var obj3 = new Object();
        obj3.id = 0;
        obj3.code = 0;
        obj3.dataKey = "MinQuickBookTime";
        obj3.value = "0.5";
        obj3.remarks = "";
        $scope.minQuickBookTime = obj3;
        var obj4 = new Object();
        obj4.id = 0;
        obj4.code = 0;
        obj4.dataKey = "MaxQuickBookTime";
        obj4.value = "2";
        obj4.remarks = "";
        $scope.maxQuickBookTime = obj4;

        $scope.searchPolicyManage = function () {
            var condition = new Object();
            $http.post('/searchAgentTime', condition).success(function (data) {
                if (data == "Error") {
                    Notify.alert("Confirm Error", "danger");
                } else if (data && data.length > 0) {
                    var configs = data;
                    for (var n = 0; n < configs.length; n++) {
                        var one = configs[n];
                        if (one.dataKey == "MinBookTime") {
                            $scope.minBookTime = one;
                        }
                        if (one.dataKey == "MaxBookTime") {
                            $scope.maxBookTime = one;
                        }
                        if (one.dataKey == "MinQuickBookTime") {
                            $scope.minQuickBookTime = one;
                        }
                        if (one.dataKey == "MaxQuickBookTime") {
                            $scope.maxQuickBookTime = one;
                        }
                    }
                }
            });

        }
        $scope.searchPolicyManage();
        /**
         * Confirm Policy Manage
         */
        $scope.confirmInfo = function () {
            var url = "";
            var minBookTime = $scope.minBookTime;
            if (minBookTime.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, minBookTime).success(function (data) {
                if (data) {
                    $scope.saveMaxBookTime();
                } else {
                    Notify.alert("Error", "danger");
                    return;
                }
            });
        }
        $scope.saveMaxBookTime = function () {
            var url = "";
            var maxBookTime = $scope.maxBookTime;
            if (maxBookTime.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, maxBookTime).success(function (data) {
                if (data) {
                    $scope.saveMinQuickBookTime();
                } else {
                    Notify.alert("Error", "danger");
                    return;
                }
            });
        }
        $scope.saveMinQuickBookTime = function () {
            var url = "";
            var minQuickBookTime = $scope.minQuickBookTime;
            if (minQuickBookTime.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, minQuickBookTime).success(function (data) {
                if (data) {
                    $scope.saveMaxQuickBookTime();
                } else {
                    Notify.alert("Error", "danger");
                    return;
                }
            });
        }
        $scope.saveMaxQuickBookTime = function () {
            var url = "";
            var maxQuickBookTime = $scope.maxQuickBookTime;
            if (maxQuickBookTime.id == 0) {
                url = "/addAgentTime"
            } else {
                url = "/updateAgentTime"
            }
            $http.post(url, maxQuickBookTime).success(function (data) {
                var msg = data ? "Confirm Success" : "Confirm Error";
                var type = data ? "success" : "danger";
                Notify.alert(msg, type);
            });
        }

    }]);

