/**=========================================================
 * Module: LogsTableCtrl.js
 * Controller for ngTables
 =========================================================*/

App.controller('LogsTableCtrl', LogsTableCtrl);
function LogsTableCtrl($scope, $filter, ngTableParams, ngDialog, $timeout, $http, $state, Notify) {
    /**
     * search Login
     */
    var loginUser = null;
    $scope.initLogin = function () {
        var condition = new Object();
        $http.post('/searchLogin', condition).success(function (result) {
            //console.log(result);
            if (result != null) {
                loginUser = result;
                $scope.initRegion();
            } else {
                Notify.alert("Please Login", "danger");
                $state.go('bizAdmin');
                return;
            }
        });
    }
    $scope.initLogin();
    /**
     * search regions
     */
    $scope.initRegion = function () {
        var condition = new Object();
        $http.post('/searchRegionList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var regions = result;
                $scope.initPool(regions);
            }
        });
    }
    /**
     * search pools
     */
    $scope.initPool = function (regions) {
        var condition = new Object();
        $http.post('/searchPoolList', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                var pools = result;
                $scope.searchLogs(regions, pools);
            }
        });
    }
    /**
     * search logs
     * @param regions
     * @param pools
     */
    $scope.searchLogs = function (regions, pools) {
        var data = [];
        var condition = new Object();
        $http.post('/searchLogs', condition).success(function (result) {
            if (result == "Error") {
                Notify.alert("Error", "danger");
                return;
            } else if (result && result.length > 0) {
                data = result;
                for (var i = 0; i < data.length; i++) {
                    var one = data[i];
                    one.index = i + 1;
                    var logTime = new Date(new Date(one.logTime).valueOf() - 8 * 60 * 60 * 1000);
                    var sMonth = logTime.getMonth() + 1;
                    var sMinite = logTime.getMinutes() < 10 ? "0" + logTime.getMinutes() : logTime.getMinutes();
                    one.logTimeView = logTime.getFullYear() + "-" + sMonth + "-" + logTime.getDate() + " " +
                        logTime.getHours() + ":" + sMinite;
                    /**
                     *  search region name
                     */
                    for (var n = 0; n < regions.length; n++) {
                        var region = regions[n];
                        if (one.region == region.id) {
                            one.regionName = region.regionName;
                        }
                    }
                    /**
                     * set pool name
                     */
                    for (var m = 0; m < pools.length; m++) {
                        var pool = pools[m];
                        if (one.pool == pool.id) {
                            one.poolName = pool.poolName;
                        }
                    }
                }
                $scope.initTableList(data);
            }
        });
    }

    $scope.initTableList = function (data) {
        // FILTERS
        $scope.tableParams2 = new ngTableParams({
                page: 1,            // show first page
                count: 10,          // count per page
                filter: {
                    userName: '',
                    bookPoolName: '',
                    description: ''
                }
            },
            {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    var users = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());
                    params.total(orderedData.length);
                    $defer.resolve(users);
                }
            }
        );
    }
    /**
     * delete logs
     */
    $scope.deleteInfo = function (obj) {
        ngDialog.openConfirm({
            template: 'confirmDialogId',
            className: 'ngdialog-theme-default'
        }).then(function (value) {
            var condition = obj;
            $http.post('/delLogs', condition).success(function (result) {
                var msg = result ? "Success" : "Error";
                var type = result ? "success" : "danger";
                Notify.alert(msg, type);
                if (result) {
                    location.reload();
                }
            });
        }, function (reason) {
        });
    }

}

